## Script for outputting LaTex constants for externalities and internalities.
rm(list = ls())
source('lib/SetGlobals.R')
source('lib/ExportToLyx.R')
# source('lib/InstallPackages.R')

library(tidyverse)
root <- paste0(dropbox.dir,"Data/dpm/intermediate/")
files <- list.files(root) # Get all files in dpm
files <- files[grepl("aggregate.csv", files) | grepl("externality_internality.csv", files)] # Get all csv files
df <- as.data.frame(do.call(rbind, str_split(gsub(".csv", "",files), "_",  n = 2))) #
colnames(df) <- c("industry", "type")
industries <- unique(df$industry)
for(industry in industries){
  agg.file.idx <- which((df$industry == industry) & (df$type == "aggregate"))
  ext.int.file.idx <- which((df$industry == industry) & (df$type == "externality_internality"))
  output.int <- industry %in% c("cigarette", "soda")
  if(length(ext.int.file.idx) == 0){
    print(c("Industry doesn't have a ext.int.file:", industry))
    ExportToLyx(0, 0, var_str=paste0("ext",str_to_sentence(industry)))
    if(output.int){
      ExportToLyx(0, 0, var_str=paste0("int",str_to_sentence(industry)))
    }
  }else{
    shares <- read.csv(paste0(root, files[agg.file.idx]))
    ext.int <- read.csv(paste0(root, files[ext.int.file.idx]))
    ind.df <- merge(shares, ext.int, by="ticker")
    meanExternalityInd <- weighted.mean(ind.df$externality, w=ind.df$shares/sum(ind.df$shares))
    ExportToLyx(meanExternalityInd, 2, var_str=paste0("ext",str_to_sentence(industry)))
    if(output.int){
      meanInternalityInd <- weighted.mean(ind.df$internality, w=ind.df$shares/sum(ind.df$shares))
      ExportToLyx(meanInternalityInd, 2, var_str=paste0("int",str_to_sentence(industry)))
    }
    
  }
  
}
