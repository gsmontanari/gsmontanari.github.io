# Change to the current working directory
setwd(paste0(github.dir, 'paper'))

# Clean all output
unlink('output', recursive = TRUE)
dir.create('output')

# Delete input folder and copy in the output folders from the other directories.
unlink('input', recursive = TRUE)
dir.create('input')
#file.copy(from='../autos/output/',to="input",recursive = FALSE, copy.mode = TRUE)

# Compile paper

# Change to the root
setwd(github.dir)
source("paper/code/output_ext_int.R")