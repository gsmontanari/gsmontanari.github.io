rm(list = ls())

# Load paths
source('lib/SetGlobals.R')

# Install required packages
# source('lib/InstallPackages.R')

# Change to the current working directory

# Clean all output
unlink("survey/output", recursive = TRUE)
dir.create("survey/output")

source('survey/code/initial_exploration.R')
source('survey/code/industry_outputs.R')