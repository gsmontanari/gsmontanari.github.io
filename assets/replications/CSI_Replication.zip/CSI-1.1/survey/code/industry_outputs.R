## Outputting figures for the survey results accross industries.

## 0.1 Set up the environment
rm(list = ls())
source('lib/SetGlobals.R')

## 0.2 Import necessary packages
library(tidyverse)
library(lfe)
library(readxl)
library(gridExtra)
library(xtable)
library(grid)
extrafont::loadfonts() # Need to run "extrafont::font_import()" and then reload R. Not sure how to incorporate this into the directory -- required for pdf outputs. png outputs works fine
library(ggrepel)
library(extrafont)

# get the functions and settings necessary
source("survey/code/read_data.R")
source("survey/code/study_settings.R")
source("survey/code/input_weights.R")

# Read in survey data
study <- study_label
output_increase_random <- read_survey_data(loc_explore, drop.columns=drop.columns, demographic_keys=demographic_keys,type=studies, surveyor = survey.company, increase_random_process=T)
df0 <- output_increase_random[[1]]
df0.long <- output_increase_random[[2]]

output_increase_random.processed <- survey_post_processing(df0, df0.long)
df0 = output_increase_random.processed[[1]]
df0.long = output_increase_random.processed[[2]]

output <- read_survey_data(loc_explore, drop.columns=drop.columns, demographic_keys=demographic_keys,type=studies, surveyor = survey.company, increase_random_process=increase_random_process)
df <- output[[1]]
df.long <- output[[2]]
output.processed <- survey_post_processing(df, df.long)
df <- output.processed[[1]]
df.long <- output.processed[[2]]


# write survey dataset for estimation

income.groups.shares <- df %>% group_by(income_num) %>% summarise(shares = sum(w)/sum(df$w))
# income.groups.shares <- data.frame(table(df$income_num)/dim(df)[1])
# names(income.groups.shares) <- c("income_num", "shares")
if(main.study){
  write.csv(income.groups.shares, paste0(dropbox.dir, "Data/survey/intermediate/income_groups.csv"), row.names=F)

}

ticker_shortname <- read.csv("lib/ticker_shortname.csv") %>% select(-industry)
ticker_shortname <- unique(ticker_shortname %>% select(survey_name, ticker) %>% filter(survey_name != ""))


ticker_shortname <- rbind(ticker_shortname, data.frame(survey_name="Other", ticker="Other"))

if(sum(unique(df.long$first_choice_firm) %in% ticker_shortname$survey_name == F)>0){
  print("You have a survey firm name that isn't in ticker shortname!!!!")
  print(unique(df.long$first_choice_firm)[unique(df.long$first_choice_firm) %in% ticker_shortname$survey_name == F])
}
df.long <- merge(df.long, ticker_shortname, by.x="first_choice_firm", by.y="survey_name") %>% mutate(first_choice_firm=ticker) %>% select(-ticker)
df0.long <- merge(df0.long, ticker_shortname, by.x="first_choice_firm", by.y="survey_name") %>% mutate(first_choice_firm=ticker) %>% select(-ticker)
industry.curr <- c("airline", "auto", "beer", "cereal", "cig"      ,"retail",  "chain",      "phone",      "soda",   "paste",    "yogurt")
industry.map <- c("airline", "auto", "beer", "cereal", "cigarette","grocery", "restaurant", "smartphone", "soda",  "toothpaste", "yogurt")
names(industry.map) <- industry.curr
#
if(main.study){
  write.csv(df.long%>% select(-satisfaction, -expenditure)  %>%
              mutate(industry = str_replace_all(industry, industry.map)),
            paste0(dropbox.dir, "Data/survey/intermediate/survey_for_estimation.csv"), row.names=FALSE)
  write.csv(df0.long%>% select(-satisfaction, -expenditure)  %>%
              mutate(industry = str_replace_all(industry, industry.map)),
            paste0(dropbox.dir, "Data/survey/intermediate/survey_for_demand_curves.csv"), row.names=FALSE)
  write.csv(df, paste0(dropbox.dir, "Data/survey/intermediate/survey_for_labor.csv"), row.names=FALSE)

}


# Get number of observations per firm.
df.long <- df.long %>% group_by(industry, first_choice_firm) %>% mutate(n_count=n())

# Survey firm level data
autos.firm.make.sheet <-read_excel(paste0(dropbox.dir, "/Data/autos/raw/keys/firm_model_key.xlsx"),sheet=excel_sheets(paste0(dropbox.dir,  "/Data/autos/raw/keys/firm_model_key.xlsx"))[1]) %>%
  rename(firm=Firm, make=Make, `2018_firm_operating`=`2018_operating`) %>% select(-Note) %>% mutate(firm = paste(toupper(substr(firm, 1, 1)), substr(firm, 2, nchar(firm)), sep=""))

# Set some lists for reading in industry data
cpg.industries <- c("cereal", "cig", "soda", "beer", "paste", "yogurt")
cpg.file.names <- c("cereal", "cigarettes", "soda", "beer", "toothpaste", "yogurt")
other.industries <- c("retail", "chain", "phone")
other.file.names <- c("retail", "chain_restaurants", "smartphones")


# Go through survey data and create summary stats for figures
survey.shares.firm <- list()
for(i in 1:length(industries[industries!="labor"])){
  temp.shares <- df %>%group_by(.dots=paste0(industries[i],"Firm"))%>% summarise(n=sum(w), stay = weighted.mean(!!sym(paste0(industries[i],"_behavior")) == "Yes", w,na.rm=T),
                                                                                 satisfaction=weighted.mean(as.numeric(!!sym(paste0(industries[i],"_satisfaction"))),w, na.rm=T),
                                                                                 mean_income=weighted.mean(income_weights, w),
                                                                                 n_count = n()) %>% ungroup()
  names(temp.shares) <- c("Firm_For_Survey", "survey_share", "stay_share", "mean_satisfaction", "mean_income", "n_count")
  other.sum <- sum((df[,sprintf("%s_brand", industries[i])] == "Other")*df$w, na.rm = T)
  temp.shares <- temp.shares %>% filter(is.na(Firm_For_Survey)==F) %>% mutate(survey_share=survey_share/(sum(survey_share) + other.sum))#/dim(df)[1])
  temp.shares[,'Industry'] <- str_to_title(industries[i])
  industry.elasticity <- -get.Elasticity.Doubling(df.long[df.long$industry==industries[i],], df, cat.or.con[i], weight_ind=T)
  temp.shares[,"industry_elasticity"] <- industry.elasticity
  survey.shares.firm[[i]] <- temp.shares %>% filter(is.na(stay_share)==F)
}
survey.shares.firm <- bind_rows(survey.shares.firm)

# Get external datasets
external.shares.firm <- get.External.Firm.Shares()

# Merge external datasets with survey summary stats
shares.firm <- merge(survey.shares.firm, external.shares.firm, by="Firm_For_Survey")
shares.firm$mean_income <- round(shares.firm$mean_income *10 , 3)
shares.firm$own_price_elasticity <- -log(shares.firm$stay_share)/log(1.25)


industry.levels <- c("Airline", "Auto", "Beer", "Cereal", "Cig"      ,"Retail",  "Chain",      "Phone",      "Soda",   "Paste",    "Yogurt")
industry.labels <- c("Airline", "Auto", "Beer", "Cereal", "Cigarette","Grocery", "Restaurant", "Smartphone", "Soda",  "Toothpaste", "Yogurt")

shares.firm$Industry <- factor(shares.firm$Industry, levels=industry.levels,  labels=industry.labels)


shares.firm <- shares.firm %>% mutate(mean_income_external_or_internal = ifelse(is.na(mean_income_external), mean_income,mean_income_external))
if(main.study){
  shares.firm <- shares.firm %>% filter(n_count>=25)
  df.long <- df.long %>% filter(n_count>=25)

}else{
  shares.firm <- shares.firm %>% filter(n_count>=5)
  df.long <- df.long %>% filter(n_count>=5)

}

## FIGURES
# Produce Figure comparing people that stay with product rating
firms.of.interest.satisfaction <- (shares.firm %>% arrange(mean_satisfaction) %>%
                                     filter(row_number() >= (n() - 2) | row_number() <= 3 |
                                              firm %in% c("GM", "Ford" , "Toyota" , "Honda", "Mercedes")))$firm

industry.shape <- 1:11-1
names(industry.shape) <- sort(unique(shares.firm$Industry))
# write.csv(industry.shape, "combined/input/industry_shapes.csv")
g <- ggplot(shares.firm,aes(x=stay_share, y=mean_satisfaction, colour=Industry, shape=Industry)) + geom_point() + geom_text_repel(aes(label=ifelse(firm %in% firms.of.interest.satisfaction, firm, '')),size=2,show.legend = FALSE)+
  xlab("Price response (share of customers that still buy after 25 percent price increase)") + ylab("Customer satisfaction (0-10 scale)") +
  hrbrthemes::theme_ipsum(base_family = "sans")+ scale_shape_manual(values = industry.shape)  +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                                                                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                                                                                        axis.text.x = element_text(hjust=1, size=axis.text.std),
                                                                                                        axis.text.y = element_text(hjust=1, size=axis.text.std))



p <- ggplot_build(g)
palette <- unique(p$data[[1]][,c("colour", "group")]) %>% arrange(group)
industry.fill <- palette[1:length(sort(unique(shares.firm$Industry))), "colour"]
names(industry.fill) <- sort(unique(shares.firm$Industry))
# write.csv(industry.fill, "combined/input/industry_fill.csv")

ggsave(sprintf("survey/output/stay_vs_satisfaction_%s.pdf", study), g, width=5*1.8, height=3.5*1.8, units="in")
ggsave("survey/output/stay_vs_satisfaction.pdf", g, width=5*1.8, height=3.5*1.8, units="in")

# Plot mean income for each firm
firms.of.interest.price_effect <- (shares.firm %>% arrange(stay_share) %>% filter(row_number() >= (n() - 5) | row_number() <= 6 ))$firm
firms.of.interest.price_effect <- c((shares.firm %>% arrange(mean_income) %>% filter(row_number() >= (n() - 5) | row_number() <= 6 ))$firm, firms.of.interest.price_effect)
firms.of.interest.price_effect <- unique(c(firms.of.interest.price_effect, c("GM", "Ford" , "Toyota" , "Honda", "Mercedes", "BMW", "Hyundai", "Fiat Chrysler", "Mazda", "Liggett", "Starbucks", "Chobani", "Yoplait")))

g <- ggplot(shares.firm,aes(x=mean_income, y=own_price_elasticity, colour=Industry, shape=Industry)) + geom_point() + geom_text_repel(aes(label=ifelse(firm %in% firms.of.interest.price_effect, firm, '')),size=3,show.legend = FALSE)+
  xlab("Average customer income ($000s)") + ylab("Own-price elasticity") +
  hrbrthemes::theme_ipsum(base_family = "sans") + scale_colour_manual(values = industry.fill) + scale_shape_manual(values = industry.shape) +
  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
         axis.title.x = element_text(hjust=0.5, size=axis.title.std),
         axis.text.x = element_text(hjust=1, size=axis.text.std),
         axis.text.y = element_text(hjust=1, size=axis.text.std))

ggsave(sprintf("survey/output/income_price_effect_%s.pdf", study), g, width=5*1.8, height=3.5*1.8, units="in")
ggsave("survey/output/income_price_effect.pdf", g, width=5*1.8, height=3.5*1.8, units="in")

g <- ggplot(shares.firm,aes(x=mean_income, y=own_price_elasticity, colour=Industry, shape=Industry)) + geom_point() + geom_text_repel(aes(label=ifelse(firm %in% firms.of.interest.price_effect, firm, '')),size=4,show.legend = FALSE)+
  xlab("Average customer income ($000s)") + ylab("Own-price elasticity") +
  hrbrthemes::theme_ipsum(base_family = "sans") + scale_colour_manual(values = industry.fill) + scale_shape_manual(values = industry.shape) +
  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
         axis.title.x = element_text(hjust=0.5, size=axis.title.std),
         axis.text.x = element_text(hjust=1, size=axis.text.std),
         axis.text.y = element_text(hjust=1, size=axis.text.std))

ggsave("survey/output/income_price_effect_large.pdf", g, width=5*1.8, height=3.5*1.8, units="in")

industry.elasticity <- shares.firm %>% group_by(Industry) %>% summarise(Industry=Industry[1], industry_elasticity = mean(industry_elasticity)) %>% arrange(industry_elasticity)
AutoAggregateElasticity <- industry.elasticity[industry.elasticity$Industry=="Auto","industry_elasticity"][[1]]
ExportToLyx(AutoAggregateElasticity, 2)

industry.elasticity$Industry <- factor(industry.elasticity$industry_elasticity, label=industry.elasticity$Industry)
# HERE
industry.elasticity.output <- industry.elasticity
names(industry.elasticity.output) <- c("Industry", "Aggregate price elasticity")
print(xtable(industry.elasticity.output,digits=c(0,0,2), align=c("l","l", "c")), file="survey/output/aggregate_price_elasticity_industry.tex",sanitize.text.function=function(x){x},include.rownames = FALSE, floating=F)


write.csv(industry.elasticity, paste0(dropbox.dir, "Data/survey/intermediate/industry_elasticities.csv"), row.names = F)
g <- ggplot(industry.elasticity, aes(x=Industry, y=industry_elasticity, colour=Industry, shape=Industry)) + geom_point() +
  xlab("") + ylab("Aggregate price elasticity") +
  hrbrthemes::theme_ipsum(base_family = "sans") + scale_colour_manual(values = industry.fill, guide=F) + scale_shape_manual(values = industry.shape, guide=F) +
  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
         axis.title.x = element_text(hjust=0.5, size=axis.title.std),
         axis.text.x = element_text(angle=45,hjust=1, size=axis.text.std),
         axis.text.y = element_text(hjust=1, size=axis.text.std))


ggsave(sprintf("survey/output/income_industry_elasticity_%s.pdf", study), g, width=5*1.8, height=3.5*1.8, units="in")
ggsave("survey/output/income_industry_elasticity.pdf", g, width=5*1.8, height=3.5*1.8, units="in")


scale.max <- round(max(shares.firm[,c("mean_income_external","mean_income")], na.rm=T)/20)*20
scale.min <- round(min(shares.firm[,c("mean_income_external","mean_income")], na.rm=T)/20 )*20
scale.x.y <- seq(scale.min, scale.max, 20)

# Produce Figure that compares market share data to survey shares
scale.max <- 0.4
scale.min <- 0
scale.x.y <- seq(scale.min, scale.max, 0.05)

g <- ggplot(shares.firm %>% filter(is.na(data_share)==F)) + geom_point(aes(x=data_share, y=survey_share, colour=Industry, shape=Industry)) + xlab("Market share from external source") + ylab("Market share from product market survey") +
  scale_x_continuous(breaks=scale.x.y, limits=c(scale.min, scale.max)) + scale_y_continuous(breaks=scale.x.y, limits=c(scale.min, scale.max)) +
  hrbrthemes::theme_ipsum(base_family = "sans") + scale_colour_manual(values = industry.fill) + scale_shape_manual(values = industry.shape) +
  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
         axis.title.x = element_text(hjust=0.5, size=axis.title.std),
         axis.text.x = element_text(hjust=1, size=axis.text.std),
         axis.text.y = element_text(hjust=1, size=axis.text.std))

ggsave(sprintf("survey/output/validation_survey_external_markets_%s.pdf", study), g, width=5*1.8, height=3.5*1.8, units="in")
ggsave("survey/output/validation_survey_external_markets.pdf", g, width=5*1.8, height=3.5*1.8, units="in")


# Mean income per firm
g <- ggplot(shares.firm) + geom_point(aes(x=reorder(firm, as.integer(mean_income)), y=mean_income, colour=Industry, shape=Industry)) + xlab("Firm") + ylab("Average customer income ($000s)") +
                    hrbrthemes::theme_ipsum(base_family = "sans") + scale_colour_manual(values = industry.fill) + scale_shape_manual(values = industry.shape) +
                                                        theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                                        axis.text.x = element_text(hjust=1, size=axis.text.std),
                                                        axis.text.y = element_text(hjust=1, size=axis.text.std))
ggsave(sprintf("survey/output/firm_mean_income_%s.pdf", study), g, width=5.5*2.5, height=3.5*1.8, units="in")
ggsave("survey/output/firm_mean_income.pdf", g, width=5.5*2.5, height=3.5*1.8, units="in")



# Plot mean income for each firm
scale.max <- round(max(shares.firm[,c("mean_income_external","mean_income")], na.rm=T)/20)*20
scale.min <- round(min(shares.firm[,c("mean_income_external","mean_income")], na.rm=T)/20 )*20
scale.x.y <- seq(scale.min, scale.max, 20)
g <- ggplot(shares.firm %>% filter(is.na(mean_income_external)==F),aes(x=mean_income_external, y=mean_income, colour=Industry, shape=Industry)) + geom_point() + xlab("Average customer income from external dataset ($000s)") + ylab("Average customer income from product market survey ($000s)") +
  scale_x_continuous(breaks=scale.x.y, limits=c(scale.min, scale.max)) + scale_y_continuous(breaks=scale.x.y, limits=c(scale.min, scale.max)) +
        hrbrthemes::theme_ipsum(base_family = "sans") + scale_colour_manual(values = industry.fill) + scale_shape_manual(values = industry.shape) +
        theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
              axis.title.x = element_text(hjust=0.5, size=axis.title.std),
              axis.text.x = element_text(hjust=1, size=axis.text.std),
              axis.text.y = element_text(hjust=1, size=axis.text.std))

ggsave(sprintf("survey/output/auto_income_nhts_survey_%s.pdf", study), g, width=5*1.8, height=3.5*1.8, units="in")
ggsave("survey/output/auto_income_nhts_survey.pdf", g, width=5*1.8, height=3.5*1.8, units="in")


# Binned scatterplot for
df.satisfaction <- df.long %>% mutate(satisfaction=ifelse(satisfaction<5, 5, satisfaction)) %>%  drop_na(satisfaction) %>%
                      group_by(satisfaction) %>% summarise(share_stays=weighted.mean(decision_after_increase == "Yes", weights, na.rm=T), n=n()) %>%
                      mutate(satisfaction = factor(satisfaction, labels=c("5 or less", "6", "7", "8", "9", "10")))

g <- df.satisfaction  %>% ggplot() + geom_point(aes(x=satisfaction, y = share_stays)) + hrbrthemes::theme_ipsum(base_family = "sans")  +
  xlab("Customer satisfaction (0-10 scale)") + ylab("Price response (share of customers that still buy after 25 percent price increase)") +
  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std-1),
     axis.title.x = element_text(hjust=0.5, size=axis.title.std),
     axis.text.x = element_text(hjust=1, size=axis.text.std),
     axis.text.y = element_text(hjust=1, size=axis.text.std))

ggsave(sprintf("survey/output/binned_satisfaction_stay_%s.pdf", study), g, width=5*1.8, height=3.5*1.8, units="in")
ggsave("survey/output/binned_satisfaction_stay.pdf", g, width=5*1.8, height=3.5*1.8, units="in")

# Binned scatterplot for labor
df.satisfaction.labor <- df %>%  drop_na(labor_satisfaction) %>% mutate(satisfaction=ifelse(labor_satisfaction<5, 5, labor_satisfaction))  %>%
  group_by(satisfaction) %>% summarise(share_stays=weighted.mean(labor_behavior == "Yes", w, na.rm=T), n=n()) %>%
  mutate(satisfaction = factor(satisfaction, labels=c("5 or less", "6", "7", "8", "9", "10")))

g <- df.satisfaction.labor  %>% ggplot() + geom_point(aes(x=satisfaction, y = share_stays)) + hrbrthemes::theme_ipsum(base_family = "sans")  +
  xlab("Worker satisfaction (0-10 scale)") + ylab("Price response (share of workers that stay after 10 percent decrease in wages)") +
  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std-1),
         axis.title.x = element_text(hjust=0.5, size=axis.title.std),
         axis.text.x = element_text(hjust=1, size=axis.text.std),
         axis.text.y = element_text(hjust=1, size=axis.text.std))

ggsave("survey/output/binned_satisfaction_stay_labor.pdf", g, width=5*1.8, height=3.5*1.8, units="in")


df.income_brackets <- df.long %>% drop_na(income_brackets, first_choice_firm) %>%
                                  group_by(income_brackets, first_choice_firm) %>%
                                  summarise(share_stays=mean(decision_after_increase=="Yes", na.rm=T),
                                            weights=sum(weights), industry = as.factor(first_choice_firm),
                                            n=n()) %>%
                                  drop_na(share_stays)

reg_y <- felm(as.formula("share_stays ~ first_choice_firm"), data=df.income_brackets)
df.income_brackets$resid_share_stays <- resid(reg_y)
df.income_brackets <- df.income_brackets %>% group_by(income_brackets) %>% summarise(share_stays=weighted.mean(resid_share_stays, weights, na.rm=T), n=n())

g <- df.income_brackets  %>% ggplot() + geom_point(aes(x=income_brackets, y = share_stays)) + hrbrthemes::theme_ipsum(base_family = "sans")  +
  xlab("Customer income bracket") + ylab("Residual price response (share of customers that still buy after 25 percent price increase)") +
  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std-2),
         axis.title.x = element_text(hjust=0.5, size=axis.title.std),
         axis.text.x = element_text(angle=45,hjust=1, size=axis.text.std),
         axis.text.y = element_text(hjust=1, size=axis.text.std))

ggsave(sprintf("survey/output/binned_income_stay_%s.pdf", study), g, width=5*1.8, height=3.5*1.8, units="in")
ggsave("survey/output/binned_income_stay.pdf", g, width=5*1.8, height=3.5*1.8, units="in")




nhts_survey <- shares.firm %>% filter(Industry=="Auto" & is.na(mean_income_external) == F)
cornhtssurveyincome <- cor(nhts_survey$mean_income_external, nhts_survey$mean_income)
corsurveymarketshare <- cor(shares.firm %>% filter(is.na(data_share)==F) %>% select(data_share),
                              shares.firm %>% filter(is.na(data_share)==F) %>% select(survey_share))[1]
corstaysharesatisfaction <- cor(shares.firm$stay_share, shares.firm$mean_satisfaction)
ExportToLyx(cornhtssurveyincome, 2)
ExportToLyx(corsurveymarketshare, 2)
ExportToLyx(corstaysharesatisfaction, 2)

ticker.names <- read.csv(paste0(github.dir, "lib/ticker_shortname.csv")) %>% select(-industry)

sort(setdiff(unique(shares.firm$firm), ticker.names$short_name))
sort(setdiff(ticker.names$short_name, unique(shares.firm$firm)))


# first.color.firms <- sort(unique(shares.firm[!is.na(shares.firm$mean_income_external), "Industry"]))
# industry.levels <- c(first.color.firms, sort(setdiff(shares.firm$Industry, first.color.firms)))
# industry.labels <- c("Auto", "Beer", "Cereal", "Cigarette", "Toothpaste", "Soda", "Yogurt","Airline", "Restaurant", "Smartphone", "Grocery")
# g_legend <- function(a.gplot){
#   tmp <- ggplot_gtable(ggplot_build(a.gplot))
#   leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
#   legend <- tmp$grobs[[leg]]
#   return(legend)
# }
# legend <- g_legend(p2)
# library(gridExtra)
# pp <- arrangeGrob(p1 ,legend,
#                   widths=c(5/4, 1/4),
#                   ncol = 2)



# Descriptive statistics table. Customer satisfaction,Price response, Aggregate price response, 
# Worker satisfaction, Worker price response

weighted.sd <- function(x, w){
  w <- w[is.na(x)==F]
  x <- x[is.na(x)==F]
  sqrt(sum(w/sum(w)*(x-weighted.mean(x, w, na.rm=T))^2))
}

my.summary = function(x, w, as_int=T){
  if(as_int==T){
    min0 <- as.integer(min(x, na.rm=T))
    max0 <- as.integer(max(x, na.rm=T))
  }else{
    min0 <- min(x, na.rm=T)
    max0 <- max(x, na.rm=T)
  }
  list(mean=weighted.mean(x, w, na.rm=T),
       sd=weighted.sd(x,w), min=min0, max=max0)
} 


doubling_unique_strings <- c("75% less","No change","50% less","25% less","I’d entirely stop buying","Yes", "No")
doubling_unique_numbers <- c(0.25,       1,          0.5,       0.75,      0,                         1,    0)
stay_doubling_df <- data.frame(decision_after_doubling=doubling_unique_strings, decision_after_doubling_numeric = doubling_unique_numbers)
df.long <- merge(df.long, stay_doubling_df)

summary.stats <- rbind(my.summary(df.long$satisfaction, df.long$weights),
                       my.summary(df.long$decision_after_increase=="Yes", df.long$weights),
                       my.summary(df.long$decision_after_doubling_numeric, df.long$weights),
                       my.summary(df$labor_satisfaction, df$w),
                       my.summary(df$labor_behavior=="Yes", df$w)
)



colnames(summary.stats) <- c("Mean", "Std. dev.", "Minimum", "Maximum")
rownames(summary.stats) <- c("Customer satisfaction", "Price response", "Aggregate price response", 
                             "Worker satisfaction", "Worker price response")

print(xtable(summary.stats,digits=c(0,2,2,0,0), align=c("l", "c", "c", "c", "c")), file="survey/output/survey_summary_stats.tex",sanitize.text.function=function(x){x}, floating=F)

MeanPriceResponse <- summary.stats["Price response", "Mean"][[1]]*100
MeanAggregatePriceResponse <- summary.stats["Aggregate price response", "Mean"][[1]]*100
MeanWorkerPriceResponse <- summary.stats["Worker price response", "Mean"][[1]]*100

ExportToLyx(MeanPriceResponse, 0)
ExportToLyx(MeanAggregatePriceResponse, 0)
ExportToLyx(MeanWorkerPriceResponse, 0)

