## Initial exploration code for survey data.

## 0.1 Set up the environment
rm(list = ls())
source('lib/SetGlobals.R')
# source('lib/InstallPackages.R')

## 0.2 Import necessary packages
library(tidyverse)
library(lfe)
library(gridExtra)
library(grid)
library(ggrepel)
library(scales)
extrafont::loadfonts() # Need to run "extrafont::loadfonts()" and then reload R. Not sure how to incorporate this into the directory -- required for pdf outputs. png outputs works fine
source("survey/code/read_data.R")
source("survey/code/study_settings.R")

source("survey/code/read_data.R")
source("survey/code/study_settings.R")
source("survey/code/input_weights.R")

# Get csv
output <- read_survey_data(loc_explore, drop.columns=drop.columns, demographic_keys=demographic_keys,type=studies, surveyor = survey.company, increase_random_process=increase_random_process)
df <- output[[1]]
df.long <- output[[2]]
output.processed <- survey_post_processing(df, df.long)
df <- output.processed[[1]]
df.long <- output.processed[[2]]


nValidParticipants <- dim(df)[1]
nValidParticipantsRounded <- round(nValidParticipants/100, digits=0)*100
ExportToLyx(nValidParticipants, 0)
ExportToLyx(nValidParticipantsRounded, 0)

study <- study_label
windsoring_level <- read.csv(paste0(github.dir, "survey/input/windsoring_levels.csv"))
if(sum(windsoring_level$industry != industries[1:11]) > 0){
  print("ERROR in windsoring list!!!")
}
windsorize_list <- c(windsoring_level$windsorize_level, NA)

## 1. Initially we can create bar plots for each industry
for(idx_ind in 1:length(industries[industries != "labor"])){
  industry<- industries[idx_ind]
  industry.elasticity <- get.Elasticity(df.long[df.long$industry==industry,], df)
  industry.doubling.elasticity <- get.Elasticity.Doubling(df.long[df.long$industry==industry,], df, cat.or.con[idx_ind])
  fig_lists <- list()
  if(cat.or.con[idx_ind] == "cat"){
    fig_idx <- 1
    for(idx_col in 1:length(columns.of.interest)){
      column <- columns.of.interest[idx_col]
      col.label <- col.labels.con[idx_col]
      if((idx_col == 4) & ("increase_random" %in% names(df))){
        col.label <- "Behavior if price increased by 25 percent: %s"
        fig_lists[[fig_idx]] <- df %>% filter(increase_random == "1") %>% ggplot(aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
          scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") + ggtitle(sprintf("Elasticity: %s", round(industry.elasticity[1], 3))) +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                              axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                              axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
        col.label <- "Behavior if price increased by 50 percent: %s"
        fig_lists[[fig_idx]] <- df %>% filter(increase_random == "2") %>% ggplot(aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
          scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") + ggtitle(sprintf("Elasticity: %s", round(industry.elasticity[2], 3))) +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                              axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                              axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
        col.label <- "Behavior if price increased by 75 percent: %s"
        fig_lists[[fig_idx]] <- df %>% filter(increase_random == "3") %>% ggplot(aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
          scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") + ggtitle(sprintf("Elasticity: %s", round(industry.elasticity[3], 3))) +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                                                axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                                                axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
      }else if(idx_col == 4){
        fig_lists[[fig_idx]] <- ggplot(data=df,aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
          scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") + ggtitle(sprintf("Elasticity: %s", round(industry.elasticity[1], 3))) +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                              axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                              axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
      }else if(idx_col == 5){
        fig_lists[[fig_idx]] <- ggplot(data=df,aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
          scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") + ggtitle(sprintf("Elasticity: %s", round(industry.doubling.elasticity, 3))) +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                              axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                              axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
      }else{
      fig_lists[[fig_idx]] <- ggplot(data=df,aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..))) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
        hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                            axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                            axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
      fig_idx <- fig_idx + 1
      }
    }
  }else{
    column <- columns.of.interest[1]
    col.label <- col.labels.con[1]
    # Windsorize column of amount purchased.
    fig_idx <- 1
    df[,"windsored_column"] <- df[,sprintf(column, industry)]
    df[df$windsored_column>windsorize_list[idx_ind], "windsored_column"] <- windsorize_list[idx_ind]

    fig_lists[[fig_idx]] <- ggplot(data=df,aes(x=windsored_column))+ geom_histogram(aes(y=..count../sum(..count..)), bins=30) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
      hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                          axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                          axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
    fig_idx <- 2
    for(idx_col in 2:length(columns.of.interest)){
      column <- columns.of.interest[idx_col]
      col.label <- col.labels.con[idx_col]
      if((idx_col == 4) & ("increase_random" %in% names(df))){
        col.label <- "Behavior if price increased by 25 percent: %s"
        fig_lists[[fig_idx]] <- df %>% filter(increase_random == "1") %>% ggplot(aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
          scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") + ggtitle(sprintf("Elasticity: %s", round(industry.elasticity[1], 3))) +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                              axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                              axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
        col.label <- "Behavior if price increased by 50 percent: %s"
        fig_lists[[fig_idx]] <- df %>% filter(increase_random == "2") %>% ggplot(aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
          scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") + ggtitle(sprintf("Elasticity: %s", round(industry.elasticity[2], 3))) +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                              axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                              axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
        col.label <- "Behavior if price increased by 75 percent: %s"
        fig_lists[[fig_idx]] <- df %>% filter(increase_random == "3") %>% ggplot(aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
          scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") + ggtitle(sprintf("Elasticity: %s", round(industry.elasticity[3], 3))) +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                                                axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                                                axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
      }else if(idx_col == 4){
        fig_lists[[fig_idx]] <- ggplot(data=df,aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
          scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") + ggtitle(sprintf("Elasticity: %s", round(industry.elasticity[1], 3))) +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                              axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                              axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
      }else if(idx_col == 5){
        fig_lists[[fig_idx]] <- ggplot(data=df,aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
          scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") + ggtitle(sprintf("Elasticity: %s", round(industry.doubling.elasticity, 3))) +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                              axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                              axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
      }else{
        fig_lists[[fig_idx]] <- ggplot(data=df,aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..))) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
          hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                              axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                              axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
        fig_idx <- fig_idx + 1
      }

    }
  }
  if(("increase_random" %in% names(df))){
    g <- grid.arrange(fig_lists[[1]], fig_lists[[2]], fig_lists[[3]], fig_lists[[4]],fig_lists[[5]],fig_lists[[6]],fig_lists[[7]], nrow=4, top =industry)
  }else{
    g <- grid.arrange(fig_lists[[1]], fig_lists[[2]], fig_lists[[3]], fig_lists[[4]],fig_lists[[5]], nrow=3, top =industry)
  }
  ggsave(sprintf("survey/output/%s_%s.pdf", industry, study), g, width=9, height=12, units="in")

  dev.off()
}
# Labor
industry<- "labor"
fig_lists <- list()
df[,"labor_industry_short"] <-  paste0(substr(df$labor_industry, 0,15), "...")
df[,"labor_occupation_short"] <- paste0(substr(df$labor_occupation, 0,15), "...")
df[,"labor_behavior_short"] <- gsub("\\s*\\([^\\)]+\\)","",as.character(df$labor_behavior))
df[,"labor_purchase_short"] <- paste0(substr(df$labor_purchase, 0,15), "...")

labor.columns.of.interest <- c("labor_purchase_short","labor_count","labor_industry_short","labor_occupation_short")#, "labor_behavior_short")
col.labels.con <-  c("Labor participation", "Labor firm size", "Labor industry", "Labor occupation")#, "Labor behavior")

for(idx_col in 1:length(labor.columns.of.interest)){
  column <- labor.columns.of.interest[idx_col]
  col.label <- col.labels.con[idx_col]
  fig_lists[[idx_col]] <- ggplot(data=df,aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..))) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
}
if(("labor_random" %in% names(df))){
  column <- "labor_behavior_short"
  col.label <- "Labor behavior 10 percent"
  labor.elasticities <- get.Elasticity.labor(df)
  fig_lists[[5]] <- df %>% filter(labor_random == "1") %>% ggplot(aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +ggtitle(sprintf("Elasticity: %s", round(labor.elasticities[1], 3))) +
    scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))

  column <- "labor_behavior_short"
  col.label <- "Labor behavior 20 percent"
  fig_lists[[6]] <- df %>% filter(labor_random == "2") %>% ggplot(aes(x=labor_behavior_short)) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +ggtitle(sprintf("Elasticity: %s", round(labor.elasticities[2], 3))) +
    scale_x_discrete(na.translate = FALSE) + xlab(col.label) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))

  g <- grid.arrange(fig_lists[[1]], fig_lists[[2]], fig_lists[[3]], fig_lists[[4]],fig_lists[[5]],fig_lists[[6]], nrow=3, top =industry)
}else{
  column <- "labor_behavior_short"
  col.label <- "Labor behavior 10 percent"
  labor.elasticities <- get.Elasticity.labor(df)
  fig_lists[[5]] <- df %>% ggplot(aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +ggtitle(sprintf("Elasticity: %s", round(labor.elasticities[1], 3))) +
    scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))

  g <- grid.arrange(fig_lists[[1]], fig_lists[[2]], fig_lists[[3]], fig_lists[[4]],fig_lists[[5]], nrow=3, top =industry)
}

ggsave(sprintf("survey/output/%s_%s.pdf", industry, study), g, width=9, height=12, units="in")

dev.off()

## 3. Produce demographics.
fig_lists <- list()
for(idx_col in 1:length(demo.cols)){

  column <- demo.cols[idx_col]
  col.label <- demo.cols.lab[idx_col]

  fig_lists[[idx_col]] <-ggplot(data=df,aes_string(x=sprintf(column, industry))) + geom_bar(aes(y=(..count..)/sum(..count..))) + xlab(col.label) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=8))

}

g <- grid.arrange(fig_lists[[1]], fig_lists[[2]], fig_lists[[3]], fig_lists[[4]], fig_lists[[5]], nrow=3, top ="Demographics")
ggsave(sprintf("survey/output/demographics_%s.pdf",study), g, width=12, height=15, units="in")


## Get autos elasticity
df.long.autos <- df %>% filter(is.na(auto_model_behavior) == F) # df.long[df.long$industry=="auto",]

if(("increase_random" %in% names(df))){
  random_increases <- df.long.autos$increase_random

  autos.table <- table(df.long.autos$auto_model_behavior,random_increases)
  autosElasticity <- log(autos.table[2,]/colSums(autos.table))/(c(log(1.25), log(1.5)))

  autosElasticityOne <- autosElasticity[1]
  autosElasticityTwo <- autosElasticity[2]

  share.leave <- autos.table[1,]/colSums(autos.table)
  autosLeaveOne <- share.leave[1]
  autosLeaveTwo <- share.leave[2]

  dq <- autos.table[1,]/colSums(autos.table)
  ExportToLyx(autosElasticityOne, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(autosElasticityTwo, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(autosLeaveOne, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(autosLeaveTwo, 2,loc=sprintf("survey/output/scalar_%s.tex", study))

  df.autos.elasticity <- data.frame(dQ=abs(c(dq[1], dq[2])),
                   Shock = c("25% increase","50% increase"))


  col.label <- "Model-level behavior if price increased by 25 percent: %s"
  g1 <- df %>% filter(increase_random == "1") %>% ggplot(aes(x=auto_model_behavior)) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
    scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))

  col.label <- "Model-level behavior if price increased by 50 percent: %s"
  g2 <- df %>% filter(increase_random == "2") %>% ggplot(aes(x=auto_model_behavior)) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
    scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
  g <- grid.arrange(g1, g2, nrow=1, top ="Autos Model-Level")
  ggsave(sprintf("survey/output/autos_dq_%s.pdf",study), g, width=9, height=3.5, units="in")

}else{
  autos.table <- table(df.long.autos$auto_model_behavior)
  autosElasticity <- log(autos.table[2]/sum(autos.table))/log(1.25)
  ExportToLyx(autosElasticity, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  autosModelElasticity <- -autosElasticity
  ExportToLyx(autosModelElasticity, 2)

  share.leave <- autos.table[1]/sum(autos.table)
  autosLeave <- share.leave

  ExportToLyx(autosLeave, 2,loc=sprintf("survey/output/scalar_%s.tex", study))

  col.label <- "Model-level behavior if price increased by 25 percent: %s"
  g1 <- df  %>% ggplot(aes(x=auto_model_behavior)) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
    scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))


  # g <- grid.arrange(g1, g2, nrow=1, top ="Autos Model-Level")
  ggsave(sprintf("survey/output/autos_dq_%s.pdf",study), g1, width=5, height=3.5, units="in")
}

## Get overall elasticity
if(("increase_random" %in% names(df))){

  df.long.new <- merge(df.long, df[,c("id", "increase_random")], by.x="consumer_ids", by.y="id")
  survey.pops <- c(sum(df.long.new$increase_random == "1"), sum(df.long.new$increase_random == "2"))
  df.long.table <- table(df.long.new$decision_after_increase,df.long.new$increase_random)

  overallElasticity <- log(df.long.table[2,]/colSums(df.long.table))/(c(log(1.25), log(1.5)))
  overallElasticityOne <- overallElasticity[1]
  overallElasticityTwo <- overallElasticity[2]

  share.leave <- df.long.table[1,]/colSums(df.long.table)
  overallLeaveOne <- share.leave[1]
  overallLeaveTwo <- share.leave[2]

  df.long.table.new <- rowSums(table(df.long.new$decision_after_doubling,df.long.new$increase_random))

  d.sum <- sum(df.long.table.new)
  doubling.leave <- (df.long.table.new[4] + df.long.table.new[5] + df.long.table.new[6])/d.sum
  doubling.stay <- (df.long.table.new[7] + df.long.table.new[8])/d.sum

  doublingNewLeave <- (0.25*df.long.table.new[1] + 0.5*df.long.table.new[2] + 0.75*df.long.table.new[3])/d.sum+doubling.leave
  doublingElasticity <- log(1-doublingNewLeave)/log(2)

  ExportToLyx(overallElasticityOne, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(overallElasticityTwo, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(overallLeaveOne, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(overallLeaveTwo, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(doublingNewLeave, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(doublingElasticity, 2,loc=sprintf("survey/output/scalar_%s.tex", study))


  col.label <- "Firm-level, overall behavior if price increased by 25 percent: %s"
  g1 <- df.long.new %>% filter(increase_random == "1") %>% ggplot(aes(x=decision_after_increase)) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
    scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))

  col.label <- "Firm-level, overall behavior if price increased by 50 percent: %s"
  g2 <- df.long.new %>% filter(increase_random == "2") %>% ggplot(aes(x=decision_after_increase)) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
    scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))
  g <- grid.arrange(g1, g2, nrow=1, top ="Overall Firm-Level")
  ggsave(sprintf("survey/output/overall_dq_%s.pdf",study), g, width=9, height=3.5, units="in")
}else{
  # df.long.new <- merge(df.long, df[,c("id", "increase_random")], by.x="consumer_ids", by.y="id")
  df.long.table <- rowSums(table(df.long$decision_after_increase,df.long$first_choice_firm))
  overallElasticity <- log(df.long.table[2]/sum(df.long.table))/log(1.25)
  ExportToLyx(overallElasticity, 2,loc=sprintf("survey/output/scalar_%s.tex", study))

  share.leave <- df.long.table[1]/sum(df.long.table)
  overallLeave <- share.leave

  df.long.table.new <- table(df.long$decision_after_doubling)

  d.sum <- sum(df.long.table.new)
  doubling.leave <- (df.long.table.new[4] + df.long.table.new[5] + df.long.table.new[6])/d.sum
  doubling.stay <- (df.long.table.new[7] + df.long.table.new[8])/d.sum

  doublingNewLeave <- (0.25*df.long.table.new[1] + 0.5*df.long.table.new[2] + 0.75*df.long.table.new[3])/d.sum+doubling.leave
  doublingElasticity <- log(1-doublingNewLeave)/log(2)

  ExportToLyx(overallLeave, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(doublingNewLeave, 2,loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(doublingElasticity, 2,loc=sprintf("survey/output/scalar_%s.tex", study))


  col.label <- "Firm-level, overall behavior if price increased by 25 percent: %s"
  g <- df.long %>%  ggplot(aes(x=decision_after_increase)) + geom_bar(aes(y=(..count..)/sum(..count..)),na.rm = TRUE) +
    scale_x_discrete(na.translate = FALSE) + xlab(sprintf(col.label, industry)) + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))

  ggsave(sprintf("survey/output/overall_dq_%s.pdf",study), g, width=5, height=3.5, units="in")
}


sodaElasticityDoubling <- -get.Elasticity.Doubling(df.long[df.long$industry=="soda",], df, cat.or.con[5], weight_ind = T)#get.Elasticity(df.long[df.long$industry=="soda",], df)
cigElasticityDoubling <- -get.Elasticity.Doubling(df.long[df.long$industry=="cig",], df, cat.or.con[4], weight_ind=T)#get.Elasticity(df.long[df.long$industry=="cig",], df)
ExportToLyx(sodaElasticityDoubling, 2)
ExportToLyx(cigElasticityDoubling, 2)
