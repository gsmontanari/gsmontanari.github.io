## 1. Set survey settings
################################################################

# Define location and study
loc_explore1 <- "Data/survey/raw/study_2/data/CSI_Lucid_responses.csv"
demographic_keys1 <- "Data/survey/raw/study_1/data/demographic-codebook.csv"
study1 <- "study_2-Lucid"
read_data_v <- 7

# Define location and study
loc_explore2 <- "Data/survey/raw/study_1/data/CSI_Lucid_responses.csv"
demographic_keys2 <- "Data/survey/raw/study_1/data/demographic-codebook.csv"
study2 <- "study_1-Lucid"
read_data_v <- 7

## Define location and study
loc_explore3 <- "Data/survey/raw/study1-Cint/data/CSI_Cint_responses.csv"
demographic_keys3 <- "Data/survey/raw/study1-Cint/data/demographic-codebook.csv"
study3 <- "study1-Cint"
read_data_v <- 7
study3 <-  "study1-Cint"

increase_random_process <- FALSE

study_label <- "study_3-Lucid-Cint"
loc_explore <- c(loc_explore1, loc_explore2, loc_explore3)
demographic_keys <- c(demographic_keys1, demographic_keys2, demographic_keys3)
studies <- c(study1, study2, study3)
survey.company <- c("Lucid", "Lucid", "Cint")

columns.of.interest <-c("%s_purchase", "%s_brand", "%s_satisfaction", "%s_behavior", "%s_doubled")
drop.columns <- c("StartDate", "EndDate", "Status", "RecordedDate", "UserLanguage", "DistributionChannel")

# Define industry level variables
industries <- c("auto", "airline", "cereal", "cig", "soda", "beer", "retail", "yogurt", "paste", "chain", "phone", "labor")
cat.or.con <- c("cat", "cat", "con", "con", "con", "con", "con", "con", "con", "con", "cat", "cat")
barrier <- c("No", "0", "","","","","", "", "", "","No", "No")

# Bar plot figure settings
col.labels.cat <- c("If a product was purchased from: %s", "Brand purchased: %s",
                    "Satisfaction with %s brand", "Behavior if price increased by 25 percent: %s", "If price in %s doubled")
col.labels.con <-  c("How much was spent on: %s", "Brand purchased: %s",
                     "Satisfaction with %s brand", "Behavior if price increased by 25 percent: %s", "If price in %s doubled")

# Demographic settings
demo.cols.sort <- c("", "gender","education","ethnicity","hhi")
demo.cols <- c("age", "gender_str",  "ethnicity_str","education_str", "hhi_str")
demo.cols.lab <- c("Age", "Sex",  "Race","Education", "Income")
demo.raw <- T

income_unique <- c("0 to $10,000", "$10,000 to $20,000" ,"$20,000 to $30,000","$30,000 to $40,000","$40,000 to $50,000","$50,000 to $60,000","$60,000 to $70,000","$70,000 to $80,000","$80,000 to $90,000","$90,000 to $100,000", "$100,000 to $125,000", "$125,000 to $150,000", "$150,000 and above")
income_int <- 1:length(income_unique)
income_weights <- c(0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5, 11.25, 13.75, 20)
income_factor <- factor(income_int, labels=income_unique)
income_df <- data.frame(income=income_unique, income_num = income_int, income_weights=income_weights)

main.study<- T

# ## 1. Set survey settings -- Cint
# ################################################################
# ## Define location and study
# loc_explore1 <- "Data/survey/raw/study1-Cint/data/CSI_Cint_responses.csv"
# study1 <- "study1-Cint"
# read_data_v <- 7
# 
# demographic_keys <- "Data/survey/raw/study1-Cint/data/demographic-codebook.csv"
# 
# study_label <- "study1-Cint"
# loc_explore <- loc_explore1
# studies <- study1
# increase_random_process <- FALSE
# 
# columns.of.interest <-c("%s_purchase", "%s_brand", "%s_satisfaction", "%s_behavior", "%s_doubled")
# drop.columns <- c("StartDate", "EndDate", "Status", "RecordedDate", "UserLanguage", "DistributionChannel")
# 
# # Define industry level variables
# industries <- c("auto", "airline", "cereal", "cig", "soda", "beer", "retail", "yogurt", "paste", "chain", "phone", "labor")
# cat.or.con <- c("cat", "cat", "con", "con", "con", "con", "con", "con", "con", "con", "cat", "cat")
# barrier <- c("No", "0", "","","","","", "", "", "","No", "No")
# 
# # Bar plot figure settings
# col.labels.cat <- c("If a product was purchased from: %s", "Brand purchased: %s",
#                     "Satisfaction with %s brand", "Behavior if price increased by 25 percent: %s", "If price in %s doubled")
# col.labels.con <-  c("How much was spent on: %s", "Brand purchased: %s",
#                      "Satisfaction with %s brand", "Behavior if price increased by 25 percent: %s", "If price in %s doubled")
# 
# # Demographic settings
# demo.cols.sort <- c("", "gender","education","ethnicity","hhi")
# demo.cols <- c("age", "gender_str",  "ethnicity_str","education_str", "hhi_str")
# demo.cols.lab <- c("Age", "Sex",  "Race","Education", "Income")
# demo.raw <- T
# survey.company <- "Cint"
# 
# income_unique <- c("0 to $10,000", "$10,000 to $20,000" ,"$20,000 to $30,000","$30,000 to $40,000","$40,000 to $50,000","$50,000 to $60,000","$60,000 to $70,000","$70,000 to $80,000","$80,000 to $90,000","$90,000 to $100,000", "$100,000 to $125,000", "$125,000 to $150,000", "$150,000 and above")
# income_int <- 1:length(income_unique)
# income_weights <- c(0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5, 11.25, 13.75, 20)
# income_factor <- factor(income_int, labels=income_unique)
# income_df <- data.frame(income=income_unique, income_num = income_int, income_weights=income_weights)
# 
# main.study<- F
