## Reading in the survey data
source("lib/ExportToLyx.R")
library(xtable)
library(ebal)
library(gridExtra)

read_survey_data <- function(loc, drop.columns=NA, demographic_keys=NA,type=NA, plot_demographics_raw=F, survey.diagnostics=T, surveyor="MTurk", increase_random_process=F){
  ## Function to red in multiple study datasets and pre-process them.
  if(is.vector(loc)){
    df_i <- list()
    for(i in 1:length(loc)){
      # for each loc provided, read in data
      df_i[[i]] <- read_survey_data_single(loc[i], drop.columns=drop.columns, demographic_keys=demographic_keys[i],type=type[i], plot_demographics_raw=plot_demographics_raw, survey.diagnostics=survey.diagnostics, surveyor=surveyor[i],increase_random_process=increase_random_process)
      df_i[[i]][,'survey_v'] <- type[i]
      df_i[[i]] <- df_i[[i]][,colSums(is.na(df_i[[i]]) == F) !=0]
    }
    common.cols <- Reduce(intersect,  lapply(df_i, function(x) names(x)))
    df_i <- lapply(df_i, function(x) x[,common.cols])
    df <- bind_rows(df_i)
    df[,"id"] <- rownames(df)
    # get survey weights
    df <- get.Survey.Weights(df)
    # get long format of data
    df.long <- survey_to_longer(df,increase_random_process=increase_random_process)

    return(list(df, df.long))
  }else{
    # same as previous block, but for loc of size 1
    df <- read_survey_data_single(loc, drop.columns=drop.columns, demographic_keys=demographic_keys,type=type, plot_demographics_raw=plot_demographics_raw, survey.diagnostics=survey.diagnostics, surveyor=surveyor,increase_random_process=increase_random_process)
    df <- get.Survey.Weights(df)
    df.long <- survey_to_longer(df, increase_random_process=increase_random_process)
    return(list(df, df.long))
  }
}

survey_post_processing  <- function(df, df.long){
  ## Takes in an (individual) level df and a (individual, industry) df.long format survey dataset and runs post processing that is outlined in #85.
  initialN <- dim(df)[1]
  # A. Windsorize and flag any (industry, individuals) that surpass a threshold. Drop an observation if N or more flags. To determine N, I'd compare quality on the other metrics below for people with different N. I suspect N=2 would be good.
  windsoring_level <- read.csv(paste0(github.dir, "survey/input/windsoring_levels.csv"))
  df.long <- merge(df.long, windsoring_level, by="industry")
  df.long <- df.long %>% mutate(windsoring_flag=ifelse(is.na(windsorize_level) == F & expenditure > windsorize_level, 1, 0), expenditure=ifelse((is.na(windsorize_level) == F) & (expenditure > windsorize_level), windsorize_level, expenditure))
  # C. Drop if grocery or cereal answers differ by more than say 35% (for 0 diff/1) AND that difference is more than 10% of the average answer.
  df[,"cereal_diff_cond"] <- (abs(df$cereal_diff)/(df$cereal_purchase + (df$cereal_purchase==0)) > 0.35) & (abs(df$cereal_diff) > mean(abs(df$cereal_diff), na.rm=T)/10)
  df[,"retail_diff_cond"] <- (abs(df$retail_diff)/(df$retail_purchase + (df$retail_purchase==0)) > 0.35) & (abs(df$retail_diff) > mean(abs(df$retail_diff), na.rm=T)/10)
  df[, "diff_cond_or"] <- df[,"cereal_diff_cond"]  | df[,"retail_diff_cond"]
  df[, "diff_cond_and"] <- df[,"cereal_diff_cond"]  & df[,"retail_diff_cond"]
  df <- df %>% mutate(auto_model_char_flag = (nchar(auto_model)>100) & is.na(auto_model) == F)
  # D. Drop if complete the survey in less than X seconds. To determine X, I'd again compare quality on the other metrics for people at different X.
  df.long.temp <- df.long %>% group_by(consumer_ids) %>% summarise(windsoring_flags = sum(windsoring_flag), windsoring_ratio=sum(windsoring_flag)/n())


  df.individual.flags <- merge(df[, c("id","diff_cond_or","diff_cond_and","Duration..in.seconds.","auto_model_char_flag")], df.long.temp, by.x="id", by.y = "consumer_ids")
  indiv.to.drop <- df.individual.flags %>% filter(diff_cond_or == T | windsoring_flags >2 | auto_model_char_flag == T)

  write.csv(df %>% filter(id %in% indiv.to.drop$id), paste0(dropbox.dir, "Data/survey/intermediate/dropped_survey_individuals.csv"), row.names=FALSE)
  df.new <- df %>% filter(id %in% indiv.to.drop$id == F)
  df.new <- get.Survey.Weights(df.new)
  # df.long.new <- df.long %>% filter(consumer_ids %in% indiv.to.drop$id == F)
  if("increase_random" %in% names(df.long)){
    df.long.new <- survey_to_longer(df.new, increase_random_process = T)
  }else{
    df.long.new <- survey_to_longer(df.new)
    
  }
  finalN <- dim(df.new)[1]
  postDropPerc <- (1-finalN/initialN)*100
  ExportToLyx(postDropPerc, 0)
  return(list(df.new, df.long.new))
}

survey_to_longer <- function(df, increase_random_process=F){
  ## Takes in a survey with individual level keys and turns it into a (individual, industry) level keys long data frame.
  df.ind <- list()
  for(idx_ind in 1:length(industries[industries !="labor"])){
    industry<- industries[idx_ind]
    if(cat.or.con[idx_ind] == "cat"){
      df.subset <- df[(df[,sprintf(columns.of.interest[1], industry)] != barrier[idx_ind]),]
      df.subset[, "expenditure"] <- ifelse(df.subset[,sprintf(columns.of.interest[1], industry)] != barrier[idx_ind], 1, 0)
    }else{
      df.subset <- df[(df[,sprintf(columns.of.interest[1], industry)] > 0),]
      df.subset[, "expenditure"] <- df.subset[,sprintf(columns.of.interest[1], industry)]
    }
    if(increase_random_process==F){
      df.subset <- df.subset[,c("id", sprintf(columns.of.interest[4], industry),sprintf(columns.of.interest[5], industry), sprintf("%sFirm", industry), "income", "income_num", sprintf(columns.of.interest[3], industry), "w", "income_weights", "expenditure")]
    }else{
      df.subset <- df.subset[,c("id", sprintf(columns.of.interest[4], industry),sprintf(columns.of.interest[5], industry), sprintf("%sFirm", industry), "income", "income_num", sprintf(columns.of.interest[3], industry), "w", "income_weights", "expenditure", "increase_random", "labor_random")]
    }
    df.subset <- df.subset %>% mutate(consumer_ids=id, industry=industry, income_brackets=income, income_groups=income_num, weights=w)
    df.subset$decision_after_increase <- df.subset[,sprintf(columns.of.interest[4], industry)]
    df.subset$decision_after_doubling <- df.subset[,sprintf(columns.of.interest[5], industry)]
    df.subset$satisfaction <- as.integer(df.subset[,sprintf(columns.of.interest[3], industry)])
    df.subset$first_choice_firm <- df.subset[,sprintf("%sFirm", industry)]
    if(increase_random_process==F){
      df.subset <- df.subset %>% select(consumer_ids, industry, income_brackets, income_groups, decision_after_increase, decision_after_doubling, first_choice_firm, satisfaction, weights, income_weights, expenditure)
      
    }else{
      df.subset <- df.subset %>% select(consumer_ids, industry, income_brackets, income_groups, decision_after_increase, decision_after_doubling, first_choice_firm, satisfaction, weights, income_weights, expenditure, increase_random, labor_random)
      
    }
    df.ind[[idx_ind]] <- df.subset
  }
  df.long <- bind_rows(df.ind)
  df.long <- df.long %>% filter(!is.na(first_choice_firm))
  df.long$chi_w <- 1
  return(df.long)
}

read_survey_data_single <- function(loc, drop.columns=NA, demographic_keys=NA,type=NA, plot_demographics_raw=F, survey.diagnostics=T, surveyor="MTurk",increase_random_process=FALSE){
    ## 0.3 Read raw datasets
    df <- read.csv(paste0(dropbox.dir, loc))

    # Save the questions
    questions <- df[1,]

    # Weird formatting issue
    df[df$airline_purchase == "2-Jan","airline_purchase"] <- "1-2"
    df[df$airline_purchase == "5-Mar","airline_purchase"] <- "3-5"
    df[df$airline_purchase == "10-May","airline_purchase"] <- "5-10"

    df[df$labor_count == "9-Jan","labor_count"] <- "1-9"
    df[df$labor_count == "Oct-99","labor_count"] <- "10-99"
    # Typo in beerFirm
    df[df$beerFirm == "Sazerac Company  Inc ","beerFirm"] <- "Sazerac Company Inc"
    df[df$beerFirm == "Sazerac Company  Inc","beerFirm"] <- "Sazerac Company Inc"
    df[df$chainFirm == "Chick-Fil-A", "chainFirm"] <- "Chick-fil-A"

    # get rid of rows with no data and columns that aren't important
    df <- df[3:dim(df)[1],] %>% filter((screening=="Yes, I’m happy to help! I will provide my best answers.") &(consent == "I agree"),grepl("true",Finished,ignore.case=T))

    if (surveyor == "MTurk"){    # get rid of attention check
      df <- df %>% select(-all_of(drop.columns)) %>% filter(duplicated(mturkid) == FALSE)
    }else if (surveyor == "Cint"){
      df <- df %>% select(-all_of(drop.columns)) %>% filter(duplicated(CintID) == FALSE)
    }else{
      df <- df %>% select(-all_of(drop.columns))
    }

    # Lets merge the behavior and brand columns
    for(industry in industries){
      if(sprintf("%s_brand_2", industry) %in% names(df)){
        ic <- sprintf("%s_brand", industry)
        ic.2 <- sprintf("%s_brand_2", industry)
        df[df[ic] == "Other",ic] <- df[df[ic] == "Other",ic.2]
        df <- df %>% select(-all_of(ic.2))
      }
      if(sprintf("%s_behavior_2", industry) %in% names(df)){
        ic <- sprintf("%s_behavior", industry)
        ic.2 <- sprintf("%s_behavior_2", industry)
        df[df[ic] == "",ic] <- df[df[ic] == "",ic.2]
        df <- df %>% select(-all_of(ic.2))
      }
      # Updating %sFirm for Other
      if(sprintf("%s_brand", industry) %in% names(df)){
        df[df[,sprintf("%s_brand", industry)] == "Other",  sprintf("%sFirm", industry)] <- "Other"
      }
    }

    ## Get char columns, turn empty into NA
    cols.char <- c()
    for(industry in industries[industries != "labor"]){
      cols.char <- c(cols.char, sprintf("%s_satisfaction", industry))
      cols.char <- c(cols.char, sprintf("%s_brand", industry))
      if(sprintf("%s_alternative", industry) %in% names(df)){
        cols.char <- c(cols.char, sprintf("%s_alternative", industry))
      }
      cols.char <- c(cols.char, sprintf("%s_behavior", industry))
      if(sprintf("%s_doubled", industry) %in% names(df)){
        cols.char <- c(cols.char, sprintf("%s_doubled", industry))
      }
    }
    for(industry in industries[cat.or.con=="cat"]){
      cols.char <- c(cols.char, sprintf("%s_purchase", industry))
    }
    if("labor" %in% industries){
      cols.char <- c(cols.char, "labor_count","labor_industry","labor_occupation","labor_satisfaction", "labor_behavior", "labor_random")
    }
    df[cols.char] <- sapply(df[cols.char], as.character)
    df <- df %>% mutate_if(is.character, list(~na_if(., "")))


    for(industry in industries){
      col <- sprintf("%s_satisfaction", industry)
      rows.1 <- grepl("extremely satisfied",df[[col]])
      rows.2 <- grepl("moderately satisfied",df[[col]])
      rows.3 <- grepl("not at all satisfied",df[[col]])
      if (sum((rows.1 & rows.2) | (rows.1 & rows.3) | rows.2 & rows.3) !=0){
        print("Issue with mapping behavior answers.")
      }

      df[rows.1, col] <- "10"
      df[rows.2, col] <- "5"
      df[rows.3, col] <- "1"
    }

    # Turn  numeric columns into numeric.
    cols.num <- c("Duration..in.seconds.")
    for(industry in industries[cat.or.con=="con"]){
      cols.num <- c(cols.num, sprintf("%s_purchase", industry))
    }
    for(industry in industries){
      cols.num <- c(cols.num, sprintf("%s_satisfaction", industry))
    }
    df[cols.num] <- sapply(sapply(df[cols.num], as.character), as.numeric)

    # Merge demographics keys
    if(is.na(demographic_keys) == F){
      dem.keys <- read.csv(paste0(dropbox.dir,demographic_keys))
      if(surveyor == "Cint"){
        for (i in unique(dem.keys$question)){
          temp <- dem.keys[dem.keys$question==i,c("value", "demographic")] %>% mutate(!!i:=value, !!paste0(i,"_str"):=demographic) %>% select(-c(value, demographic))
          temp[,paste0(i, "_str")] <- factor(temp[,i], levels=temp[,i],labels=temp[,paste0(i, "_str")],ordered=TRUE)
          df[,paste0(i, "_str")] <-df[,i]
          df <- df %>% select(-!!i)
          df <-left_join(df, temp, by=paste0(i, "_str"))
        }
        if("income_num" %in% names(dem.keys)){
          temp <- dem.keys[dem.keys$question == "hhi",c("value", "income_num")] %>% mutate(hhi=value) %>% select(-c(value))
          temp[,"income_num"] <- as.numeric(temp[,"income_num"])
          df <-left_join(df, temp, by="hhi")
        }

      }else{
        for (i in unique(dem.keys$question)){
          temp <- dem.keys[dem.keys$question==i,c("value", "demographic")] %>% mutate(!!i:=value, !!paste0(i,"_str"):=demographic) %>% select(-c(value, demographic))
          temp[,paste0(i, "_str")] <- factor(temp[,i], levels=temp[,i],labels=temp[,paste0(i, "_str")],ordered=TRUE)
          df[,i] <- as.numeric(df[,i])
          df <-left_join(df, temp, by=i)
        }
        if("income_num" %in% names(dem.keys)){
          temp <- dem.keys[dem.keys$question == "hhi",c("value", "income_num")] %>% mutate(hhi=value) %>% select(-c(value))
          temp[,"income_num"] <- as.numeric(temp[,"income_num"])
          df <-left_join(df, temp, by="hhi")
        }

      }

    }

    # Join with Income
    if("income_num" %in% names(df)){
      df <- left_join(df, income_df, by="income_num")
      df$income <- factor(df[,'income_num'], labels=income_df[,'income'])
      df$income_num <- df$income_num-1 # Make it so lowest income_num is 0

    }else{
      df <- left_join(df, income_df, by="income")
      df$income <- factor(df[,'income_num'], labels=income_df[,'income'])
      df$income_num <- df$income_num-1 # Make it so lowest income_num is 0
    }
    df$cereal_diff <- df$cereal_purchase - as.numeric(df$cereal_check)
    df$retail_diff <- df$retail_purchase - as.numeric(df$grocery_check)

    # Run survey diagnostics
    if(survey.diagnostics == T){
      survey_diag(df, type)
    }


    # Comparing cereal and retail check
    df <- df %>% filter(grepl("puce",AttentionCheck1,ignore.case=T)) %>% filter(grepl("mayo",AttentionCheck2,ignore.case=T))


    if(sum(is.na(df$income))>0){
      hhi.incomes <- c(1, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 12, 13, 13, 13, 13)
      df[is.na(df$income), "income"] <- unlist(df$hhi_str  %>% map(function(x) income_unique[hhi.incomes[x]]))[is.na(df$income)]
      df <- df %>% select(-c(income_num, income_weights))
      df <- left_join(df, income_df, by="income")
      df$income <- factor(df[,'income_num'], labels=income_df[,'income'])
      df$income_num <- df$income_num-1 # Make it so lowest income_num is 0
    }

    if("increase_random" %in% names(df) ){
      if(increase_random_process==FALSE){
        df <- df %>% filter(increase_random == 1)
      }
      if(length(unique(df$increase_random)) == 1 || increase_random_process==FALSE){
        df <- df %>% select(-increase_random )
      }
      
    }
    if(increase_random_process==T && ("increase_random" %in% names(df)) == F){
      df$increase_random <- "1"
    }

    if("labor_random" %in% names(df)){
      if(increase_random_process==FALSE){
        df <- df %>% filter(labor_random == 1)
      }
      if(length(unique(df$labor_random)) == 1){
        df <- df %>% select(-labor_random)
      }

    }
    if(increase_random_process==T && ("labor_random" %in% names(df)) == F){
      df$labor_random <- "1"
    }
    return(df)
}

survey_diag <- function(df, study){
  ## Function to run some survey diagnostics!
  df$one_AC_T <- grepl("puce",df$AttentionCheck1,ignore.case=T) | grepl("mayo",df$AttentionCheck2,ignore.case=T)
  df$two_AC_T <- grepl("puce",df$AttentionCheck1,ignore.case=T) & grepl("mayo",df$AttentionCheck2,ignore.case=T)
  zeroAC <- dim(df)[1]
  oneAC <- sum(df$one_AC_T)
  twoAC <- sum(df$two_AC_T)

  ExportToLyx(zeroAC, 0, loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(oneAC, 0, loc=sprintf("survey/output/scalar_%s.tex", study))
  ExportToLyx(twoAC, 0, loc=sprintf("survey/output/scalar_%s.tex", study))

  # Time distribution
  g <- df %>% mutate(time_30 = ifelse(Duration..in.seconds./60>30, 30, Duration..in.seconds./60)) %>% ggplot(aes(x=time_30)) +geom_histogram(bins=50) + xlab("Duration of survey (minutes)") + ylab("count") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme(axis.title.y = element_text(hjust=0.5, size=11),
                                        axis.title.x = element_text(hjust=0.5, size=11),
                                        axis.text.x = element_text(angle=45, hjust=1))

  ggsave(sprintf("survey/output/duration_hist_%s.pdf",study), g, width=5*1.5, height=3.5*1.5, units="in")

  g <- df %>% mutate(cereal_diff_plot = ifelse(abs(cereal_diff)>100, 100, cereal_diff)) %>%
    ggplot(aes(x=cereal_diff_plot))+geom_histogram(bins=50) + xlab("Cereal (Purchase) - Cereal (Check)") + ylab("Count") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=11),
                                        axis.title.x = element_text(hjust=0.5, size=11),
                                        axis.text.x = element_text(angle=45, hjust=1))


  ggsave(sprintf("survey/output/cereal_check_%s.pdf",study), g, width=5*1.5, height=3.5*1.5, units="in")

  g <- df %>%  mutate(retail_diff_plot = ifelse(abs(retail_diff)>100, 100, retail_diff)) %>%
    ggplot(aes(x=retail_diff_plot))+geom_histogram(bins=50) + xlab("Retail (Purchase) - Retail (Check)") + ylab("Count") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=11),
                                        axis.title.x = element_text(hjust=0.5, size=11),
                                        axis.text.x = element_text(angle=45, hjust=1))


  ggsave(sprintf("survey/output/retail_check_%s.pdf",study), g, width=5*1.5, height=3.5*1.5, units="in")

  cereal_AC <- c(mean(abs(df[,"cereal_diff"])), mean(abs(df[df$one_AC_T ,"cereal_diff"])), mean(abs(df[df$two_AC_T ,"cereal_diff"])))
  retail_AC <- c(mean(abs(df[,"retail_diff"])), mean(abs(df[df$one_AC_T ,"retail_diff"])), mean(abs(df[df$two_AC_T ,"retail_diff"])))

  df_diff_AC <- data.frame(Abs.Cereal.Diff=round(cereal_AC, 2), Abs.Retail.Diff=round(retail_AC, 2))
  rownames(df_diff_AC) <- c("0 AT", "1 AT", "2 AT")
  print(xtable(df_diff_AC), file="survey/output/attention_check_vs_purchase_check.tex",sanitize.text.function=function(x){x},floating = FALSE)
}

get.External.Firm.Shares <- function(){
  #### Get info from external dataset
  df.sales <- list()
  idx <- 1


  # Get autos shares: Using 2019 data
  df.autos <- read.csv(paste0(dropbox.dir, "Data/autos/intermediate/wards_autos_w_electric.csv"), header=TRUE,row.names=1) %>% mutate(total.new = ifelse(is.na(total.new), jan.+feb.+mar.+apr.+may+june+july+aug., total.new))
  df.autos.sales <- read_excel(paste0(dropbox.dir,"Data/autos/raw/keys/total_sales.xlsx")) %>% group_by(year) %>%
    summarise_if(is.numeric, sum) %>% select(year, total_year, total_year_new)

  df.autos <- df.autos[df.autos$total.new!=0,]

  df.autos <- merge(df.autos, autos.firm.make.sheet, by="make", all.x=T)
  df.autos <- merge(df.autos, df.autos.sales, by="year") %>%
    mutate(shares = total/total_year, shares.new = total.new/total_year_new) %>%
    arrange(year, firm, model)
  df.autos.shares <- df.autos %>% filter(year == 2019) %>% group_by(firm, Firm_For_Survey, ticker) %>% summarise(data_share = sum(shares.new))
  df.autos.shares$data_share=df.autos.shares$data_share/sum(df.autos.shares$data_share)
  # Lets get the NHTS data and clean it
  nhts_df<-read_csv(paste0(dropbox.dir,"/Data/oil/raw/NHTS/vehpub.csv"))
  nhts_df <- nhts_df # %>% filter(VEHYEAR >= 2014)
  nhts_income_unique <- c("0 to $10,000", "$10,000 to $15,000" ,"$15,000 to $25,000","$25,000 to $35,000","$35,000 to $50,000","$50,000 to $75,000","$75,000 to $100,000","$100,000 to $125,000","$125,000 to $150,000","$150,000 to $200,000", "$200,000 and above")
  nhts_income_int <- 1:length(nhts_income_unique)
  nhts_weights <- c(0.5, 1.25, 2.0, 3.0, 4.25, 6.25, 8.75, 11.25, 13.75, 17.5, 25)
  nhts_income <- factor(nhts_income_int, labels=nhts_income_unique)

  nhts_df$income<-NA
  nhts_df$income[which(nhts_df$HHFAMINC=="01")]<- nhts_weights[1]
  nhts_df$income[which(nhts_df$HHFAMINC=="02")]<- nhts_weights[2]
  nhts_df$income[which(nhts_df$HHFAMINC=="03")]<- nhts_weights[3]
  nhts_df$income[which(nhts_df$HHFAMINC=="04")]<- nhts_weights[4]
  nhts_df$income[which(nhts_df$HHFAMINC=="05")]<- nhts_weights[5]
  nhts_df$income[which(nhts_df$HHFAMINC=="06")]<- nhts_weights[6]
  nhts_df$income[which(nhts_df$HHFAMINC=="07")]<- nhts_weights[7]
  nhts_df$income[which(nhts_df$HHFAMINC=="08")]<- nhts_weights[8]
  nhts_df$income[which(nhts_df$HHFAMINC=="09")]<- nhts_weights[9]
  nhts_df$income[which(nhts_df$HHFAMINC=="10")]<- nhts_weights[10]
  nhts_df$income[which(nhts_df$HHFAMINC=="11")]<- nhts_weights[11]
  # nhts_df$income <- factor(nhts_df$income, labels=nhts_income_unique)

  autos.firm.make.sheet.nhts <- autos.firm.make.sheet %>% filter(NHTS_code >0)
  nhts_df$NHTS_code <- as.numeric(nhts_df$MAKE)
  nhts_df <-  nhts_df %>% filter((is.na(NHTS_code) == F))
  nhts_df <- nhts_df %>% filter((NHTS_code >0))
  nhts_df <- merge(nhts_df, unique(autos.firm.make.sheet.nhts[,c("firm","NHTS_code")]), by="NHTS_code")
  nhts_df <- nhts_df %>% filter(NHTS_code>0)
  nhts_df<- nhts_df %>% select(firm, income) %>% filter(!is.na(income) | !is.na(firm))
  nhts_firm <- nhts_df %>% group_by(firm) %>% summarise(mean_income_external = mean(income, na.rm=T))
  nhts_firm$mean_income_external <- round(nhts_firm$mean_income_external *10 , 3)
  df.autos.shares.nhts <- left_join(df.autos.shares, nhts_firm, "firm")

  df.sales[[idx]] <- df.autos.shares.nhts
  idx <- idx + 1
  # airlines
  airlines.shares <- read.csv(paste0(dropbox.dir, "Data/dpm/intermediate/airlines_aggregate_for_figures.csv")) %>% select(Firm_For_Survey, data_share, firm, firm_ids) %>% mutate(ticker=firm_ids) %>% select(-firm_ids)
  airlines.shares$data_share <- as.numeric(airlines.shares$data_share)
  airlines.shares$mean_income_external <- NA
  df.sales[[idx]] <- airlines.shares
  idx <- idx + 1
  # CPG
  cpg.mean.income <- read.csv(paste0(dropbox.dir, "Data/cpg/intermediate/firm_average_income.csv")) %>%
    mutate(firm_from_nielson=gsub(" ", "", tolower(firm)), mean_income_external=avg_income) %>% select(-firm, -avg_income)
  cpg.file.numbers <- c(1344, 7460, 1484, 5000, 8404, 3603)
  for(i in 1:length(cpg.file.names)){
    temp.sales <- read_excel(paste0(github.dir,sprintf("issues/55/survey_text_generation/output/%s.xlsx", cpg.file.names[i]))) %>% mutate(firm_from_nielson=gsub(" ", "", tolower(firm_from_nielson)))
    temp.sales <- temp.sales %>% group_by(firm, Firm_For_Survey,firm_from_nielson, ticker) %>% summarise(data_share=first(firm_ratio))
    cpg.mean.income.subset <- cpg.mean.income %>% filter((firm_from_nielson %in% temp.sales$firm_from_nielson) & (cpg.file.numbers[i] == product_module)) %>% select(-product_module)
    # cpg.mean.income.subset <- cpg.mean.income.subset %>% group_by(firm_from_nielson) %>% summarise(mean_income_external=mean(mean_income_external)/1000)
    cpg.mean.income.subset <- cpg.mean.income.subset %>% mutate(mean_income_external=mean_income_external/1000)
    temp.sales <- left_join(temp.sales, cpg.mean.income.subset, by="firm_from_nielson") %>% select(-firm_from_nielson)
    df.sales[[idx]] <- temp.sales
    idx <- idx + 1
  }

  # Get other industries
  other.shares <- list()
  for(i in 1:(length(other.file.names))){
    temp.sales <- read_excel(paste0(github.dir,sprintf("issues/55/survey_text_generation/output/%s.xlsx", other.file.names[i])))
    temp.sales <- temp.sales %>% group_by(firm, Firm_For_Survey, ticker) %>% summarise(data_share=NA)
    temp.sales$mean_income_external <- NA
    df.sales[[idx]] <- temp.sales
    idx <- idx + 1
  }
  external.shares.firm <- bind_rows(df.sales)
}

get.Elasticity <- function(d.l, d){
  ## get elasticity
  if(("increase_random" %in% names(d))){
    random_increases <- d[d$id %in% d.l$consumer_ids, "increase_random"]
    survey.pops <- table(random_increases) #c(sum(random_increases == "1"), sum(random_increases == "2"))
    t.table <- table(d.l$decision_after_increase,random_increases)
    Elasticity <- log(t.table[2,]/colSums(t.table))/log(1+.25*as.numeric(names(survey.pops)))#(c(log(1.25), log(1.5)))
  }else{
    t.table <- rowSums(table(d.l$decision_after_increase,d.l$first_choice_firm))
    Elasticity <- log(t.table[2]/sum(t.table))/log(1.25)
  }
  return(Elasticity)
}

get.Elasticity.Doubling <- function(d.l, d, type, weight_ind=F){
  ## get elasticity after doubling
  if(weight_ind==F){
    df.l.table <- table(d.l$decision_after_doubling)
    if(type == "cat"){
      doubling.stay <- (df.l.table[2])/sum(df.l.table)
      doublingElasticity <- log(doubling.stay)/log(2)
    }else{
      doubling.leave <- (0.25*df.l.table[1] + 0.5*df.l.table[2] + 0.75*df.l.table[3] + 1*df.l.table[4])/sum(df.l.table)
      doublingElasticity <- log(1-doubling.leave)/log(2)
    }
  }else{
    doubling_unique_strings <- c("75% less","No change","50% less","25% less","I’d entirely stop buying","Yes", "No")
    doubling_unique_numbers <- c(0.25,       1,          0.5,       0.75,      0,                         1,    0)
    stay_doubling_df <- data.frame(decision_after_doubling=doubling_unique_strings, decision_after_doubling_numeric = doubling_unique_numbers)
    d.l <- merge(d.l, stay_doubling_df)
    doubling.stay <- sum(d.l$decision_after_doubling_numeric*d.l$weights)/sum(d.l$weights)
    doublingElasticity <- log(doubling.stay)/log(2)
  }
  
}

get.Elasticity.labor <- function(d){
  ## Get labor elasticity
  d.l <- d %>% filter(is.na(df$labor_behavior_short) == FALSE)
  if("labor_random" %in% names(d)){
    t.table <- table(d.l$labor_behavior_short,d.l$labor_random )
    Elasticity <- log(t.table[2,]/colSums(t.table))/(c(log(1.1), log(1.2)))
  }else{
    t.table <- table(d.l$labor_behavior_short)
    Elasticity <- log(t.table[2]/sum(t.table))/log(1.1)
  }
  return(Elasticity)
}
