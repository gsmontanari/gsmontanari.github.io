## File to get the survey weights using acs data.

## 0.2 Import necessary packages
library(tidyverse)
library(lfe)
library(readxl)
library(gridExtra)
library(xtable)
library(grid)
library(ggrepel)
library(extrafont)
library(tidycensus)

get.Survey.Weights <- function(df){
  # Get acs data
  ozaltun.census.key <- "2e33b5fe02e29f60f2027e3872a92d5975e3d408"
  census_api_key(ozaltun.census.key)
  
  # Sex data
  pop.sex <- get_acs(geography = "us", variables = c("Total"="K200101_001E", "Men"="K200101_002E", "Women"="K200101_003E"), year = 2019, survey="acs1") %>% 
    select(estimate) %>% mutate(label=c("Total", "Men", "Women")) %>% mutate(estimate= estimate/estimate[1]) %>% filter(label!="Total")
  
  pop.white <-  get_acs(geography = "us", variables = c("Total"="K200201_001E","White"="K200201_002E"), year = 2019, survey="acs1") %>% 
    select(estimate) %>% mutate(label=c("Total","White")) %>% mutate(estimate= estimate/estimate[1]) %>% filter(label!="Total")
  
  pop.college <-  get_acs(geography = "us", variables = c("Total"="K201501_001E","AS"="K201501_006E", "BS"="K201501_007E",
                                                          "Grad"="K201501_008E"), year = 2019, survey="acs1") %>% 
    select(estimate) %>% mutate(label=c("Total","AS", "BS", "Grad")) %>% mutate(estimate= estimate/estimate[1]) %>% filter(label!="Total") 
  pop.college <- data.frame(estimate=sum(pop.college$estimate), label="College")
  age.label <- c("Total","age.under.18", "age.18.24","age.25.34","age.35.44","age.45.54","age.55.64","age.over.65")
  age.var <- c()
  for( i in 1:length(age.label)){
    age.var <- c(age.var, sprintf("K200104_00%sE", i))
  }
  names(age.var) <- age.label
  pop.age <- get_acs(geography = "us", variables = age.var, year = 2019, survey="acs1") %>% 
    select(estimate) %>% mutate(label=age.label) %>% mutate(estimate= estimate/estimate[1]) %>% filter(label!="Total")
  pop.age$estimate <- pop.age$estimate / (1 - pop.age[which(pop.age$label=="age.under.18"),]$estimate)
  pop.age <- pop.age %>% filter(label != "age.under.18")
  # Income data
  household.income.label <- c("Total","0 to $20,000", "$20,000 to $39,999","$40,000 to $59,999", "$60,000 to $99,999", "$100,000 to $149,999", "$150,000 to $199,999", "$200,000 or more")
  household.var <- c()
  for( i in 1:length(household.income.label)){
    household.var <- c(household.var, sprintf("K201901_00%sE", i))
  }
  names(household.var) <- household.income.label
  pop.household.income <- get_acs(geography = "us", variables = household.var, year = 2019, survey="acs1") %>% 
    select(estimate) %>% mutate(label=household.income.label) %>% mutate(estimate= estimate/estimate[1]) %>% filter(label!="Total")
  
  # Bind top two bins
  pop.household.income <- rbind(pop.household.income, c(sum(pop.household.income[6:7,"estimate"]), "$150,000 or more"))
  pop.household.income <- pop.household.income[-c(6, 7),]
  household.income.label <- c(household.income.label[-c(1, 7, 8)], "$150,000 or more")
  pop.household.income <- t(pop.household.income)
  colnames(pop.household.income) <- pop.household.income["label",]
  pop.household.income <- pop.household.income['estimate',]
  
  # Age data
  pop.age <- t(pop.age)
  colnames(pop.age) <- pop.age["label",]
  pop.age <- pop.age['estimate',]
  pop.values <- c("male"=as.numeric(pop.sex$estimate[1]),"white"=as.numeric(pop.white$estimate[1]),"college"=as.numeric(pop.college$estimate[1]), pop.household.income, pop.age, "treatment"=1, 
                  "0 to $39,999" = as.numeric(pop.household.income["0 to $20,000"])+as.numeric(pop.household.income["$20,000 to $39,999"]),
                  "$100,000 or more" = as.numeric(pop.household.income["$100,000 to $149,999"])+as.numeric(pop.household.income["$150,000 or more"]))
  col.names <- names(pop.values)
  pop.values <- data.frame(t(pop.values))
  names(pop.values) <- col.names
  pop.values <- pop.values %>% mutate(age.over.45 = as.numeric(age.45.54) + as.numeric(age.55.64) +as.numeric(age.over.65))
  
  
  df.demo <- df %>% select(age)
  df.demo$age <- as.integer(df.demo$age)
  survey.incomes <- c(1, 1, 2, 2, 3, 3, 4, 4, 4, 4, 5, 5, 6) # Aggregate top two bins of acs bins
  df.demo$income <- unlist(df$income_num %>% map(function(x) household.income.label[survey.incomes[x+1]]))
  df.demo$male <- ifelse(df$gender_str == "Male", 1, 0)
  df.demo$white <- ifelse(as.character(df$ethnicity_str) == "White", 1, 0)
  df.demo$college <- ifelse(df$education>=5, 1, 0)
  df.demo <- df.demo %>% fastDummies::dummy_cols(select_columns="income", remove_selected_columns=T) 
  names(df.demo) <- gsub("income_", "",names(df.demo))
  df.demo <- df.demo %>% mutate(age.18.24 = ifelse((age >= 18) & (age <=24), 1, 0),
                                age.25.34 = ifelse((age >= 25) & (age <=34), 1, 0),
                                age.35.44 = ifelse((age >= 35) & (age <=44), 1, 0),
                                age.45.54 = ifelse((age >= 45) & (age <=54), 1, 0),
                                age.55.64 = ifelse((age >= 55) & (age <=64), 1, 0),
                                age.over.65 = ifelse((age >= 65), 1, 0))
  
  df.demo <- df.demo %>% select(-age)
  df.demo$treatment<-0
  df.demo <- df.demo %>% mutate(`0 to $39,999` = ifelse(`0 to $20,000`==1 |`$20,000 to $39,999`==1, 1, 0),
                                `$100,000 or more` = ifelse(`$100,000 to $149,999`==1 |`$150,000 or more`==1, 1, 0),
                                age.over.45 = ifelse(age.45.54 == 1 | age.55.64 == 1 | age.over.65 ==1, 1, 0))
  
  pop.rep <- pop.values
  for(i in 1:(dim(df.demo)[1]-1)){pop.rep<- rbind(pop.rep, pop.values)}
  df.demo<-rbind(df.demo[order(names(df.demo))], pop.rep[order(names(pop.rep))])
  treatment <- as.numeric(df.demo$treatment)
  # X <- df.demo %>% select(male, age.25.34, age.35.44, age.45.54, age.55.64, age.over.65, above.60k)
  X <- df.demo %>% select(male, white, college, age.over.45, `$40,000 to $59,999`,`$60,000 to $99,999`, `$100,000 or more`)
  X <- sapply(X, as.numeric)
  
  ebal <- ebalance(treatment, X)
  df$w <- ebal$w
  
  g <- ggplot(data=df,aes(x=w))+ geom_histogram(aes(y=..count../sum(..count..)), bins=30) + xlab("Weights") + ylab("Ratio") +
    hrbrthemes::theme_ipsum(base_family='sans') +  theme( axis.title.y = element_text(hjust=0.5, size=axis.title.std),
                                        axis.title.x = element_text(hjust=0.5, size=axis.title.std),
                                        axis.text.x = element_text(angle=45, hjust=1, size=axis.text.std),axis.text.y = element_text(hjust=1, size=axis.text.std))  
  ggsave("survey/output/weight_hist.pdf", g, width=5*1.8, height=3.5*1.8, units="in")
  
  df[df$w>3,"w"] <- 3
  df[df$w<1/3,"w"] <- 1/3
  
  X.2 <- df.demo %>% select(male, white, college, age.over.45,`0 to $39,999`, `$40,000 to $59,999`,`$60,000 to $99,999`, `$100,000 or more`)
  X.2 <- sapply(X.2, as.numeric)
  
  survey.stats <- colMeans(X.2[1:(dim(df.demo)[1]/2),])
  survey.weighted.stats <- colSums(X.2[1:(dim(df.demo)[1]/2),] *df$w)/sum(df$w)
  acs.stats <- colMeans(X.2[(dim(df.demo)[1]/2+1):dim(df.demo)[1],])
  
  demographics.table <- data.frame(cbind(survey.stats,survey.weighted.stats, acs.stats))
  rownames(demographics.table) <- c("Male", "White", "College", "Age over 45",
                                    "Income 0 to \\$39,999", 
                                    "Income \\$40,000 to \\$59,999", "Income \\$60,000 to \\$99,999", 
                                    "Income \\$100,000 or more")
  names(demographics.table) <- c(" \\shortstack{(1) \\\\ Unweighted \\\\ sample}", "\\shortstack{(2) \\\\ Weighted \\\\ sample}", "\\shortstack{(3) \\\\ U.S. \\\\adults}")

    print(xtable(demographics.table,digits=2, align=c("l", "c", "c", "c")), file="survey/output/demographics_table.tex",sanitize.text.function=function(x){x}, floating=F)

  
  return(df)
}

