## Counterfactual functions needed to generate counterfactuals.
source(paste0(github.dir, "lib/functions.R"))

counterfactual_routine <- function(df_estimates, type_distribution, df_aggregate, profits_weight, welfare_weights,
                                   M = 2000, choice_occasions){
  
  "
    Function to run the counterfactual routine.
  "
  # NOTE: for industries with ex/internalities, merge dataset with df_aggregate prior to running counterfactuals
  
  if ("externality" %in% colnames(df_aggregate)) {
    extern <- TRUE
  } else {
    extern <-  FALSE
  }
  # define some variables
  set.seed(1234)
  consumers_m_f <- generate_nu_m_f(M, df_aggregate)
  J <- nrow(df_aggregate)
  Theta <- length(type_distribution)
  Fplus1 <- ncol(consumers_m_f)
  
  eta <- df_estimates[param == "eta", coeff]
  sigmas <- df_estimates[param == "sigma", coeff]
  zetas <- matrix(df_estimates[param == "zeta", coeff],
                  nrow = Theta - 1,
                  ncol = Fplus1 - 1)
  
  parameters <- c(sigmas, zetas)
  
  # estimate the deltas 
  df_aggregate$delta <- delta_inverter(parameters,
                                       eta,
                                       df_aggregate,
                                       consumers_m_f,
                                       type_distribution)
  # get utilitiies - p*alpha
  utils_thetam_j <- calculate_utils(type_distribution,
                                    consumers_m_f,
                                    df_aggregate$firm_ids,
                                    eta,
                                    df_aggregate$prices,
                                    df_aggregate$delta,
                                    sigmas,
                                    zetas)
  # estimate mc
  df_aggregate$mc <- calculate_mc_j(df_aggregate$prices, utils_thetam_j, diag(J), eta, type_distribution, df_aggregate$market_ids)
  df_aggregate[ticker == "Other", mc := 1]
  
  # Get shares
  s_j <- calculate_share_j(eta, utils_thetam_j, df_aggregate$prices, df_aggregate$market_ids, type_distribution)
  
  #cs_loss_bounds <- - 2 * df_aggregate$prices * s_j #  bound CS loss by twice expenditure per firm
  cs_loss_bounds<- -Inf*s_j
  
  # Estimate consumer surplus, externality without any firm exit
  profit0 <- s_j * (df_aggregate$prices - df_aggregate$mc)
  if (extern == TRUE) {
    ext0 <- sum(s_j * df_aggregate$prices * df_aggregate$externality)
    cs0 <- calculate_consumer_surplus(eta, utils_thetam_j, type_distribution, df_aggregate$prices, internality = df_aggregate$internality)
    cs0_weighted <- calculate_consumer_surplus(eta, utils_thetam_j, type_distribution, df_aggregate$prices, weights = welfare_weights, internality = df_aggregate$internality)
  } else {
    ext0 <- 0
    cs0 <- calculate_consumer_surplus(eta, utils_thetam_j, type_distribution, df_aggregate$prices)
    cs0_weighted <- calculate_consumer_surplus(eta, utils_thetam_j, type_distribution, df_aggregate$prices, weights = welfare_weights)
  }
  
  # For each firm, estimate the counterfactuals
  surplus <- data.table()
  for (firm in df_aggregate$firm_ids) {
    # Get revenue, producer surplus, other producer surplus
    print(sprintf('Calculating the new equilibrium without %s', df_aggregate$short_name[firm]))
    revenue <- df_aggregate[firm_ids == firm, shares * prices]
    sigmas <- parameters[1:Fplus1][-firm]
    zetas <- matrix(parameters[-(1:Fplus1)][-firm], nrow = Theta - 1, ncol = Fplus1 - 2)
    own_ps0 <- profit0[firm]
    other_ps0 <- sum(profit0[-firm])
    
    consumers_m_f.counterfactual <- consumers_m_f[, -firm]
    utils_thetam_j.counterfactual <- utils_thetam_j[, -firm]
    df_counterfactual <- df_aggregate[firm_ids != firm][, firm_ids := .GRP, by = product_ids]
    
    # counterfactual with low prices
    shares_lowprices <- calculate_share_j(eta,
                                          utils_thetam_j.counterfactual,
                                          df_counterfactual$prices,
                                          df_counterfactual$market_ids,
                                          type_distribution)
    
    df_counterfactual_lowprices <- df_counterfactual[, shares := shares_lowprices]
    
    # generate equlibirium under new market setup.
    df_counterfactual <- generate_equilibrium(df_aggregate = df_counterfactual, eta = eta, type_distribution = type_distribution,
                                              consumers_m_f = consumers_m_f.counterfactual, sigmas = sigmas, zetas = zetas)
    df_counterfactual[ticker == "Other", prices := 1]
    
    # get new shares
    s_j <- calculate_share_j(eta, utils_thetam_j.counterfactual, df_counterfactual$prices, df_counterfactual$market_ids, type_distribution)
    
    # get new profits
    profit1 <- s_j * (df_counterfactual$prices - df_counterfactual$mc)
    profit1_lowprices <- df_counterfactual_lowprices$shares * (df_counterfactual_lowprices$prices - df_counterfactual_lowprices$mc)
    
    # compute variables of interest under new equilibrium
    if (extern == TRUE) {
      delta_cs <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual$prices, internality = df_counterfactual$internality) - cs0
      delta_cs <- max(delta_cs, cs_loss_bounds[firm])
      
      delta_cs_lowprices <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual_lowprices$prices, internality = df_counterfactual_lowprices$internality) - cs0
      delta_cs_lowprices <- max(delta_cs_lowprices, cs_loss_bounds[firm])
      
      delta_cs_weighted <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual$prices, weights = welfare_weights, internality = df_counterfactual$internality) - cs0_weighted
      delta_cs_weighted <- max(delta_cs_weighted, cs_loss_bounds[firm])
      
      delta_cs_weighted_lowprices <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual_lowprices$prices, weights = welfare_weights, internality = df_counterfactual_lowprices$internality) - cs0_weighted
      delta_cs_weighted_lowprices <- max(delta_cs_weighted_lowprices, cs_loss_bounds[firm])
    } else {
      delta_cs <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual$prices) - cs0
      delta_cs <- max(delta_cs, cs_loss_bounds[firm])
      
      delta_cs_lowprices <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual_lowprices$prices) - cs0
      delta_cs_lowprices <- max(delta_cs_lowprices, cs_loss_bounds[firm])
      
      delta_cs_weighted <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual$prices, weights = welfare_weights) - cs0_weighted
      delta_cs_weighted <- max(delta_cs_weighted, cs_loss_bounds[firm])
      
      delta_cs_weighted_lowprices <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual_lowprices$prices, weights = welfare_weights) - cs0_weighted
      delta_cs_weighted_lowprices <- max(delta_cs_weighted_lowprices, cs_loss_bounds[firm])
    }
    
    
    delta_own_ps <- 0 - own_ps0
    delta_own_ps_lowprices <- delta_own_ps
    
    delta_other_ps <- sum(profit1) - other_ps0
    delta_other_ps_lowprices <- sum(profit1_lowprices) - other_ps0
    
    delta_ts <- delta_cs + delta_own_ps + delta_other_ps
    delta_ts_lowprices <- delta_cs_lowprices + delta_own_ps_lowprices + delta_other_ps_lowprices
    
    if (extern == TRUE) {
      externality <- sum(s_j * df_counterfactual$prices * df_counterfactual$externality) - ext0
      externality_lowprices <- sum(df_counterfactual_lowprices$shares * df_counterfactual_lowprices$prices * df_counterfactual_lowprices$externality) - ext0
    } else {
      externality <- 0
      externality_lowprices <- 0
    }
    
  
    delta_own_ps_weighted <- delta_own_ps * profits_weight
    delta_own_ps_weighted_lowprices <- delta_own_ps_lowprices * profits_weight
    
    delta_other_ps_weighted <- delta_other_ps * profits_weight
    delta_other_ps_weighted_lowprices <- delta_other_ps_lowprices * profits_weight
    
    delta_ts_weighted <- delta_cs_weighted + delta_own_ps_weighted + delta_other_ps_weighted
    delta_ts_weighted_lowprices <- delta_cs_weighted_lowprices + delta_own_ps_weighted_lowprices + delta_other_ps_weighted_lowprices
    
    delta_ts <- delta_ts-externality
    delta_ts_weighted <- delta_ts_weighted-externality
    
    delta_ts_lowprices <- delta_ts_lowprices -externality_lowprices
    delta_ts_weighted_lowprices <- delta_ts_weighted_lowprices -externality_lowprices
    
    surplus <- rbindlist(list(surplus, data.table(df_aggregate$short_name[firm],
                                                  delta_cs,
                                                  delta_own_ps,
                                                  delta_other_ps,
                                                  externality,
                                                  delta_ts,
                                                  delta_cs_weighted,
                                                  delta_own_ps_weighted,
                                                  delta_other_ps_weighted,
                                                  delta_ts_weighted,
                                                  revenue
    )))
    surplus <- rbindlist(list(surplus, data.table(df_aggregate$short_name[firm],
                                                  delta_cs_lowprices,
                                                  delta_own_ps_lowprices,
                                                  delta_other_ps_lowprices,
                                                  externality_lowprices,
                                                  delta_ts_lowprices,
                                                  delta_cs_weighted_lowprices,
                                                  delta_own_ps_weighted_lowprices,
                                                  delta_other_ps_weighted_lowprices,
                                                  delta_ts_weighted_lowprices,
                                                  revenue
    )),
    use.names = FALSE)
  }
  
  surplus[, (2:11) := lapply(.SD, "*", choice_occasions), .SDcols = 2:11]  # multiply surplus by normalized market size
  colnames(surplus) <- c("firm",
                         "CS_billion",
                         "OwnProfit_billion",
                         "OtherProfit_billion",
                         "Externality_billion",
                         "TS_billion",
                         "CS_weighted_billion",
                         "OwnProfit_weighted_billion",
                         "OtherProfit_weighted_billion",
                         "TS_weighted_billion",
                         "Revenues_billion")
  surplus[, scenario := rep(c("primary", "low_prices"), nrow(df_aggregate))]
  setcolorder(surplus, c("firm", "scenario"))
  
  return(surplus[order(-scenario)])
}

counterfactual_prices <- function(df_estimates, type_distribution, df_aggregate, profits_weight, welfare_weights,
                                  choice_occasions, Industry, M = 2000){
  "
  Function to run the counterfactual routine, specified for certain price changes.
  "
  # NOTE: for industries with ex/internalities, merge dataset with df_aggregate prior to running counterfactuals
  # get variables of interest
  consumers_m_f <- generate_nu_m_f(M, df_aggregate)
  J <- nrow(df_aggregate)
  Theta <- length(type_distribution)
  Fplus1 <- ncol(consumers_m_f)
  
  eta <- df_estimates[param == "eta", coeff]
  sigmas <- df_estimates[param == "sigma", coeff]
  zetas <- matrix(df_estimates[param == "zeta", coeff],
                  nrow = Theta - 1,
                  ncol = Fplus1 - 1)
  
  parameters <- c(sigmas, zetas)
  
  # estimate delta
  df_aggregate$delta <- delta_inverter(parameters,
                                       eta,
                                       df_aggregate,
                                       consumers_m_f,
                                       type_distribution)
  # get utility - price*alpha
  utils_thetam_j <- calculate_utils(type_distribution,
                                    consumers_m_f,
                                    df_aggregate$firm_ids,
                                    eta,
                                    df_aggregate$prices,
                                    df_aggregate$delta,
                                    sigmas,
                                    zetas)
  # get marginal cost
  df_aggregate$mc <- calculate_mc_j(df_aggregate$prices, utils_thetam_j, diag(J), eta, type_distribution, df_aggregate$market_ids)
  df_aggregate[ticker == "Other", mc := 1]
  # get shares
  s_j <- calculate_share_j(eta, utils_thetam_j, df_aggregate$prices, df_aggregate$market_ids, type_distribution)
  
  # for each firm
  counter_prices <- data.table()
  for (firm in df_aggregate$firm_ids) {
    
    print(sprintf('Calculating the new equilibrium without %s', df_aggregate$short_name[firm]))
    sigmas <- parameters[1:Fplus1][-firm]
    zetas <- matrix(parameters[-(1:Fplus1)][-firm], nrow = Theta - 1, ncol = Fplus1 - 2)
    
    consumers_m_f.counterfactual <- consumers_m_f[, -firm]
    utils_thetam_j.counterfactual <- utils_thetam_j[, -firm]
    df_counterfactual <- df_aggregate[firm_ids != firm][, firm_ids := .GRP, by = product_ids]
    
    # generate new equilibrium
    df_counterfactual <- generate_equilibrium(df_aggregate = df_counterfactual, eta = eta, type_distribution = type_distribution,
                                              consumers_m_f = consumers_m_f.counterfactual, sigmas = sigmas, zetas = zetas)
    df_counterfactual[ticker == "Other", prices := 1]
    
    s_j <- calculate_share_j(eta, utils_thetam_j.counterfactual, df_counterfactual$prices, df_counterfactual$market_ids, type_distribution)
    
    df_counterfactual[, industry := Industry]
    
    counter_prices <- rbindlist(list(counter_prices, df_counterfactual[ticker != "Other", .(industry, ticker, prices )]))
  }
  
  counter_prices
}


shapley <- function(df_estimates, type_distribution, df_aggregate, profits_weight, welfare_weights,
                    M = 2000, choice_occasions, ext_val = 0, total_fuel = 0){
  "
    Shapley routine for counterfactual prediction.
  "
  powerset <- function(x) {
    "
    Function to get the power set for a given number.
    "
    sets <- lapply(1:(length(x)), function(i) combn(x, i, simplify = F))
    unlist(sets, recursive = F)
  }
  
  if ("externality" %in% colnames(df_aggregate)) {
    extern <- TRUE
  } else {
    extern <-  FALSE
  }
  
  # compute some important variables
  firm_sets<-powerset(unique(df_aggregate$firm_ids))
  consumers_m_f <- generate_nu_m_f(M, df_aggregate)
  J <- nrow(df_aggregate)
  Theta <- length(type_distribution)
  Fplus1 <- ncol(consumers_m_f)
  
  eta <- df_estimates[param == "eta", coeff]
  sigmas <- df_estimates[param == "sigma", coeff]
  zetas <- matrix(df_estimates[param == "zeta", coeff],
                  nrow = Theta - 1,
                  ncol = Fplus1 - 1)
  
  parameters <- c(sigmas, zetas)
  # estimate deltas
  df_aggregate$delta <- delta_inverter(parameters,
                                       eta,
                                       df_aggregate,
                                       consumers_m_f,
                                       type_distribution)
  # estimate utility-price*alpha
  utils_thetam_j <- calculate_utils(type_distribution,
                                    consumers_m_f,
                                    df_aggregate$firm_ids,
                                    eta,
                                    df_aggregate$prices,
                                    df_aggregate$delta,
                                    sigmas,
                                    zetas)
  # estimate marginal cost
  df_aggregate$mc <- calculate_mc_j(df_aggregate$prices, utils_thetam_j, diag(J), eta, type_distribution, df_aggregate$market_ids)
  df_aggregate[ticker == "Other", mc := 1]
  # get shares
  s_j <- calculate_share_j(eta, utils_thetam_j, df_aggregate$prices, df_aggregate$market_ids, type_distribution)
  
  
  function2<-function(x){
    "
    Function to get variables of interest when a set x of firms is in the market
    "
    # get variables
    set<-x
    sigmas <- parameters[1:Fplus1][set]
    zetas <- matrix(parameters[-(1:Fplus1)][set], nrow = Theta - 1, ncol = length(set))
    
    consumers_m_f.counterfactual <- as.matrix(consumers_m_f[, set])
    utils_thetam_j.counterfactual <- as.matrix(utils_thetam_j[, set])
    df_counterfactual <-  df_aggregate[firm_ids %in% set][, firm_ids := .GRP, by = product_ids]
    
    # generate equilibrium
    df_counterfactual <- generate_equilibrium(df_aggregate = df_counterfactual, eta = eta, type_distribution = type_distribution,
                                              consumers_m_f = consumers_m_f.counterfactual, sigmas = sigmas, zetas = zetas)
    
    df_counterfactual[ticker == "Other", prices := 1]
    
    s_j <- calculate_share_j(eta, utils_thetam_j.counterfactual, df_counterfactual$prices, df_counterfactual$market_ids, type_distribution)
    
    # get new variables of interest
    profit1 <- s_j * (df_counterfactual$prices - df_counterfactual$mc)
    
    if (extern == TRUE) {
      cs <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual$prices, internality = df_counterfactual$internality)
      cs_weighted <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual$prices, weights = welfare_weights, internality = df_counterfactual$internality)
      externality <- sum(s_j * df_counterfactual$prices * df_counterfactual$externality)
    } else {
      cs <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual$prices)
      cs_weighted <- calculate_consumer_surplus(eta, utils_thetam_j.counterfactual, type_distribution, df_counterfactual$prices, weights = welfare_weights)
      externality <- 0
    }
    ps<-rep(0,length(unique(df_aggregate$firm_ids)))
    ps[set] <- profit1
    ts <- sum(ps) +cs - externality
    
    ps_weighted <- ps * profits_weight
    ts_weighted <- cs_weighted + sum(ps_weighted) - externality
    
    return(c(cs,
             ps,
             ts,
             externality,
             cs_weighted,
             ps_weighted,
             ts_weighted) )
  }
  
  # create data frame to output with all possible power sets
  surplus<-lapply(firm_sets, function2 )
  surplus<-as.data.frame(do.call(rbind, surplus))
  surplus<-cbind(1:length(firm_sets),surplus)
  surplus<-as.data.frame(surplus)
  
  surplus<-data.table(surplus)
  surplus[, (2:ncol(surplus)) := lapply(.SD, "*", choice_occasions), .SDcols = 2:ncol(surplus)]
  revenue <- df_aggregate[, shares * prices]*choice_occasions
  
  set_perm<- function(x,no) {
    # function to get all permutations. for industries with more than 7 firms, randomly sample 5000 for computational efficiency.
    if (length(x)>7) {
      temp<-do.call(rbind,lapply(1:5000,function(y) sample(x)))
    } else {
      temp<-permutations(n = length(x), r = length(x), v = x)
    }
    temp <- split(temp, 1:nrow(temp))
    return(lapply(temp, function(x) sort(x[1:which(x==no)])))
  }
  # go through each firm
  out <- data.frame()
  for (firm in unique(df_aggregate$firm_ids)){
    print(firm)
    # get all permutations of a market with a firm
    firm_sets_sub<-set_perm(unique(df_aggregate$firm_ids), firm)
    
    function1<-function(x){
      # Get v(S U f) - v(S)
      set_in<-sort(c(x))
      k_in<-which(sapply(firm_sets,function(x)all(x==set_in)))
      if (length(set_in)>1){
        set_out<-x[-which(x==firm)]
        k_out<-which(sapply(firm_sets,function(x)all(x==set_out)))
        return(surplus[k_in,-1]- surplus[k_out,-1])
      } else{
        return(surplus[k_in,-1])
      }
    }
    # finalize shapley value
    shapley<-bind_rows(lapply(firm_sets_sub, function1 ))
    shapley<-colSums(shapley)/length(firm_sets_sub)
    
    shapley<-c(shapley[1],sum(shapley[2:(1+length(unique(df_aggregate$firm_ids)))][firm]),sum(shapley[2:(1+length(unique(df_aggregate$firm_ids)))][-firm]),shapley[(2+length(unique(df_aggregate$firm_ids))):((4+length(unique(df_aggregate$firm_ids))))],sum(shapley[((5+length(unique(df_aggregate$firm_ids)))):((4+ 2*length(unique(df_aggregate$firm_ids))))][firm]),sum(shapley[((5+length(unique(df_aggregate$firm_ids)))):((4+ 2*length(unique(df_aggregate$firm_ids))))][-firm]),shapley[length(shapley)])
    
    out <- rbind(out , shapley)
  }
  out<-cbind(df_aggregate$short_name,out)
  names(out)<-c("firm","cs",
                "own_ps",
                "other_ps",
                "ts",
                "externality",
                "cs_weighted",
                "own_ps_weighted",
                "other_ps_weighted",
                "ts_weighted")
  
  #out$cs[out$cs> (revenue*2)]<-revenue[out$cs> (revenue*2)]
  #out$cs_weighted[out$cs_weighted> (revenue*2)]<-revenue[out$cs_weighted> (revenue*2)]
  
  out$ts_weighted <- out$cs_weighted + out$own_ps_weighted+out$other_ps_weighted - out$externality
  out$ts <- out$cs + out$own_ps+out$other_ps - out$externality
  
  colnames(out) <- c("firm",
                     "CS_billion",
                     "OwnProfit_billion",
                     "OtherProfit_billion",
                     "TS_billion",
                     "Externality_billion",
                     "CS_weighted_billion",
                     "OwnProfit_weighted_billion",
                     "OtherProfit_weighted_billion",
                     "TS_weighted_billion")
  return(out)
  
}
