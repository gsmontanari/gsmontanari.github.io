## This is the main file to generate the counterfactual results. Both single firm exit estimations and shapley value estimations.
source('../lib/SetGlobals.R')
source('../lib/functions.R')
source('code/counterfactual.R')
library(xtable)
library(Rfast)
library(data.table)
library(tidyverse)
library(gtools)
library(glue)

## 0. Initial definitions of variables and reading in of datasets.
# Read in the welfare weights
w_weights <- fread(paste0(github.dir,'welfare_weights/output/welfare_weights.csv'))
profits_weight <- w_weights[["ProfitWeight"]]

welfare_weights <- c(w_weights[["WeightLowEarner"]], w_weights[["WeightHighEarner"]])

# Get ticker short names
shortnames <- fread(paste0(github.dir,'lib/ticker_shortname.csv')) %>% select(-industry)

# Get income bin shares from survey data. Create type_distribution based on below and above median income.
income_group_shares <- fread(paste0(dropbox.dir,'Data/survey/intermediate/income_groups.csv'))
below.median.income <- sum(income_group_shares[1:median.income.cutoff, "shares"])
above.median.income <- sum(income_group_shares[(median.income.cutoff+1):13, "shares"])
type_distribution <- c(below.median.income, above.median.income)

# Read-in survey data
df_survey <- fread(paste0(dropbox.dir,'Data/survey/intermediate/survey_for_estimation.csv'))[income_groups <= (median.income.cutoff-1), income_groups := 0][income_groups > (median.income.cutoff-1), income_groups := 1]

# Define certain parameters and lists for the counterfactual exercise.
scale_factor <- 0.5  # normalizing factor that defines the initial market share for the inside goods

products <- c("smartphone", "airline", "grocery", "auto", "restaurant", "cereal", "yogurt", "toothpaste", "beer", "soda", "cigarette")
choice_occasions <- fread(paste0(github.dir, "diffprod_counterfactuals/input/choice_occasions.csv"))[, choice_occasions]

## 1. Counterfactuals: Single-firm exit and Shapley scenarios
counterfactual_price_changes <- data.table()
for (i in seq_along(products)){
  # Get parameter estimates
  cpg_estimates <- fread(glue('{github.dir}diffprod_estimation/output/{products[i]}_estimates.csv'),
                         stringsAsFactors = FALSE)

  firms_in_survey <- unique(cpg_estimates$ticker)

  # Get aggregate data
    df_cpg <- fread(glue(paste0(dropbox.dir,'Data/dpm/intermediate/{products[i]}_aggregate.csv')),
                    stringsAsFactors = FALSE)[(ticker %in% firms_in_survey)][,
                                                                             .(shares = sum(shares)),
                                                                             by = ticker][order(ticker)][,
                                                                                                         firm_ids :=  .GRP,
                                                                                                         by = ticker][,
                                                                                                                      `:=`(market_ids = 1,
                                                                                                                           prices = 1,
                                                                                                                           product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
 
  
  if (products[i] == "auto" || products[i] == "airline") {
    # If autos, label the ticker of firms that aren't in estimates as "Other"
    df_cpg <- fread(glue(paste0(dropbox.dir,'Data/dpm/intermediate/{products[i]}_aggregate.csv')),
                    stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey), ticker := "Other"][,
                                                                             .(shares = sum(shares)),
                                                                             by = ticker][order(ticker)][,
                                                                                                         firm_ids :=  .GRP,
                                                                                                         by = ticker][,
                                                                                                                      `:=`(market_ids = 1,
                                                                                                                           prices = 1,
                                                                                                                           product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
  }

  # Merge aggregate data with shortnames
  df_cpg <- merge(df_cpg, shortnames, all.x = TRUE)[is.na(short_name), short_name := "Other"]

  df_cpg <- df_cpg %>% group_by(ticker) %>% filter(row_number() == 1)

  # Get externalities/internalities for select industries and merge with df_cpg
  if (products[i] %in% c("cigarette", "soda", "airline", "auto", "beer")){

    df_cpg_externality <- fread(glue(paste0(dropbox.dir,'Data/dpm/intermediate/{products[i]}_externality_internality.csv')),
                                stringsAsFactors = FALSE)

    if (products[i] == "auto" || products[i] == "airline"){
      other_firms <- fread(glue(paste0(dropbox.dir,'Data/dpm/intermediate/{products[i]}_aggregate.csv')),
                           stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey)][, .(shares = sum(shares)),
                                                                                     by = ticker][, ticker]

      other_externality <- fread(glue(paste0(dropbox.dir,'Data/dpm/intermediate/{products[i]}_externality_internality.csv')),
                            stringsAsFactors = FALSE)[ticker %in% other_firms, lapply(.SD, mean)][is.na(ticker), ticker := "Other"]

      df_cpg_externality <- rbind(df_cpg_externality, other_externality)

    }

    df_cpg <- merge(df_cpg, df_cpg_externality)
  }
  df_cpg <- df_cpg %>% arrange(firm_ids)
  df_cpg <- data.table(df_cpg)
  # Run single-firm counterfactual routine.
  counterfactual_results <- counterfactual_routine(cpg_estimates,
                                                   type_distribution,
                                                   df_cpg,
                                                   profits_weight,
                                                   welfare_weights,
                                                   choice_occasions = choice_occasions[i])
  # Write counterfactual results.
  fwrite(counterfactual_results, paste0("output/", products[i] ,"_output.csv"), row.names = FALSE)

  # Plot counterfactual results.
  plot_output(counterfactual_results[scenario == "primary", -c("Revenues_billion")], products[i], weighted = NULL)
  plot_output(counterfactual_results[scenario == "primary", -c("Revenues_billion")], products[i], weighted = TRUE)

  # Run shapley counterfactual routine.
  shapley_results <- shapley(cpg_estimates,
                             type_distribution,
                             df_cpg,
                             profits_weight,
                             welfare_weights,
                             choice_occasions = choice_occasions[i])
  shapley_results <- data.table(shapley_results)
  # Write shapley results.
  fwrite(shapley_results, glue('output/{products[i]}_shapley.csv'), row.names = FALSE)
  # Plot shapley results.

  plot_shapley(shapley_results, products[i], weighted = NULL)
  plot_shapley(shapley_results, products[i], weighted = TRUE)

  # Get single-firm exit counterfactual prices
  counterfactual_price_changes <- rbindlist(list(counterfactual_price_changes,
                                                  counterfactual_prices(cpg_estimates,
                                                                        type_distribution,
                                                                        df_cpg,
                                                                        profits_weight,
                                                                        welfare_weights,
                                                                        choice_occasions = choice_occasions[i],
                                                                        Industry = products[i])))
}

# Call in industry shapes and colors for figures
industry.shape <-read.csv("../combined/input/industry_shapes.csv")
shape.ind <- industry.shape$X
industry.shape <- industry.shape$x
names(industry.shape) <- shape.ind
industry.fill <- read.csv("../combined/input/industry_fill.csv")
fill.ind <- industry.fill$X
industry.fill <- industry.fill$x
names(industry.fill) <- fill.ind

counterfactual_price_changes[, industry := capitalize(industry)]
# Plot counterfactual prices
ggplot(data = counterfactual_price_changes,
       mapping = aes(x = factor(industry),
                     y = prices,
                     shape = industry,
                     color = industry)) +
  geom_jitter() +
  xlab (" ") +
  ylab("Counterfactual prices") +
  scale_shape_manual(values = industry.shape) +
  scale_colour_manual(values = industry.fill) +
  theme( axis.title.y = element_text(hjust=0.5, size=10),
         axis.title.x = element_text(hjust=0.5, size=10),
         axis.text.x = element_text(angle = 45, vjust=0.5, hjust=1, size=8),
         axis.text.y = element_text(angle=0, hjust=1, size=8),
         legend.title = element_blank(),
         legend.position = "none")

ggsave('output/CounterfactualPrices.pdf', height = 3.5*1.5, width = 5*1.5)
