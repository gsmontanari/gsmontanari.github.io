rm(list = ls())

# Load paths
source('lib/SetGlobals.R')

# Install required packages
# source('lib/InstallPackages.R')

# Change to the current working directory
setwd(paste0(github.dir, 'diffprod_counterfactuals'))

# Clean all output
unlink('output', recursive = TRUE)
dir.create('output')

# Run all scripts
source('code/generate_counterfactuals.R')

# Change to the root
setwd(github.dir)
