# Helper functions for handling worker data from ACS.
source(paste0(github.dir, 'lib/SetGlobals.R'))
library(tidyverse)
library(magrittr)
library(ipumsr)

# Group the OCC2010 CPS/ACS variable (2010 Census) into larger occupation categories:
#   0 - Management,  Business, Science, and Arts Occupations
#   1 - Service
#   2 - Sales and office
#   3 - Natural Resources, Construction, and Maintenance Occupations
#   4 - Production, Transportation, and Material Moving
#   6 - Military + N/A
group_occ10 <- function(occ10) {
  return <- case_when(
    occ10 > 0 & occ10 <= 3540 ~ 0,
    occ10 > 3540 & occ10 <= 4650 ~ 1, 
    occ10 > 4650 & occ10 <= 5940 ~ 2, 
    occ10 > 5940 & occ10 <= 7630 ~ 3, 
    occ10 > 7630 & occ10 <= 9750 ~ 4,
    TRUE ~ 6
  )
}

# Group IND1990 CPS/ACS variable (1990 Census) into larger industry categories.
#   1 - Mining + construction
#   2 - Manufacturing
#   3 - Sales (Wholesale + retail trade)
#   4 - Airlines
#   5 - Professional services
#   0 - Other
#   -1 - NIU
group_ind90 <- function(ind90) {
  return <- case_when(
    ind90 >= 40 & ind90 <= 60 ~ 1,
    ind90 >= 100 & ind90 <= 392 ~ 2,
    ind90 >= 500 & ind90 <= 691 ~ 3,
    ind90 == 421 ~ 4,
    (ind90 >= 812 & ind90 <= 893) | (ind90 >= 721 & ind90 <= 760) ~ 5,
    ind90 <= 932 ~ 0,
    TRUE ~ -1
  )
}

# Converts NAICS codes to industry groupings
#   1 - Mining + construction
#   2 - Manufacturing
#   3 - Sales (Wholesale + retail trade)
#   4 - Airlines
#   5 - Professional services
#   0 - Other
#   -1 - NIU
naics_to_ind <- function(naics) {
  return <- case_when(
    naics >= 200 & naics <= 239 ~ 1,
    naics >= 310 & naics <= 339 ~ 2,
    (naics >= 420 & naics <= 459) | (naics >= 700 & naics <= 729) ~ 3,
    naics == 481 ~ 4,
    (naics >= 540 & naics <= 569) | naics == 811 ~ 5,
    TRUE ~ 0
  )
}

# Create indicator for Bachelor's degree from EDUCD variable.
group_educd_acs <- function(educd) {
  return <- if_else(educd >= 101, 1, 0)
}

# Adjust prices for inflation.
adjust_cpi <- function(prices, cpi, base_cpi) {
  return <- prices * cpi / base_cpi
}

# Imputes missing values of occ in order to keep sum(occ) / sum(emp) same.
# Missing values in occ need to be NaN (not NA) for this to work reliably.
impute_weighted_mean <- function(occ, emp) {
  return <- case_when(!is.na(occ) ~ occ,
                      sum(as.numeric(occ), na.rm = TRUE) == 0 ~ NaN,
                      TRUE ~ emp * sum(occ, na.rm = TRUE) / sum(emp * !is.na(occ), na.rm = TRUE))
}


# Approximate income from primary employer.
assign_income <- function(income_range) {
  return <- case_when(
    income_range == '0 to $10,000' ~ 5000,
    income_range == '$10,000 to $20,000' ~ 15000,
    income_range == '$20,000 to $30,000' ~ 25000,
    income_range == '$30,000 to $40,000' ~ 35000,
    income_range == '$40,000 to $50,000' ~ 45000,
    income_range == '$50,000 to $60,000' ~ 55000,
    income_range == '$60,000 to $70,000' ~ 65000,
    income_range == '$70,000 to $80,000' ~ 75000,
    income_range == '$80,000 to $90,000' ~ 85000,
    income_range == '$90,000 to $100,000' ~ 95000,
    income_range == '$100,000 to $125,000' ~ 112500,
    income_range == '$125,000 to $150,000' ~ 137500,
    income_range == '$150,000 and above' ~ 200000,
    TRUE ~ -1
  )
}

# Approximate ln(# of employees at this establishment).
assign_log_labor_count <- function(labor_count) {
  return <- case_when(
    labor_count == '1-9' ~ mean(log(1), log(9)), 
    labor_count == '10-99' ~ mean(log(10), log(99)),
    labor_count == '100-999' ~ mean(log(100), log(999)),
    labor_count == '1000 or more' ~ mean(log(1000), log(9999)),
    TRUE ~ -1
  )
}

# Group occupations.
# 0 - Management, business, science, and arts
# 1 - Service
# 2 - Sales and office
# 3 - Natural resources, construction, and maintenance
# 4 - Production, Transportation, and Material Moving Occupations
# 5 - Airlines
# 6 - Military or Other (there shouldn't be any Other)
group_occ_survey <- function(labor_occupation) {
  return <- case_when(
    substr(labor_occupation, 1, 5) == 'Manag' ~ 0, # Management, business, and financial operation
    substr(labor_occupation, 1, 5) == 'Compu' ~ 0, # Computer, engineering, and science occupations
    substr(labor_occupation, 1, 5) == 'Educa' ~ 0, # Education, Legal, Community Service, Arts, and Media Occupations,
    substr(labor_occupation, 1, 5) == 'Healt' ~ 0, # Healthcare Practitioners and Technical Occupations
    substr(labor_occupation, 1, 5) == 'Servi' ~ 1, # Service occupations
    substr(labor_occupation, 1, 5) == 'Sales' ~ 2, # Sales and related occupations
    substr(labor_occupation, 1, 5) == 'Offic' ~ 2, # Office and Administrative Support Occupations
    substr(labor_occupation, 1, 5) == 'Farmi' ~ 3, # Farming, Fishing, and Forestry Occupations
    substr(labor_occupation, 1, 5) == 'Const' ~ 3, # Construction and Extraction Occupations
    substr(labor_occupation, 1, 5) == 'Insta' ~ 3, # Installation, Maintenance, and Repair Occupations
    substr(labor_occupation, 1, 5) == 'Produ' ~ 4, # Production Occupations
    substr(labor_occupation, 1, 5) == 'Trans' ~ 4, # Transportation and Material Moving Occupations
    substr(labor_occupation, 1, 5) == 'Airli' ~ 4, # Airlines (make this 5 if we want to separate it)
    TRUE ~ 6 # Military or N/A
  )
}


# Cleaning survey data for labor regression and use!
clean_data <- function(df_survey, df_zip2county, df_county_occ, export_to_lyx=T) {
  # Filter for employed respondents
  num_respondents <- nrow(df_survey)
  df_prep <- df_survey %>%
    select(individual_income, labor_purchase, labor_count, labor_industry, labor_occupation,
          labor_behavior, labor_behavior, education, zip, w) %>%
    filter(!is.na(labor_purchase) & labor_purchase != 'No')
  num_employed <- nrow(df_prep)
  sprintf('Fraction of employed respondents: %i / %i', num_employed, num_respondents)
  # Make sure each zip code is matched to the exactly one county where most of the zip lies.
  df_zip2county %<>%
    rename(zip = ZIP, countyfip = COUNTY)  %>%
    group_by(zip) %>%
    arrange(desc(TOT_RATIO)) %>%
    filter(row_number() == 1) %>%
    ungroup() %>%
    arrange(TOT_RATIO) %>%
    select(zip, countyfip, TOT_RATIO)
  # Match county occupation counts from ACS
  df_prep %<>% 
    left_join(df_zip2county, by = 'zip') %>%
    left_join(df_county_occ, by = c('countyfip' = 'STATECOUNTYFIP'))
  # Create covariates + filter invalid responses
  df_prep %<>% 
    mutate(stay_job = if_else(!is.na(labor_behavior) & labor_behavior == 'Yes', 1, 0),
          wage = assign_income(individual_income),
          x_wage_tthsd = wage / 10000,
          y = (1 - stay_job),
          x_educ = if_else(education >= 6, 1, 0),
          x_logsize = assign_log_labor_count(labor_count),
          x_occ = group_occ_survey(labor_occupation),
          x_log_labormarket = case_when(x_occ == 0 ~ log(OCC0_COUNT),
                                        x_occ == 1 ~ log(OCC1_COUNT),
                                        x_occ == 2 ~ log(OCC2_COUNT),
                                        x_occ == 3 ~ log(OCC3_COUNT),
                                        x_occ == 4 ~ log(OCC4_COUNT),
                                        TRUE ~ -1)
          ) %>%
    filter(x_occ < 6 & wage > -1 & x_logsize > -1 & x_log_labormarket > -1) %>%
    dummy_cols(select_columns = 'x_occ', remove_first_dummy = TRUE)
  if(export_to_lyx==T){
    # Save constants to Lyx file
    NumLaborResponses <- nrow(df_prep)
    sprintf('Fraction of employed with valid occupation, wage, and establishment size: %i / %i', 
            num_employed, NumLaborResponses)
    ExportToLyx(NumLaborResponses, 0)
    MeanLeaveJob <- 1 - (sum(df_prep$stay_job*df_prep$w) / sum(df_prep$w))
    ExportToLyx(MeanLeaveJob, 2)
    MeanLeaveJobPercent <- 100 * MeanLeaveJob
    ExportToLyx(MeanLeaveJobPercent, 0)
    AlphaIllustration <- 10 * round(MeanLeaveJobPercent) / 100
    ExportToLyx(AlphaIllustration, 1)
    MeanSurveyIncome <- 100 * round(100 * sum(df_prep$x_wage_tthsd*df_prep$w)/sum(df_prep$w))
    ExportToLyx(MeanSurveyIncome, 0)
    SurplusIllustration <- MeanSurveyIncome / (2 * AlphaIllustration)
    ExportToLyx(SurplusIllustration, 0)
    
  }
  
  return(df_prep)
}
