# Predicts worker losses is each firm exited. Saves results in an outputed csv file.
rm(list=ls())
source('lib/SetGlobals.R')
source('labor/code/helper_functions.R')
library(tidyverse)
library(fastDummies)
library(magrittr)
library(DescTools)

main <- function(){
  ### File paths
  inpath_model <- paste0(dropbox.dir, 'Data/labor/intermediate/labor_regression.Rds')
  inpath_firms <- paste0(dropbox.dir, 'Data/labor/intermediate/county_ticker_employment_msa_adjusted.csv')
  inpath_county_occ <- 'labor/output/county_occupation_counts.csv'
  # inpath_occ_workers <- 'labor/output/sim_occupation_workers.csv'
  inpath_ind_workers <- 'labor/output/sim_industry_workers.csv'
  # inpath_ind_occ_shares <- 'labor/output/industry_occupation_shares.csv'
  inpath_revenues <- paste0(dropbox.dir, 'Data/labor/raw/ticker_revenue_employment.csv')
  outpath_firm_predictions <- 'labor/output/firm_predictions.csv'
  outpath_firm_predictions1 <- 'labor/output/firm_predictions_lse_3.csv'

  ### Other constants
  wage_drop_percent <- 0.1

  ### Read inputs
  model <- readRDS(inpath_model) # Coefficients from regression
  df_firms <- read_csv(inpath_firms)
  df_firms$area_fips <- as.numeric(df_firms$area_fips)# (Firm, MSA, NAICS) -> Employment counts (InfoUSA)
  df_county_occ <- read_csv(inpath_county_occ)
  # df_occ_workers <- read_csv(inpath_occ_workers)
  df_ind_workers <- read_csv(inpath_ind_workers)
  # df_ind_occ_shares <- read_csv(inpath_ind_occ_shares)
  df_revenues <- read_csv(inpath_revenues) %>% select(ticker, revt_million)

  ### Estimate worker surplus for each firm and save results
  df_results <- predict_worker_welfare(df_firms, df_county_occ, df_ind_workers,
                                       model, wage_drop_percent)
  df_results %<>%
    left_join(df_revenues, by = 'ticker')
  write_csv(df_results, outpath_firm_predictions)
  
  ### Estimate worker surplus with labor supply elasticity adjusted to 3 for each firm and save results.
  # This is part of the robustness analysis
  model1 <- get_updated_model(inpath_model)
  df_results1 <- predict_worker_welfare(df_firms, df_county_occ, df_ind_workers,
                                       model1, wage_drop_percent)
  df_results1 %<>%
    left_join(df_revenues, by = 'ticker')
  write_csv(df_results1, outpath_firm_predictions1)
  
}

# Compute characteristics for each firm in the sample, including total/average weighted/unweighed
# worker surplus, average wage, and average education of workers.
predict_worker_welfare <- function(df_firms, df_county_occ, df_ind_workers,
                                   model, wage_drop_percent) {
  df_firms %<>%
    mutate(IND_I = naics_to_ind(industry), # Create industry groups from NAICS codes
           establishment_surplus = NaN, establishment_welfare = NaN,
           ave_surplus = NaN, ave_welfare = NaN, ave_wage = NaN, ave_educ = NaN)
  for (i in 1:nrow(df_firms)) {
    if(mod(i, 100) == 0) {
      print(i)
    }
    establishment <- slice(df_firms, i)
    establishment_aves <- single_establishment_welfare(establishment$IND_I, establishment$area_fips,
                                          establishment$emp_raw, establishment$emp_adjusted, model,
                                          df_county_occ, df_ind_workers, wage_drop_percent)
    df_firms$establishment_surplus[i] <- establishment_aves$establishment_surplus
    df_firms$establishment_welfare[i] <- establishment_aves$establishment_welfare
    df_firms$ave_surplus[i] <- establishment_aves$ave_surplus
    df_firms$ave_welfare[i] <- establishment_aves$ave_welfare
    df_firms$ave_wage[i] <- establishment_aves$ave_wage
    df_firms$ave_educ[i] <- establishment_aves$ave_educ
  }
  df_results <- df_firms %>%
    group_by(ticker) %>%
    summarise(firm_weighted_welfare_total = sum(establishment_welfare, na.rm = TRUE),
      firm_surplus_total = sum(establishment_surplus, na.rm = TRUE),
      firm_employees_total = sum(emp_adjusted, na.rm = TRUE),
      firm_educ_mean = sum(emp_adjusted * ave_educ, na.rm = TRUE) / sum(emp_adjusted, na.rm = TRUE),
      firm_establishment_jobs_median = median(emp_adjusted, na.rm = TRUE),
      firm_wage_mean = sum(emp_adjusted * ave_wage, na.rm = TRUE) / sum(emp_adjusted, na.rm = TRUE),
      firm_weighted_welfare_per = firm_weighted_welfare_total / firm_employees_total,
      firm_surplus_per = firm_surplus_total / firm_employees_total)
  return(df_results)
}

# This function gets the updated model parameters for the robustness check of 
# different labor supply elasticities. See Issue #142 for more details.
get_updated_model <- function(model_path, set_lse=3){
  survey_path <- paste0(dropbox.dir, 'Data/survey/intermediate/survey_for_labor.csv')

  zip2county_path <- 'labor/input/zip_county_hud0321.csv'
  acs_countyocc_path <- 'labor/output/county_occupation_counts.csv'
  
  ### Read data
  headers <- names(read_csv(survey_path, n_max = 0))
  df_survey <- read_csv(survey_path, col_names = headers, skip = 3)
  df_zip2county <- read_csv(zip2county_path)
  df_county_occ <- read_csv(acs_countyocc_path)

  ### Clean data
  df_prep <- clean_data(df_survey, df_zip2county, df_county_occ, export_to_lyx = F)
  
  ## Get scaling factor
  scaling_factor <- set_lse/(mean(df_prep$y)/0.1)
  model1 <- readRDS(model_path) # Coefficients from regression
  model1$coefficients <- model1$coefficients*scaling_factor
  return(model1)
}

# Computes the worker characteristics for a single firm by estimating the attributes of 1000 workers
# the firm's industry.
single_establishment_welfare <- function(ind_group, county, emp_raw, emp_adjusted, model,
                                         df_county_occ, df_ind_workers, wage_drop_percent) {
  # Get the average surplus and weighted welfare of a representative worker in each industry
  # at this firm based on its county and employee count.
  df_surplus <- df_ind_workers %>%
    filter(IND_GROUP == ind_group) %>%
    rename(x_ind = IND_GROUP,
           x_occ = OCC_GROUP) %>%
    dummy_cols(select_columns = 'x_occ', remove_first_dummy = TRUE) %>%
    mutate(x_logsize = log(emp_raw),
           countyfips = county) 
  # Adds in missing x_occ_# columns
  for (missing_occ in 1:4) {
    occ_colname <- paste0('x_occ_', missing_occ)
    if (!(occ_colname %in% colnames(df_surplus))) {
      # df_surplus %<>%
      #   add_column(missing_occ = 0)
      df_surplus[[occ_colname]] <- 0
    }
  }
  # Compute surplus of the industry in the local county, and then scale by firm size
  df_surplus %<>%
    left_join(df_county_occ, by = c('countyfips' = 'STATECOUNTYFIP')) %>%
    mutate(x_log_labormarket = case_when(x_occ == 0 ~ log(OCC0_COUNT),
                                         x_occ == 1 ~ log(OCC1_COUNT),
                                         x_occ == 2 ~ log(OCC2_COUNT),
                                         x_occ == 3 ~ log(OCC3_COUNT),
                                         x_occ == 4 ~ log(OCC4_COUNT),
                                         TRUE ~ 0),
           alpha_x = (model$coefficients[['x_wage_tthsd']] * x_wage_tthsd +
                     model$coefficients[['x_educ']] * x_educ +
                     model$coefficients[['x_logsize']] * x_logsize +
                     model$coefficients[['x_log_labormarket']] * x_log_labormarket +
                     model$coefficients[['x_occ_1']] * x_occ_1 +
                     model$coefficients[['x_occ_2']] * x_occ_2 +
                     model$coefficients[['x_occ_3']] * x_occ_3 +
                     model$coefficients[['x_occ_4']] * x_occ_4 +
                     model$coefficients[['(Intercept)']]) / wage_drop_percent,
          #  alpha_x = Winsorize(alpha_x, probs = c(0.05, 0.95)),
           alpha_x = if_else(alpha_x < 1, 1, alpha_x), # make sure that alpha_x >= 1
           surplus = wage / (2 * alpha_x),
           weighted_welfare = welfweight * surplus) %>%
    # group_by(x_occ) %>%
    summarise(ave_surplus = mean(surplus, na.rm = TRUE),
              ave_welfare = mean(weighted_welfare, na.rm = TRUE),
              ave_wage = mean(wage, na.rm = TRUE),
              ave_educ = mean(x_educ, na.rm = TRUE),
              min_alpha_x = min(alpha_x),
              max_alpha_x = max(alpha_x),
              establishment_surplus = emp_adjusted * ave_surplus,
              establishment_welfare = emp_adjusted * ave_welfare)# %>%
  # print(df_surplus$min_alpha_x)
  # print('asdfasd')
  # print(df_surplus$max_alpha_x)
  if(nrow(df_surplus) == 0) {
    return <- tibble(ave_surplus = 0, ave_welfare = 0, ave_wage = 0, ave_educ = 0,
                     establishment_surplus = 0, establishment_welfare = 0)
  } else {
    return(df_surplus)
  }
}

main()
