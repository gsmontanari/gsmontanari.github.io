# Plots (1) total surplus against total number of employees and (2) average worker surplus
# against average earnings for all firms. 
rm(list=ls())
source('lib/SetGlobals.R')
library(tidyverse)
library(magrittr)
library(hrbrthemes)

main <- function() {
  ### File paths
  firm_info_path <- paste0(github.dir, 'lib/ticker_shortname.csv')
  industry_shape_path <- paste0(github.dir, 'combined/input/industry_shapes.csv')
  industry_fill_path <- paste0(github.dir, 'combined/input/industry_fill.csv')
  results_path <- paste0(github.dir, 'labor/output/firm_predictions.csv')
  outpath_surplus_employees <- paste0(github.dir, 'labor/output/TotalSurplus_TotalEmployees.pdf')
  outpath_surplus_wage <- paste0(github.dir, 'labor/output/AverageSurplus_AverageEarnings.pdf')

  ### Read data
  firm_info <- read_csv(firm_info_path) %>% 
    select(ticker, industry) %>% filter(industry != "")
  results <- read_csv(results_path)
  results %<>%
    left_join(firm_info, by = 'ticker')
  
  ### Industry and firm settings for plotting
  industry.shape <-read.csv(industry_shape_path)
  shape.ind <- industry.shape$X
  industry.shape <- industry.shape$x
  names(industry.shape) <- shape.ind
  industry.fill <- read.csv(industry_fill_path)
  fill.ind <- industry.fill$X
  industry.fill <- industry.fill$x
  names(industry.fill) <- fill.ind
  
  ### Create plots
  plot_totalsurplus_employees(results, industry.fill, industry.shape, outpath_surplus_employees)
  plot_personsurplus_wage(results, industry.fill, industry.shape, outpath_surplus_wage)
}

formatter1000 <- function(x){ 
    return(x / 1000)
}

# Plots total surplus vs. total employees.
plot_totalsurplus_employees <- function(results, industry.fill, industry.shape, outpath) {
  plot <- results %>%
    ggplot(aes(x = firm_employees_total, y = firm_surplus_total, label = ticker)) + 
      geom_point(aes(color = industry, shape = industry)) + 
      scale_x_log10(labels = scales::trans_format("log10", scales::math_format(10^.x))) +
      scale_y_log10(labels = scales::trans_format("log10", scales::math_format(10^.x))) + 
      xlab('Total employees (log scale)') +
      ylab('Total predicted worker surplus ($ / year, log scale)') +
      hrbrthemes::theme_ipsum(base_family = "sans") +
      scale_shape_manual(values = industry.shape) +
      scale_colour_manual(values = industry.fill) +
      theme(axis.title.y = element_text(hjust=0.5, size=8),
          axis.title.x = element_text(hjust=0.5, size=8),
          axis.text.x = element_text(angle=45, hjust=1, size=8),
          axis.text.y = element_text(hjust=1, size=8),
          legend.title= element_blank())
  ggsave(outpath, plot=plot, height = 3.5*1.5, width = 5*1.5)
}

# Plots average surplus vs. average wage.
plot_personsurplus_wage <- function(results, industry.fill, industry.shape, outpath) {
  plot <- results %>%
    ggplot(aes(x = firm_wage_mean, y = firm_surplus_total / firm_employees_total, label = ticker)) + 
      geom_point(aes(color = industry, shape = industry)) + 
      scale_x_continuous(labels = formatter1000) +
      scale_y_continuous(labels = formatter1000) +
      xlab('Average employee earnings (thousand $ / year)') +
      ylab('Average predicted worker surplus (thousand $ / year)') +
      hrbrthemes::theme_ipsum(base_family = "sans") +
      scale_shape_manual(values = industry.shape) +
      scale_colour_manual(values = industry.fill) +
      theme(axis.title.y = element_text(hjust=0.5, size=8),
          axis.title.x = element_text(hjust=0.5, size=8),
          axis.text.x = element_text(angle=45, hjust=1, size=8),
          axis.text.y = element_text(hjust=1, size=8),
          legend.title= element_blank())
  ggsave(outpath, plot=plot, height = 3.5*1.5, width = 5*1.5)
}

main()