# Cleans the ACS data and (1) computes occupation shares for each industry and (2) 
# draws 1000 random workers and their attributes from each occupation.
# Saves results into two csv output files.
rm(list=ls())
source('lib/SetGlobals.R')
source(paste0(github.dir, 'labor/code/helper_functions.R'))
library(tidyverse)
library(magrittr)
library(ipumsr)

main <- function() {
  ### File paths
  # Data on occupations in each county
  inpath_acs <- paste0(dropbox.dir, 'Data/labor/raw/ACS/usa_00004.xml')
  # Welfare weights of each income percentile
  inpath_percentiles <- paste0(github.dir, 'welfare_weights/output/percentile_welfare_weights.csv')
  # Output path for occupation shares for all industries
  # outpath_ind_occ_shares <- paste0(github.dir, 'labor/output/industry_occupation_shares.csv')
  # Output path for simulated workers in each occupation
  # outpath_occ_simworkers <- paste0(github.dir, 'labor/output/sim_occupation_workers.csv')
  # Output path for simulated workers in each industry
  outpath_ind_simworkers <- paste0(github.dir, 'labor/output/sim_industry_workers.csv')

  ### Read data
  df_acs <- clean_acs(inpath_acs)
  df_percentiles <- read_csv(inpath_percentiles)

  ### Get occupation shares and simulate workers.
  # df_ind_occ_shares <- industry_occupation_shares(df_acs)
  # df_sim <- sim_occupation_workers(df_acs, df_percentiles)
  df_sim <- sim_industry_workers(df_acs, df_percentiles)

  ### Save results
  # write_csv(df_ind_occ_shares, outpath_ind_occ_shares)
  write_csv(df_sim, outpath_ind_simworkers)
}

####### 1. Clean data sources

# Clean ACS data by making wages real, dropping NA values, and grouping occupation and industry 
# variables.
clean_acs <- function(inpath_acs) {
  # Read in data
  ddi <- read_ipums_ddi(inpath_acs)
  df_acs <- read_ipums_micro(ddi, vars = 
                            c('YEAR', 'OCC2010', 'IND1990', 'INCWAGE', 'HHINCOME', 'EDUCD', 
                              'CPI99', 'PERWT'), 
                            verbose = FALSE)
  # Get 2019 CPI                          
  cpi19 <- df_acs %>%
    group_by(YEAR) %>%
    summarise(cpi = median(CPI99)) %>%
    filter(YEAR == 2019) %>%
    pull('cpi')
  # Make wages real and construct variables
  return <- df_acs %>%
    filter(!is.na(INCWAGE) & INCWAGE < 999998 & INCWAGE > 0,
          !is.na(OCC2010) & OCC2010 > 0 & OCC2010 < 9800,
          !is.na(IND1990) & IND1990 > 0 & IND1990 < 9670) %>%
    mutate(x_educ = group_educd_acs(EDUCD), 
          wage = adjust_cpi(INCWAGE, CPI99, cpi19), # adjusted to 2019 dollars
          hhinc = adjust_cpi(HHINCOME, CPI99, cpi19),
          x_wage_tthsd = wage / 10000, 
          OCC_GROUP = group_occ10(OCC2010),
          IND_GROUP = group_ind90(IND1990))
}

####### 2. Get occupation shares of each industry

# Get share of each industry consisting of each occupation.
# industry_occupation_shares <- function(df_acs) {
#   return <- df_acs %>%
#     filter(OCC_GROUP < 6) %>%
#     # Get (industry, occupation) counts
#     group_by(IND_GROUP, OCC_GROUP) %>%
#     summarise(count = sum(PERWT)) %>% # Now grouped only by IND_GROUP
#     # Make occupation county counts into column
#     mutate(OCC0 = ifelse(OCC_GROUP == 0, count, 0),
#           OCC1 = ifelse(OCC_GROUP == 1, count, 0),
#           OCC2 = ifelse(OCC_GROUP == 2, count, 0),
#           OCC3 = ifelse(OCC_GROUP == 3, count, 0),
#           OCC4 = ifelse(OCC_GROUP == 4, count, 0)) %>% 
#     # Get occupation shares by industry
#     group_by(IND_GROUP) %>% 
#     summarise(OCC0_SHARE = sum(OCC0) / sum(count),
#               OCC1_SHARE = sum(OCC1) / sum(count),
#               OCC2_SHARE = sum(OCC2) / sum(count),
#               OCC3_SHARE = sum(OCC3) / sum(count),
#               OCC4_SHARE = sum(OCC4) / sum(count)) %>%
#     ungroup()
# }

######## 3. Sample 1000 workers' education and wages in each occupation

# Return tibble with 1000 workers in each occupation and their attributes.
# sim_occupation_workers <- function(df_acs, df_percentiles) {
#   n_simworkers <- 100
#   occupations <- 0:4
#   df_sim = tibble(OCC_GROUP = c(), x_wage_tthsd = c(), wage = c(), x_educ = c(), hhinc = c(), 
#                   welfweight = c())

#   for (occ in occupations) {
#     df_occ <- df_acs %>%
#       filter(OCC_GROUP == occ) %>%
#       sample_n(n_simworkers, weight = PERWT) %>%
#       mutate(hhinc_perc_idx = findInterval(hhinc, df_percentiles$ACS_LowBound, left.open = FALSE),
#              hhinc_perc_idx = pmax(hhinc_perc_idx, 1),
#              welfweight = df_percentiles$WelfareWeight[hhinc_perc_idx]) %>%
#       select(OCC_GROUP, x_wage_tthsd, wage, x_educ, hhinc, welfweight)
#     df_sim %<>%
#       bind_rows(df_occ)
#   }

#   return(df_sim)
# }

# Return tibble with 1000 workers in each industry and their attributes.
sim_industry_workers <- function(df_acs, df_percentiles) {
  n_simworkers <- 1000
  industries <- 0:5
  df_sim = tibble(IND_GROUP = c(), x_wage_tthsd = c(), wage = c(), x_educ = c(), hhinc = c(), 
                  welfweight = c())

  for (ind in industries) {
    df_ind <- df_acs %>%
      filter(IND_GROUP == ind) %>%
      sample_n(n_simworkers, weight = PERWT) %>%
      mutate(hhinc_perc_idx = findInterval(hhinc, df_percentiles$ACS_LowBound, left.open = FALSE),
             hhinc_perc_idx = pmax(hhinc_perc_idx, 1),
             welfweight = df_percentiles$WelfareWeight[hhinc_perc_idx]) %>%
      select(IND_GROUP, OCC_GROUP, x_wage_tthsd, wage, x_educ, hhinc, welfweight)
    df_sim %<>%
      bind_rows(df_ind)
  }

  return(df_sim)
}

main()
