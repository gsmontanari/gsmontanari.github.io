# Regresses linear probability model for probability of leaving a firm if wages dropped
# Outputs (1) model as Rds, (2) tex file of coefficients
rm(list=ls())
source('lib/SetGlobals.R')
source(paste0(github.dir, 'lib/ExportToLyx.R'))
source('labor/code/helper_functions.R')
library(tidyverse)
library(fastDummies)
library(stargazer)
library(magrittr)
library(hrbrthemes)

main <- function() {
  ### File paths
  survey_path <- paste0(dropbox.dir, 'Data/survey/intermediate/survey_for_labor.csv')
  kappa_path <- 'welfare_weights/output/welfare_weights.csv'
  zip2county_path <- 'labor/input/zip_county_hud0321.csv'
  acs_countyocc_path <- 'labor/output/county_occupation_counts.csv'
  out_path_model <- paste0(dropbox.dir, 'Data/labor/intermediate/labor_regression.Rds')
  out_path_tex <- 'labor/output/labor_regression_coeffs.tex'
  out_path_surveysurplus <- 'labor/output/survey_surplus_hist.pdf'
  out_path_surveywelfare <- 'labor/output/survey_welfare_hist.pdf'

  ### Read data
  headers <- names(read_csv(survey_path, n_max = 0))
  df_survey <- read_csv(survey_path, col_names = headers, skip = 1)
  df_zip2county <- read_csv(zip2county_path)
  print(colnames(df_zip2county))
  # df_zip2county %<>% 
  #   select(ZIP, COUNTY) %>%
  #   rename(zip = ZIP, countyfip = COUNTY)
  df_county_occ <- read_csv(acs_countyocc_path)

  ### Clean data
  df_prep <- clean_data(df_survey, df_zip2county, df_county_occ)

  ### Run regression
  model <- regress_exit_probability(df_prep, out_path_model, out_path_tex)
  LaborCoefWage <- -100 * as.numeric(model$coef['x_wage_tthsd'])
  LaborCoefEmp <- 100 * as.numeric(model$coef['x_logsize'])
  ExportToLyx(LaborCoefWage, 1)
  ExportToLyx(LaborCoefEmp, 1)
}

### 1. Helper functions for processing survey data
## Moved to helper_functions.R

###### 2. Clean data

# (1) Filter for employed respondents with valid responses.
# (2) Create independent + dependent variables.
# This function has been moved. It can be found in helper_functions.R -- It is being used in fit_firms now as well.

###### 3. Regress model and save output

# Regress scaled probability of exit on covariates
# Saves model, outputs coefficients, and returns model.
regress_exit_probability <- function(df_prep, out_path_model, out_path_tex) {
  # These will give 0.1\alpha
  model1 <- lm(y ~ x_wage_tthsd + x_educ, 
               weights = w, data = df_prep)
  model2 <- lm(y ~ x_wage_tthsd + x_educ + x_occ_1 + x_occ_2 + x_occ_3 + x_occ_4, 
               weights = w, data = df_prep)
  model3 <- lm(y ~ x_wage_tthsd + x_educ + x_occ_1 + x_occ_2 + x_occ_3 + x_occ_4 + x_logsize + 
                   x_log_labormarket, 
               weights = w, data = df_prep)
  print(summary(model3))
  # saveRDS(model3, out_path_model)
  coeffs2tex(model1, model2, model3, out_path_tex)

  return(model3)
}

# Output model coefficients to tex file
coeffs2tex <- function(model1, model2, model3, texpath) {
  output <- capture.output(stargazer(model1, model2, model3,
          title = "",
          no.space = TRUE,
          float = FALSE,
          label = "",
          omit.stat = c("LL","ser","f","adj.rsq"),
          dep.var.caption = "",
          dep.var.labels.include = FALSE,
          intercept.top = TRUE,
          intercept.bottom = FALSE,
          omit.table.layout = "n",
          star.cutoffs = c(0.1, 0.05, 0.01),
          covariate.labels = c('Constant',
                               'Annual earnings (\\$10,000)',
                               'College degree',
                               'Occupation: service',
                               'Occupation: sales and office',
                               'Occupation: natural resources, construction, maintenance',
                               'Occupation: production, transportation, material moving',
                               'ln(firm\'s total employees in county)',
                               'ln(labor market size)'
                              )
          ))
  output = sub('^.+\\caption.+$','', output)
  output = sub('^.+\\label.+$','', output)
  cat(paste(output, collapse = "\n"), "\n", file=texpath, append=FALSE)
}

main()