rm(list=ls())

source('lib/SetGlobals.R')

library(foreach)
library(doParallel)
library(readr)
library(tidyverse)
library(haven)
library(readxl)
library(fixest)
library(data.table)
library("devtools")

replaceColVals <- function(values, replacement){
  new_values <- c()
  for(i in values){
    new_value <- replacement[i][[1]]
    if(is.na(new_value)){
      new_value <- i
    }
    new_values <- c(new_values, new_value)
  }
  return(new_values)
}

getEmployeesFIPS <-function(){
  file_root <- '/Data/airlines/raw/PassengersAirport.csv'
  
  pass_airport_df <- fread(paste0(dropbox.dir, file_root), stringsAsFactors=F, data.table=F)
  airport_loc_df <- fread(paste0(dropbox.dir,'/Data/airlines/raw/airports_to_location.csv'), stringsAsFactors=F, data.table=F)
  
  
  airports <- unique(pass_airport_df$Airport)
  airport_lons_lats <- airport_loc_df %>% group_by(AIRPORT) %>% summarise(lons=mean(LONGITUDE), lats=mean(LATITUDE)) %>% ungroup()
  
  airport_lons_lats <- airport_lons_lats[airport_lons_lats$AIRPORT %in% airports,]
  airports <- airport_lons_lats$AIRPORT
  lons <- airport_lons_lats$lons
  lats <- airport_lons_lats$lats
  

  fips <- c()
  for (i in 1:length(lats)){
    #Sample latitude and longitudes
    lat = lats[i]
    lon = lons[i]
    url <- "https://geo.fcc.gov/api/census/area?lat=%f&lon=%f&format=json"
    
    # Contruct request URL
    # There seems to be an issue with the API call on some days. Re-calling solves the issue.
    break_loop = FALSE
    while(break_loop == F){
      try({
        res <- jsonlite::fromJSON(sprintf(url, lat, lon))[["results"]][["county_fips"]]
        break_loop=T
        },silent=T
        )  
      Sys.sleep(1)
      print(i)
    }
    
    #Print FIPS code
    fips <- c(fips, unique(res))
  }
    
  airport_to_fips <- data.frame(Airport=airports, FIPS=fips)
  pass_airport_df <- fread(paste0(dropbox.dir,'/Data/airlines/raw/PassengersAirport.csv'), stringsAsFactors=F, data.table=F)
  airline_2_employee <- read_excel(paste0(dropbox.dir,'/Data/airlines/raw/airline_employee_counts.xlsx')) %>% select(-...1)
  
  pass_airport_df <- merge(pass_airport_df, airport_to_fips, by='Airport')
  names(airline_2_employee) <- c('Airline', 'Companies', 'iUSA_employees','wiki_employees','year','ratio')
  ids_2_holding <- c("QX"="AS","VX"="AS", "MQ"="AA", "PT"="AA", "OH"="AA",
                     "YV"="AA","CZ"="AA","9E"="DL","VS"="DL")
  pass_airport_df$firm_ids <- replaceColVals(pass_airport_df$firm_ids, ids_2_holding)
  
  firmids_2_airlines = c("AA"="AAL", "AS"="ALK", "DL"="DAL",
                         "F9"="FRNT","B6"="JBLU","WN"="LUV",
                         "NK"="SAVE", "OO"="SKYW", "UA"="UAL")
  
  pass_airport_df$Airline <- replaceColVals(pass_airport_df$firm_ids, firmids_2_airlines)
  
  final_df = merge(airline_2_employee, pass_airport_df, by="Airline")
  
  final_df <- final_df %>% group_by(Airline) %>% mutate(TotPassengerAcrossfirm=sum(TotPassengersByCarrier)) %>% ungroup()
  final_df['ratio_of_passengers'] <- final_df['TotPassengersByCarrier']/final_df['TotPassengerAcrossfirm']
  final_df['employees_for_firm_at_airport'] = final_df['ratio_of_passengers']*  final_df['wiki_employees']
  
  return(final_df)    
}
getInfoUSAData <- function(){
  setwd(paste0(dropbox.dir, "Data/labor/raw/InfoUSA-all"))
  #read in crosswalks
  zip_crosswalk <- read_dta(paste0(dropbox.dir, "Data/labor/raw/concordances/ZIP5_County_Crosswalk.dta"))
  cz00_eqv_v1 <- read_excel(paste0(dropbox.dir, "Data/labor/raw/concordances/cz00_eqv_v1.xls"))

  #create zipcode to CZ crosswalk
  zip_crosswalk$county<- as.numeric(zip_crosswalk$county)
  cz00_eqv_v1$FIPS<- as.numeric(cz00_eqv_v1$FIPS)
  zip_crosswalk<-left_join(zip_crosswalk, cz00_eqv_v1, by = c("county"="FIPS"))
  zip_crosswalk<- zip_crosswalk[,c("zip5","Commuting Zone ID, 2000","county" )]
  names(zip_crosswalk)<-c("ZIP.Code", "CZ", "area_fips")
  zip_crosswalk$ZIP.Code<-as.numeric(zip_crosswalk$ZIP.Code)
  rm(cz00_eqv_v1)

  #import InfoUSA data
  files <- list.files(pattern = "\\.csv$")

  #reading each file and append them to create one dataframe
  df <-  read.csv(files[1])
  for (f in files[-1]){
    temp <- read.csv(f)      # read the file
    df <- rbind(df, temp)    # append the current file
  }

  #Manually insert Sun Country Airlines Parent ID
  df$Parent.IUSA.Number[df$Company.Name=="Sun Country Airlines"]<-11111111111111111

  #merge cz data
  df<-left_join(df, zip_crosswalk)
  rm(zip_crosswalk)

  #cleaning
  df$industry<-substring(df$`Primary.NAICS`,1,3)
  df$n<-as.numeric(df$`Location.Employee.Size.Actual`)
  df <- df[which(df$n!=0),]
  fips.CZ <- df %>% select(area_fips, CZ) %>% unique()
  df$parent_id<-df$`Parent.IUSA.Number`
  df<-df %>% filter(!is.na(industry), !is.na(CZ), industry!=999) %>% select(n,CZ,industry,parent_id, area_fips)

  ## Merge airlines updated: Issue #7
  airlines.n <- getEmployeesFIPS()

  infousa_ids_of_interest <- read.csv(paste0(dropbox.dir, "Data/labor/raw/infousa_ids_of_interest.csv"))
  parent_iusa <- infousa_ids_of_interest$parent_iusa
  ticker <- infousa_ids_of_interest$ticker

  airlines.n <- left_join(airlines.n, data.frame(parent_id = parent_iusa, Airline=ticker), by="Airline")
  airlines.n$n <- round(airlines.n$employees_for_firm_at_airport, 0)
  airlines.n$area_fips <- as.numeric(airlines.n$FIPS)

  airlines.n <- left_join(airlines.n, fips.CZ, by="area_fips") %>% filter(!is.na(CZ))
  # Assuming industry for ailines is 481 as 98 percent of the entries in infoUSA that are associated to our airline tickers
  # have 481. See:
  # df.airlines <- df %>% filter(parent_id %in% unique(airlines.n$parent_id))
  airlines.n$industry <- 481
  airlines.n <- airlines.n %>% select(n, CZ, industry, parent_id, area_fips)
  df <- df %>% filter(!(parent_id %in% unique(airlines.n$parent_id)))
  df <- rbind(df, airlines.n)

  df<-df %>% group_by(industry,CZ) %>% mutate(market = cur_group_id()) %>% ungroup()
  setwd(github.dir)

  return(df)
}

main <- function(){
  data<-getInfoUSAData()
  data$area_fips<-as.character(data$area_fips)
  data$area_fips[which(nchar(data$area_fips)<5)]<-paste0("0",data$area_fips[which(nchar(data$area_fips)<5)])
  data <- data %>% group_by(area_fips, industry, parent_id) %>% summarise(employment_counts=sum(n))
  data <- data %>% filter(parent_id != 0)
  infousa_ids_of_interest <- read.csv(paste0(dropbox.dir, "Data/labor/raw/infousa_ids_of_interest.csv"))
  parent_iusa <- infousa_ids_of_interest$parent_iusa
  ticker <- infousa_ids_of_interest$ticker
  data.subset <- data %>% filter(parent_id %in% parent_iusa & employment_counts != 0)
  df <- merge(data.subset, data.frame(parent_id=parent_iusa, ticker=ticker))
  
  cbsa <- read.csv(paste0(github.dir, "labor/input/cbsatocountycrosswalk.csv"))
  cbsa$fipscounty<-as.character(cbsa$fipscounty)
  cbsa$fipscounty[which(nchar(cbsa$fipscounty)<5)]<-paste0("0",cbsa$fipscounty[which(nchar(cbsa$fipscounty)<5)])
  cbsa <- cbsa %>% select(fipscounty, msa) %>% mutate(MSA_FIPS=msa) %>% select(-msa)
  cbsa <- cbsa %>% group_by(fipscounty) %>% summarise(MSA_FIPS = mean(MSA_FIPS))
  
  df_msa <- left_join(df, cbsa,by = c("area_fips"="fipscounty"))
  # df_msa2 <- read.csv(paste0(dropbox.dir, "Data/labor/intermediate/county_ticker_employment_msa.csv"), row.names = 1) %>% select(-c(X.1, X.2))
  # df_msa2$area_fips[which(nchar(df_msa2$area_fips)<5)]<-paste0("0",df_msa2$area_fips[which(nchar(df_msa2$area_fips)<5)])
  # df_msa <- df_msa %>% arrange(parent_id, area_fips, industry, ticker)
  # df_msa2 <- df_msa2 %>% arrange(parent_id, area_fips, industry, ticker)
  
  write.csv(df_msa, paste0(dropbox.dir, "Data/labor/intermediate/county_ticker_employment_msa.csv"))
}

main()
