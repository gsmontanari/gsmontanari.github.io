# Product-weight employment counts using InfoUSA data.
# Outputs a csv of adjusted employment counts and a diagnostic plot to show the adjustment.

rm(list=ls())
source('lib/SetGlobals.R')

library(data.table)
library(xtable)
library(tidyverse)
library(ggplot2)
library(stargazer)
library(tidyr)
library(glue)
library(tidyverse)
library(magrittr)

### Copied from combined/code. 
preprocessing <- function() {
  ## 1. Preparing data ##
  # Read in names/ticker
  ticker_shortname <- fread(paste0(github.dir, 'lib/ticker_shortname.csv')) %>% select(-industry)
  
  products <- c("smartphone", "airline", "grocery", "auto", "restaurant", "cereal", "yogurt", "toothpaste", "beer", "soda", "cigarette","oil")
  
  out<-data.frame()
  for (i in seq_along(products[1:(length(products)-1)])){
    output_results<-fread(glue(paste0(github.dir,'diffprod_counterfactuals/output/{products[i]}_output.csv')))
    output_results <- output_results %>% filter(scenario=="primary")
    output_results$industry <- products[i]
    out<-rbind(out,output_results)
  }
  output_results<-fread(paste0(github.dir,'oil/output/oil_output.csv'))
  output_results <- output_results %>% filter(scenario=="primary")
  output_results$industry <- 'oil'
  out<-rbind(out,output_results)
  
  df_firm <- as.data.frame(out)
  df_firm <- merge(df_firm, ticker_shortname %>% mutate(firm=short_name) %>% select(ticker, firm))
  df_firm$industry <- paste(toupper(substring(df_firm$industry, 1,1)), substring(df_firm$industry, 2), sep="")

  df_firm$Externality_billion <- -df_firm$Externality_billion
  df_firm[,"Externality_weighted_billion"] <- df_firm[,"Externality_billion"]
  df_firm <- df_firm %>% filter(firm != "Other")# %>% mutate(LS_billion=ifelse(is.na(LS_billion), 0, LS_billion),LS_weighted_billion=ifelse(is.na(LS_weighted_billion), 0, LS_billion))#filter(is.na(LS_billion)== F)
  
  # Call in industry shapes and colors for figures
  industry.shape <-read.csv("combined/input/industry_shapes.csv")
  shape.ind <- industry.shape$X
  industry.shape <- industry.shape$x
  names(industry.shape) <- shape.ind
  industry.fill <- read.csv("combined/input/industry_fill.csv")
  fill.ind <- industry.fill$X
  industry.fill <- industry.fill$x
  names(industry.fill) <- fill.ind
  
  return(list(df_firm, industry.shape, industry.fill))
}

main <- function() {
  # (1) Get tick shapes and colors. (2) Load df_firm, which has firm revenue for specific product
  data_list <- preprocessing()
  df_firm <- data_list[[1]]
  industry.shape <- data_list[[2]]
  industry.fill <- data_list[[3]]
  
  
  # Contains MSA and employment counts for each establishment of every firm (InfoUSA)
  df_firm_info <- read_csv(paste0(dropbox.dir, 'Data/labor/intermediate/county_ticker_employment_msa.csv'))
  # Contains total revenue, total employment count, and industry category for every firm (across all products; InfoUSA)
  df_firm_totals <- read_csv(paste0(dropbox.dir, 'Data/labor/raw/ticker_revenue_employment.csv'))
  df_firm_info <- left_join(df_firm_info, df_firm_totals, by = 'ticker')
  df_firm_info <- left_join(df_firm_info, df_firm, by = 'ticker')
  
  
  df_firm_info %<>%
    group_by(ticker) %>%
    mutate(firm_emp_infousa = sum(employment_counts)) %>%
    ungroup() %>%
    # Adjust establishment employment counts by product revenue
    mutate(emp_adjusted = case_when(
      emp_thousand > -1 & revt_million > -1 & !is.na(Revenues_billion) ~ employment_counts * (1000 * emp_thousand) * (1e9 * Revenues_billion) / (1e6 * revt_million * firm_emp_infousa),
      TRUE ~ employment_counts))
  
  # Save to csv
  df_firm_info %>% 
    rename(industry = industry.x, emp_raw = employment_counts) %>%
    select(parent_id, area_fips, industry, ticker, MSA_FIPS, short_name, emp_adjusted, emp_raw) %>%
    write_csv(paste0(dropbox.dir, 'Data/labor/intermediate/county_ticker_employment_msa_adjusted.csv'))
}

main()