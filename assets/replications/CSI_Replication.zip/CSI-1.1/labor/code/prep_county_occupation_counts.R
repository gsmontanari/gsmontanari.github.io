# Creates a csv containing the employment counts for 6 occupation types
# in every US county (~3000 total). Occupation counts are initially based on 
# ACS data. Missing counties (from a full list of US counties) are imputed
# based on other counties in the same MSA (or state/nation, if MSA data still unavailable).
# Imputed counts are scaled based on each county's total 2019 employment, taken 
# from the BEA.
rm(list=ls())
source('lib/SetGlobals.R')
source('labor/code/helper_functions.R')
library(tidyverse)
library(magrittr)
library(ipumsr)

main <- function() {
  ### File paths
  # Data on occupations in each county
  inpath_acs <- paste0(dropbox.dir, 'Data/labor/raw/ACS/usa_00004.xml')
  # Data on jobs in each county
  inpath_bea <- paste0(github.dir, 'labor/input/countyjobs2019.csv')
  # List of all counties and MSAs
  inpath_countylist <- paste0(github.dir, 'labor/input/cbsatocountycrosswalk.csv')
  # Output path for occupation shares for all US counties
  outpath_county_occ <- paste0(github.dir, 'labor/output/county_occupation_counts.csv')
  
  ### Prepare data 
  # Read and clean data sources
  df_acs_sum <- clean_acs(inpath_acs)
  df_bea_countyjobs <- clean_bea(inpath_bea)
  df_countylist <- clean_countylist(inpath_countylist) %>%
    group_by(fipscounty) %>%
    filter(row_number() == 1) %>%
    ungroup()
  # Impute occupation shares for all counties using ACS data
  df_county_occ <- county_occupation_counts(df_countylist, df_acs_sum, df_bea_countyjobs)

  ### Save output
  write_csv(df_county_occ, outpath_county_occ)
}

####### 1. Clean data sources

# Return a dataframe with the employment counts of each occupation type in 
# every US county represented in the ACS dataset. Output has county fips and 
# 6 occupation types as columns, and each row is a county.
clean_acs <- function(inpath_acs) {
  # Read in data
  ddi <- read_ipums_ddi(inpath_acs)
  df_acs <- read_ipums_micro(ddi, vars = 
                            c('YEAR', 'OCC2010', 'STATEFIP', 
                            'COUNTYFIP', 'INCWAGE', 'EDUC', 'CPI99'), 
                            verbose = FALSE)
  return <- df_acs %>%
    # Get people with known county and employment
    filter(COUNTYFIP > 0,
          !is.na(INCWAGE) & INCWAGE < 999998 & INCWAGE > 0,
          !is.na(OCC2010) & OCC2010 > 0 & OCC2010 < 9800) %>% 
    # Create county fips and occupation groupings
    mutate(STATECOUNTYFIP = 1000 * STATEFIP + COUNTYFIP,
          OCC_GROUP = group_occ10(OCC2010)) %>% 
    arrange(YEAR) %>%
    # Force counties to have consistent states
    group_by(STATECOUNTYFIP) %>%
    mutate(STATE = last(STATEFIP)) %>% 
    ungroup() %>%
    # Get occupation counts in each county
    group_by(STATECOUNTYFIP, OCC_GROUP) %>%
    summarise(count = n(),
              STATE = last(STATEFIP)) %>% 
    ungroup() %>%
    # Make occupation county counts into column
    mutate(OCC0 = ifelse(OCC_GROUP == 0, count, 0),
          OCC1 = ifelse(OCC_GROUP == 1, count, 0),
          OCC2 = ifelse(OCC_GROUP == 2, count, 0),
          OCC3 = ifelse(OCC_GROUP == 3, count, 0),
          OCC4 = ifelse(OCC_GROUP == 4, count, 0)) %>% 
    # summarise occupation counts in each county
    group_by(STATECOUNTYFIP) %>% 
    summarise(OCC0_COUNT = sum(OCC0),
              OCC1_COUNT = sum(OCC1),
              OCC2_COUNT = sum(OCC2),
              OCC3_COUNT = sum(OCC3),
              OCC4_COUNT = sum(OCC4),
              STATE = last(STATE)) %>%
    ungroup()
}

# Return a dataframe with two columns: every county FIPS code and its total 2019 job count.
# NA job counts are convered to 0.
# These county job counts are used for imputing occupation counts for counties not in the ACS data.
clean_bea <- function(inpath_bea) {
  df_bea_countyjobs <- read_csv(inpath_bea)
  return <- df_bea_countyjobs %>%
    rename(STATECOUNTYFIP = GeoFips) %>%
    select(-GeoName) %>%
    mutate(STATECOUNTYFIP = as.numeric(STATECOUNTYFIP)) %>%
    filter(!is.na(STATECOUNTYFIP)) %>%
    mutate(Jobs2019 = if_else(Jobs2019 == '(NA)', 0, as.numeric(Jobs2019)))
}

# Return a a dataframe with basic info on every county in the US.
# Important columns are fipscounty and msa; the crosswalk 
# between counties, MSAs, and states will be useful for imputing 
# occupation counts to missing counties in the ACS data.
clean_countylist <- function(inpath_countylist) {
  df_countylist <- read_csv(inpath_countylist)
  df_countylist$fipscounty %<>% as.integer()
  df_countylist$msa %<>% as.integer()
  return(df_countylist)
}

####### 2. Merge datasets and impute occupation counts for missing ACS counties

# Create a dataframe of employment counts for each occupation type for every county
# in the US. Columns are county/MSA/state FIPS and 6 occupation counts.
#
# Occupation counts are taken from the ACS if available and imputed for the rest of
# the counties based on the occupation shares for other counties in the same
# MSA (or state/nation, if no counties in the MSA have ACS data). Occupation shares are then
# scaled according to total employment counts in each county from the BEA.
county_occupation_counts <- function(df_countylist, df_acs_sum, df_bea_countyjobs) {
  return <- df_countylist %>% 
    # Get list of all county, MSA, and state FIPS in US
    select(fipscounty, msa) %>%
    rename(STATECOUNTYFIP = fipscounty, 
          MSAFIP = msa) %>%
    mutate(STATEFIP = STATECOUNTYFIP %/% 1000) %>% 
    # Add occupation counts for each county from ACS
    left_join(df_acs_sum, by = c('STATECOUNTYFIP')) %>% 
    select(-c(STATE)) %>%
    # Add total employment counts for each county from BEA
    left_join(df_bea_countyjobs, by = c('STATECOUNTYFIP')) %>% # Add total employment per county
    # Impute missing occupation counts based on counties in the same MSA
    group_by(MSAFIP) %>%
    mutate(OCC0_COUNT = impute_weighted_mean(OCC0_COUNT, Jobs2019),
          OCC1_COUNT = impute_weighted_mean(OCC1_COUNT, Jobs2019),
          OCC2_COUNT = impute_weighted_mean(OCC2_COUNT, Jobs2019),
          OCC3_COUNT = impute_weighted_mean(OCC3_COUNT, Jobs2019),
          OCC4_COUNT = impute_weighted_mean(OCC4_COUNT, Jobs2019)) %>%
    ungroup() %>%
    # Impute remaining missing occupation counts based on counties in the same state
    group_by(STATEFIP) %>%
    mutate(OCC0_COUNT = impute_weighted_mean(OCC0_COUNT, Jobs2019),
        OCC1_COUNT = impute_weighted_mean(OCC1_COUNT, Jobs2019),
        OCC2_COUNT = impute_weighted_mean(OCC2_COUNT, Jobs2019),
        OCC3_COUNT = impute_weighted_mean(OCC3_COUNT, Jobs2019),
        OCC4_COUNT = impute_weighted_mean(OCC4_COUNT, Jobs2019)) %>%
    ungroup() %>%
    # Impute remaining missing occupation counts based on national counties
    mutate(OCC0_COUNT = impute_weighted_mean(OCC0_COUNT, Jobs2019),
        OCC1_COUNT = impute_weighted_mean(OCC1_COUNT, Jobs2019),
        OCC2_COUNT = impute_weighted_mean(OCC2_COUNT, Jobs2019),
        OCC3_COUNT = impute_weighted_mean(OCC3_COUNT, Jobs2019),
        OCC4_COUNT = impute_weighted_mean(OCC4_COUNT, Jobs2019))
}

main()