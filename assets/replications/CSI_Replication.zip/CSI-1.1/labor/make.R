rm(list=ls())

# Clean all output
unlink('labor/output', recursive = TRUE)
dir.create('labor/output')

# Run scripts
source('labor/code/prep_county_employment.R')
source('labor/code/adjust_employment.R')
source('labor/code/prep_county_occupation_counts.R')
source('labor/code/prep_industry_occupation_traits.R')
source('labor/code/regress_surplus_survey.R')
source('labor/code/fit_firms.R')
source('labor/code/plot_labor_welfare.R')

# Change to the root
setwd(github.dir)
