user.name = Sys.info()[7]

if (user.name == 'chuanyu') {
	dropbox.dir = '~/Dropbox/CSI/'
	github.dir  = '~/Desktop/CSI/'
}

#### Please fill in the information of different users
if (user.name == 'giovanni') {
  	dropbox.dir = '~/Dropbox/CSI/'
  	github.dir  = '/Users/giovanni/Documents/Research/CSI/'
}

if (user.name == 'hallcott') {
    dropbox.dir = 'C:/Users/hallcott.NORTHAMERICA/Dropbox/CSI/'
    github.dir  = 'C:/Users/hallcott.NORTHAMERICA/Documents/GitHub/CSI/'
}

if (user.name == 'ozaltun') {
    if(Sys.info()[1] == "Linux"){
        dropbox.dir = '/home/ozaltun/Dropbox/CSI/'
        github.dir = '/home/ozaltun/GitHub/CSI/'
    }else{
        dropbox.dir = '/Users/ozaltun/Dropbox (Personal)/CSI/' 
        github.dir  = '/Users/ozaltun/Documents/GitHub/CSI/'
    }
}
if (user.name == 'boraozaltun') {
    dropbox.dir = '/Users/boraozaltun/Dropbox (Personal)/CSI/' 
    github.dir  = '/Users/boraozaltun/GitHub/CSI/'
}

if (user.name == 'btan') {
    dropbox.dir = '/Users/btan/Dropbox/CSI/'
    github.dir  = "/Users/btan/Documents/GitHub/CSI/"
}

if (user.name == 'JimmyLin') {
    dropbox.dir = '/Users/JimmyLin/Dropbox/CSI/'
    github.dir  = '/Users/JimmyLin/GoogleDrive/EconRA/CSI_Allcott/CSI/'
}

## Setting SCC values for everybody.
scc <- 51.0 # https://www.scientificamerican.com/article/cost-of-carbon-pollution-pegged-at-51-a-ton/
axis.title.std <- 11
axis.text.std <- 9

median.income.cutoff <- 6
