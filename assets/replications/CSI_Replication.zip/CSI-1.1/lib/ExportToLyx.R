# This function exports variables to a scalar.tex file for the LyX paper.

ExportToLyx <- function(var, sig.figs, loc="paper/input/scalar.tex", var_str=NULL){
  "
  Creates or edits the file of lyx variables.
  
  Inputs: var (numeric), sig.figs (numeric), loc (optional, string)
  Output: None
  "
  if(is.null(var_str)){
    var.str <- deparse(substitute(var))
  }else{
    var.str <- var_str
  }
  var.round <- format(round(var, sig.figs), nsmall=sig.figs,big.mark=",", scientific=F)
  # Check if file exists
  if(file.exists(paste0(github.dir,loc))){
    # if it does, read in all the values
    current.file <- read.table(paste0(github.dir, loc))
    current.values <- gsub("[\\]","",current.file$V1)
    current.values <- regmatches(current.values, gregexpr("(?<=\\{)[^{}]+(?=\\})", current.values, perl=T))
  
    var.names <- unlist(current.values)[c(T,F)]
    var.values <- unlist(current.values)[c(F,T)]
    # Check if the var trying to be added is within the current file
    if(var.str %in% var.names){
      # If so edit the value
      var.values[match(var.str, var.names)] <- var.round
    }else{
      # If not add it as a new value
      var.names <- c(var.names, var.str)
      var.values <- c(var.values, var.round)
    }
  }else{
    # If file doesn't exist, create new one
    var.names <- c(var.str)
    var.values <- c(var.round)
  }
  string.list <- c()
  for(i in 1:length(var.names)){
    # Create list of output strings
    string.list <- c(string.list, string <- sprintf("\\newcommand{\\%s}{%s}", var.names[i], var.values[i]))
  }
  # Write table
  write.table(string.list, file=paste0(github.dir,loc), 
              append=F, quote=F, col.names=F, row.names=F)
}



