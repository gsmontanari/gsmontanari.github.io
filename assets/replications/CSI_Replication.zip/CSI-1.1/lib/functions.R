## This file contains common functions used throughout the repository.
library(Hmisc)
library(Matrix)
library(SQUAREM)
library(Rfast)
library(data.table)
library(abind)

data_extractor <- function(df_survey, industry_name) {
    "
    Used to prep the data for the estimation routine
    "
    df <- df_survey[industry == industry_name][, nobs := length(decision_after_increase), by = first_choice_firm][nobs >= 25][, nobs := NULL]
    df <- df[order(first_choice_firm)][, firm_ids := .GRP, by = first_choice_firm]  # create numerical ID
    excluded_firm <- unique(df[first_choice_firm == "Other", firm_ids])
    if (length(excluded_firm) == 0 ) {excluded_firm <- 0}
    largest_index <- df[firm_ids != excluded_firm, sum(decision_after_increase=="Yes") / .N, by = firm_ids][, .SD[which.min(V1), firm_ids]]

    return(
        list(df, largest_index)
    )
}

delta_iteration <- function(delta, pars, actual_shares, eta, df_aggregate, consumers_m_f, type_distribution) {
    "
    Input:
        delta: vector of length J with current guess of representative utilities delta
        pars: vector of length F + 1 + [(Theta - 1) x F] to be decomposed into sigmas and zetas. It assumes flattening of zetas with c-major order.
        eta: scalar price coefficient
        consumers_m_f: M x (F + 1) matrix of simulate unobserved consumer preferences for each firm + all inside goods
        df_aggregate: data table containing market aggregate data
        type_distribution: vector of length Theta with types' empirical distribution
    Output:
        vector of length J with udated guess of representative utilities delta
    Description:
        This function performs one iteration of the BLP fixed point to recover representative utilities delta
    "
    J <- nrow(df_aggregate)
    Fplus1 <- ncol(consumers_m_f)
    Theta <- length(type_distribution)
    M <- nrow(consumers_m_f) / Theta
    sigmas <- pars[1:Fplus1]
    zetas <- matrix(pars[-(1:Fplus1)], nrow = Theta - 1, ncol = Fplus1 - 1)

    utils_thetam_j <- calculate_utils(type_distribution, consumers_m_f, df_aggregate$firm_ids, eta, df_aggregate$prices, delta, sigmas, zetas)
    predicted_shares <- calculate_share_j(eta, utils_thetam_j, df_aggregate$prices, df_aggregate$market_ids, type_distribution)

    return( delta + (actual_shares - log(predicted_shares)) )
}

delta_inverter <- function(.pars, .eta, .df_aggregate, .consumers_m_f, .type_distribution, tol.squarem = 1e-13, tol.contraction = 1e-6, k = 2){
    "
    Input:
        pars: vector of length F + 1 + [(Theta - 1) x F] to be decomposed into sigmas and zetas. It assumes flattening of zetas with c-major order.
        eta: scalar price coefficient
        df_aggregate: data table containing market aggregate data
        consumers_m_f: M x (F + 1) matrix of simulate unobserved consumer preferences for each firm + all inside goods
        type_distribution: vector of length Theta with types' empirical distribution
        tol: scalar tolerance for the fixed point
    Output:
        vector of length J of representative utilities delta
    Description:
        This function implements the BLP fixed point and recovers representative utilities delta
        The fixed-point is accelerated using the SQUAREM algorithm
    "

    fp <- tryCatch(
        {
            fixedpoint <- squarem(par = rep(0, nrow(.df_aggregate)),
                                  pars = .pars,
                                  actual_shares = log(.df_aggregate$shares),
                                  eta = .eta,
                                  df_aggregate = .df_aggregate,
                                  consumers_m_f = .consumers_m_f,
                                  type_distribution = .type_distribution,
                                  fixptfn = delta_iteration,
                                  control = list(tol = tol.squarem, K=k))
            fixedpoint$par
        },
        error = function(e) {
            print("Squarem didn't converge: Using contraction!")
            dif <- 10
            i <- 1
            maxiter <- 2000
            delta <- rep(0, nrow(.df_aggregate))
            while (dif > tol.contraction & i < maxiter) {
                print(i)
                delta_new <- delta_iteration(delta = delta, pars = .pars, actual_shares = log(.df_aggregate$shares), eta = .eta,
                                             df_aggregate = .df_aggregate, consumers_m_f = .consumers_m_f, type_distribution = .type_distribution)
                dif <- norm_vec(delta_new - delta)
                i <- i+1
                delta <- delta_new
            }

            return(delta)
        }
    )

    return(fp)
}

generate_nu_m_f <- function(M, df_survey) {
    "
    Inputs:
        M: scalar, total number of simulated consumers that will be split across types
        df_survey: data table containing industry survey responses
    Output:
        M x (F + 1) matrix of simulated unobserved preferences for each (consumer, firm) pair, plus last column for (consumer, all inside goods)
    "

    Fplus1 <- length(unique(df_survey$firm_ids)) + 1
    simulated_draws <- matrix( rnorm(Fplus1 * M), nrow = M, ncol = Fplus1 )

    return(simulated_draws)
}

calculate_owner_j_j <- function(firm_list) {
    "
    Input:
        firm_list: vector of length J of firm_ids in market t
    Output:
        J x J ownership matrix for all products in market t
    "
    J <- length(firm_list)
    H <- matrix(0, J, J)

    for (j in 1:J) {  H[j, ] <- (firm_list == firm_list[j]) }

    return(H)
}

calculate_utils_m_j <- function(consumers_m_f, theta, firm_list, eta, prices, deltas, sigmas, zetas) {
    "
    Input:
        consumers_m_f: M x (F + 1) matrix of simulated unobserved preferences for each (consumer, firm) pair, plus one column for (consumer, all inside goods)
        theta: type of consumers whose utility is to be simulated (an integer)
        firm_list: vector of length J of firm_ids in market t
        eta: price coefficient (scalar)
        prices: vector of length J of prices
        deltas: vector of length J of representative indirect utilities for each good (delta in the literature)
        sigmas: vector of length F + 1 of parameters weighting unobserved preferences for each firm + all inside goods
        zetas: (Theta - 1) x F matrix of type-specific unobserved firm preferences
    Output:
        M x J matrix of indirect utilities (deltas - price component + individual components) for each (consumer, product) pair of type theta
    "
    M <- nrow(consumers_m_f)
    Fplus1 <- length(sigmas)
    J <- length(deltas)
    zeta_f <- c(zetas[theta, ])

    if (theta != 0) {
        utils_m_j <- matrix(deltas, nrow = M, ncol = J, byrow = T) +#- eta * matrix(prices, nrow = M, ncol = J, byrow = T) +
            matrix(zeta_f[firm_list], nrow = M, ncol = J, byrow = T) +
            consumers_m_f[, firm_list] * matrix(sigmas[firm_list], nrow = M, ncol = J, byrow = T) +
            sigmas[Fplus1] * matrix(consumers_m_f[, Fplus1], nrow = M, ncol = J)
    } else {
        utils_m_j <- matrix(deltas, nrow = M, ncol = J, byrow = T) +#- eta * matrix(prices, nrow = M, ncol = J, byrow = T) +
            consumers_m_f[, firm_list] * matrix(sigmas[firm_list], nrow = M, ncol = J, byrow = T) +
            sigmas[Fplus1] * matrix(consumers_m_f[, Fplus1], nrow = M, ncol = J)
    }

    return(utils_m_j)
}

calculate_utils <- function(type_distribution, consumers_m_f, firm_list, eta, prices, deltas, sigmas, zetas) {

    Theta <- length(type_distribution)
    M <- nrow(consumers_m_f)
    J <- length(deltas)

    consumers_m_f <- partition.matrix(consumers_m_f, rowsep = rep(M / Theta, Theta))

    utils_thetam_j <- matrix(0, nrow = 0, ncol = J)
    for (theta in 0:(length(type_distribution)-1)) {
        utils_thetam_j <- rbind(utils_thetam_j, calculate_utils_m_j(consumers_m_f[[theta + 1]], theta, firm_list, eta, prices, deltas, sigmas, zetas))
    }

    return(utils_thetam_j)
}

calculate_share_m_j <- function(eta, utils, prices, market_list) {
    "
    Input:
        eta: price coefficient (scalar)
        utils: M x J matrix of indirect utilities except for price component for each (consumer, product) pair
        prices: vector of length J of prices
        market_list: vector of market ids
    Output:
        M x J matrix of shares for each (consumer, product) pair
    "

    M <- nrow(utils)
    J <- ncol(utils)

    utils <- utils - eta * matrix(prices, nrow = M, ncol = J, byrow = T)

    p_util <- partition.matrix(utils, colsep = table(market_list))
    p_mutil <- lapply(p_util, function(x) rowMaxs(x, value=T))
    p_util <- lapply(seq_len(length(p_util)), function(x) p_util[[x]]-p_mutil[[x]])
    p_eutil <- lapply(p_util, function(x) exp(x))
    p_eutil <- lapply(seq_len(length(p_util)), function(x) p_eutil[[x]]/(rowSums(p_eutil[[x]]) + exp(-p_mutil[[x]])))

    eu <- do.call(cbind, p_eutil)

    return( eu )
}

calculate_share_m_j_nooutgood <- function(eta, utils, prices, market_list) {
    "
    Input:
        eta: price coefficient (scalar)
        utils: M x J matrix of indirect utilities except for price component for each (consumer, product) pair
        prices: vector of length J of prices
        market_list: vector of market ids
    Output:
        M x J matrix of shares for each (consumer, product) pair
    "

    M <- nrow(utils)
    J <- ncol(utils)
    utils <- utils - eta * matrix(prices, nrow = M, ncol = J, byrow = T)

    p_util <- partition.matrix(utils, colsep = table(market_list))
    p_mutil <- lapply(p_util, function(x) rowMaxs(x, value=T))
    p_util <- lapply(seq_len(length(p_util)), function(x) p_util[[x]]-p_mutil[[x]])
    p_eutil <- lapply(p_util, function(x) exp(x))
    p_eutil <- lapply(seq_len(length(p_util)), function(x) p_eutil[[x]]/rowSums(p_eutil[[x]]))

    eu <- do.call(cbind, p_eutil)

    return( eu )
}

calculate_share_j <- function(eta, utils_thetam_j, prices, market_list, type_distribution) {
    "
    Input:
        eta: price coefficient (scalar)
        utils_thetam_j: (Theta x M) x J matrix of indirect utilities except for price component for each (consumer, product) pair
        prices: vector of length J of prices
        market_list: vector of market ids
        type_distribution: vector of length Theta with types' empirical distribution
    Output:
        vector of lenght J of shares for each product
    "

    Theta <- length(type_distribution)
    M <- nrow(utils_thetam_j) / Theta

    types_weights <- rep(type_distribution, each = M)
    s_m_j <- types_weights * calculate_share_m_j(eta, utils_thetam_j, prices, market_list)
    s_j <- c(Reduce("+", lapply(partition.matrix(s_m_j, rowsep = rep(M, Theta)), colMeans)))

    return(s_j)
}

ms_iteration <- function(prices, utils_thetam_j, mc, H, eta, type_distribution, market_list) {
    "
    Input:
        prices: vector of length J of product prices
        utils_thetam_j: (Theta x N) x J matrix of utilies
        mc: vector of length J of product marginal costs
        H: J x J ownership matrix for the products in the market
        eta: scalar price coefficient
        type_distribution: vector of length Theta with types' empirical distribution
        market_list: vector of market ids
    Output:
        vector of length J with next iteration for prices using Morrow-Skerlos fixed point
    Description and notes:
        utils_thetam_j assumes that utilities are stacked by type, from the lowest to the highest;
        it also assumes that for all types we've generated the same number of consumers
    "

    Theta <- length(type_distribution)
    M <- nrow(utils_thetam_j) / Theta

    types_weights <- rep(type_distribution, each = M)
    s_m_j <- calculate_share_m_j(eta, utils_thetam_j, prices, market_list)
    s_j <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M, Theta)), colMeans)))

    # Morrow-Skerlos decomposition
    Lambda_inv <- diag(1 / (-eta * s_j), nrow = (length(1 / (-eta * s_j))))

    J <- length(prices)

    # outer product of s_m_j averaged over draws
    Gamma <- array(as.numeric(unlist(lapply(1:nrow(s_m_j), function(i) types_weights[i] * tcrossprod(s_m_j[i,])))), dim = c(J, J, nrow(s_m_j)))
    Gamma <- -eta * apply(Gamma, c(1,2), mean)

    return( mc + Lambda_inv %*% (H * Gamma) %*% (prices - mc) - Lambda_inv %*% s_j )
}

generate_equilibrium <- function(df_aggregate, eta, type_distribution, consumers_m_f, sigmas, zetas, tol = 1e-13, max_iter = 20000) {
    "
    Input:
        eta: scalar price coefficient
        type_distribution: vector of length Theta with types' empirical distribution
        consumers_m_f: M x (F + 1) matrix of simulate unobserved consumer preferences for each firm + all inside goods
        sigmas: vector of length F + 1 of parameters weighting unobserved preferences for each firm + all inside goods
        zetas: (Theta - 1) x F matrix of type-specific unobserved firm preferences

        df_aggregate: data table containing market aggregate data
        markup: scalar representing the simulated percentage price increase
    Output:

    "

    utils_thetam_j <- calculate_utils(type_distribution,
                                      consumers_m_f,
                                      df_aggregate$firm_ids,
                                      eta,
                                      df_aggregate$prices,
                                      df_aggregate$delta,
                                      sigmas,
                                      zetas)

    H <- calculate_owner_j_j(df_aggregate$firm_ids)

    dif <- 1
    k <- 1

    p <- df_aggregate$mc  # initial value

    while (dif > tol & k <= max_iter) {
        p_new <- ms_iteration(p, utils_thetam_j, df_aggregate$mc, H, eta, type_distribution, df_aggregate$market_ids)
        s_j <- calculate_share_j(eta, utils_thetam_j, p_new, df_aggregate$market_ids, type_distribution)
        Lambda <- diag(-eta * s_j, nrow = length(-eta * s_j))
        dif <- norm_vec(Lambda %*% (p - p_new))
        k <- k + 1
        p <- p_new
    }

    df_aggregate$prices <- p

    df_aggregate$shares <- calculate_share_j(eta, utils_thetam_j, df_aggregate$prices, df_aggregate$market_ids, type_distribution)

    return(df_aggregate)
}

calculate_mc_j <- function(prices, utils_thetam_j, H, eta, type_distribution, market_list) {
    "
    Input:
        prices: vector of length J of product prices
        utils_thetam_j: (Theta x M) x J matrix of utilies
        H: J x J ownership matrix for the products in the market
        eta: scalar price coefficient
        type_distribution: vector of length Theta with types' empirical distribution
        market_list: vector of length J of market IDs
    Output:
        vector of length J of marginal costs
    Notes:
        This should be used on the single market of interest
        (otherwise Gamma would be computed incorrectly over multiple markets)
    "

    Theta <- length(type_distribution)
    M <- nrow(utils_thetam_j) / Theta
    J <- length(prices)

    types_weights <- rep(type_distribution, each = M)

    # simulated shares for each consumer m and each product j
    s_m_j <- calculate_share_m_j(eta, utils_thetam_j, prices, market_list)
    # simulated average shares for each product j
    s_j <- Reduce("+", lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M, Theta)), colMeans))

    # Morrow-Skerlos decomposition
    Lambda <- diag(-eta * s_j)

    # outer product of s_m_j averaged over draws
    Gamma <- array(as.numeric(unlist(lapply(1:nrow(s_m_j), function(i) types_weights[i] * tcrossprod(s_m_j[i,])))), dim = c(J, J, nrow(s_m_j)))
    Gamma <- -eta * apply(Gamma, c(1,2), mean)

    Sigma <- Lambda - Gamma
    
    # this should be elasticity and should coincide with solve(H * Sigma) %*% s_j
    # notice I've already multiplied by the type weights above
    epsilon <- - eta * c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j * (1 - s_m_j), rowsep = rep(M, Theta)), colMeans))) * prices / s_j

    return(prices + solve(H * Sigma) %*% s_j)
    
    #return(prices + 1/epsilon)
}

calculate_producer_surplus <- function(prices, utils_thetam_j, mc, eta, type_distribution, market_list) {
    "
    Function to estimate producer surplus
    Input:
        prices: vector of length J of product prices
        utils_thetam_j: (Theta x N) x J matrix of utilies
        mc: vector of length J of product marginal costs
        eta: scalar price coefficient
        type_distribution: vector of length Theta with types' empirical distribution

    Output:
        Vector of profits for each firm
    "
    Theta <- length(type_distribution)
    M <- nrow(utils_thetam_j) / Theta
    J <- length(prices)


    s_j <- calculate_share_j(eta, utils_thetam_j, prices, market_list, type_distribution)

    profit <- s_j * (prices - mc)

    return(profit)

}

calculate_consumer_surplus <- function(eta, utils_thetam_j, type_distribution, prices, weights = NULL, internality = NULL) {
    "
    Function to estimate consumer surplus
    "
    Theta <- length(type_distribution)
    M <- nrow(utils_thetam_j) / Theta
    J <- ncol(utils_thetam_j)

    p_util <- utils_thetam_j - eta * matrix(prices, nrow = (M * Theta), ncol = J, byrow = T)

    p_mutil <- rowMaxs(p_util, value = TRUE)
    p_util <- p_util - p_mutil
    p_eutil <- exp(p_util)
    p_eutil <- log(rowSums(p_eutil) + exp(-p_mutil) ) + p_mutil

    cs_thetam <- 1/eta * p_eutil
    cs_thetam[!(is.finite(cs_thetam))] <- NA # ignore underflow issues for the moment
    cs_theta <- unlist(lapply(partition.vector(cs_thetam, sep = rep(M, Theta)), mean, na.rm = TRUE))

    if (is.null(weights) == T) {
        if (is.null(internality) == T) {
            cs <- sum(type_distribution * cs_theta)
        } else {
            s_j <- calculate_share_j(eta, utils_thetam_j, prices, rep(1, J), type_distribution)
            cs <- sum(type_distribution * cs_theta) - sum(s_j * internality)
        }
    } else {
        if (is.null(internality) == T) {
            cs <- sum(weights * type_distribution * cs_theta)
        } else {
            types_weights <- rep(type_distribution, each = M)
            rep_weights <- rep(weights, each = M)
            s_m_j <- types_weights * rep_weights * calculate_share_m_j(eta, utils_thetam_j, prices, rep(1, J))
            s_theta_j <- lapply(partition.matrix(s_m_j, rowsep = rep(M, Theta)), colMeans)
            s_j <- c(Reduce("+", s_theta_j))
            cs <- sum(weights * type_distribution * cs_theta) - sum(s_j * internality)
        }
    }

    return(cs)

}

norm_vec <- function(x){ sqrt(crossprod(x)) }  # computes Euclidean norm

plot_output <- function(output_table, industry, weighted = NULL, lowprice = NULL) {
    "
    Function to output a standardize plot of the output.
    "
    msurplus <- melt(output_table[, -2], id.vars = "firm")

    msurplus$value <- - msurplus$value
    msurplus[variable == "Externality_billion", value := - value]

    if (is.null(weighted)) {
        surplus_plot <- ggplot(data = subset(msurplus, variable == "TS_billion"),
                               aes(x = factor(firm), y = value)) +
            geom_bar(data = msurplus[variable != "TS_billion" & !(variable %like% "weighted")],
                     aes(fill = factor(variable, levels=levels(msurplus$variable)[c(1,2,3,4)])),
                     stat = "identity") +
            geom_point(aes(colour = variable),
                       shape=18,
                       size=5) +
            scale_fill_manual( values = c("CS_billion" = "#86BBD8",
                                          "OwnProfit_billion" = "#21897E",
                                          "OtherProfit_billion" = "#9FCC2E",
                                          "Externality_billion" = "#92140C"),
                               labels = c("CS_billion" = "Consumer surplus",
                                          "OwnProfit_billion" = "Profit",
                                          "OtherProfit_billion" = "Competitors' profits",
                                          "Externality_billion" = "Externality"),
                               name = "Measures",
                               breaks = levels(msurplus$variable)[c(1,2,3,4)]) +
            scale_colour_manual(values = c("TS_billion" = "#000000"),
                                labels = c("TS_billion" = "Total product market surplus"),
                                name="") +
            guides(fill = guide_legend(order=1),
                   size = guide_legend(prder=0)) +
            theme_bw() +
            theme(legend.title = element_blank(), axis.text.x = element_text(angle = 45, hjust = 1)) +
            ylab("Billion dollars per year") +
            xlab("Firm")

        if (is.null(lowprice)){
        ggsave(plot = surplus_plot,
               file = paste0("output/", industry, "_output.pdf"),
               width = 5*1.5, height = 3.5*1.5, units = "in", dpi = 128)
        } else {
            ggsave(plot = surplus_plot,
                   file = paste0("output/", industry, "_lowprice_output.pdf"),
                   width = 5*1.5, height = 3.5*1.5, units = "in", dpi = 128)    
        }
        
    }
    else {
        surplus_plot <- ggplot(data = subset(msurplus, variable == "TS_weighted_billion"),
                               aes(x = factor(firm), y = value)) +
            geom_bar(data = msurplus[variable != "TS_weighted_billion" & ((variable %like% "weighted") | (variable %like% "Externality"))],
                     aes(fill = factor(variable, levels=levels(msurplus$variable)[c(6,7,8,4)])),
                     stat = "identity") +
            geom_point(aes(colour = variable),
                       shape = 18,
                       size = 5) +
            scale_fill_manual( values = c("CS_weighted_billion" = "#86BBD8",
                                          "OwnProfit_weighted_billion" = "#21897E",
                                          "OtherProfit_weighted_billion" = "#9FCC2E",
                                          "Externality_billion" = "#92140C"),
                               labels = c("CS_weighted_billion" = "Consumer surplus",
                                          "OwnProfit_weighted_billion" = "Profit",
                                          "OtherProfit_weighted_billion" = "Competitors' profits",
                                          "Externality_billion" = "Externality"),
                               name = "Measures",
                               breaks = levels(msurplus$variable)[c(6,7,8,4)]) +
            scale_colour_manual(values = c("TS_weighted_billion" = "#000000"),
                                labels = c("TS_weighted_billion" = "Total product market surplus"),
                                name="") +
            guides(fill = guide_legend(order=1),
                   size = guide_legend(prder=0)) +
            theme_bw() +
            theme(legend.title = element_blank(), axis.text.x = element_text(angle = 45, hjust = 1)) +
            ylab("Billion dollars per year") +
            xlab("Firm")
        
        if (is.null(lowprice)) {
        ggsave(plot = surplus_plot,
               file = paste0("output/", industry, "_weighted_output.pdf"),
               width = 5*1.5, height = 3.5*1.5, units = "in", dpi = 128)
        } else {
            ggsave(plot = surplus_plot,
                   file = paste0("output/", industry, "_lowprice_weighted_output.pdf"),
                   width = 5*1.5, height = 3.5*1.5, units = "in", dpi = 128)
        }
    }

}

generate_comparison_table <- function(industry_name, df_survey, ticker_shortname, type_distribution, other = NULL){
    "
    Function to generate a standardized comparison table of estimation results.
    "
    df_aggregate <- fread(paste0(dropbox.dir,paste0("Data/dpm/intermediate/", industry_name, "_aggregate.csv")))
    df_estimates <- read_csv(paste0(github.dir, paste0('diffprod_estimation/output/', industry_name, '_estimates.csv')))
    df_mc <- fread(paste0(github.dir, paste0('diffprod_estimation/output/', industry_name, '_mc.csv')))
    
    firms_in_survey <- unique(df_estimates$ticker)[!(is.na(unique(df_estimates$ticker)))]
    
    if (industry_name != "auto" & industry_name != "airline") {
        df_aggregate <- df_aggregate[(ticker %in% firms_in_survey)][,
                                                                    .(shares = sum(shares)), 
                                                                    by = ticker][order(ticker)][, 
                                                                                                firm_ids :=  .GRP, 
                                                                                                by = ticker][,
                                                                                                             `:=`(market_ids = 1,
                                                                                                                  prices = 1,
                                                                                                                  product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
        
    }
    
    if (industry_name == "auto" | industry_name == "airline") {
        df_aggregate <- df_aggregate[!(ticker %in% firms_in_survey), ticker := "Other"][,
                                                                                        .(shares = sum(shares)), 
                                                                                        by = ticker][order(ticker)][, 
                                                                                                                    firm_ids :=  .GRP, 
                                                                                                                    by = ticker][,
                                                                                                                                 `:=`(market_ids = 1,
                                                                                                                                      prices = 1,
                                                                                                                                      product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
    }
    
    df_survey <- df_survey[industry == industry_name & !(first_choice_firm %in% firms_in_survey), 
                           first_choice_firm := "Other"][, nobs := length(decision_after_increase), 
                                                         by = first_choice_firm][nobs >= 25][, nobs := NULL]
    
    if (is.null(other) == FALSE) {
        df_survey <- df_survey[first_choice_firm != "Other"]
    }
    
    df <- df_survey[order(first_choice_firm)][industry == industry_name][,firm_ids := .GRP, by = first_choice_firm][industry == industry_name]
    
    df_survey_measures <- df[, .(`Share of purchases by below-median income consumers` = sum((income_groups == 0) * weights / sum(weights)),
                                 `Share of purchases retained after 25% price increase` = sum((decision_after_increase == "Yes") * weights / sum(weights)),
                                 industry = industry_name),
                             by = first_choice_firm]
    
    if (is.null(other)) {
        df_survey_measures[first_choice_firm == "Other", `Share of purchases retained after 25% price increase` := 0 ]
    }


    set.seed(12345)
    J <- nrow(df_aggregate)
    M <- 1000
    Fplus1 <- J + 1
    consumers_m_f <- matrix( rnorm(Fplus1 * M), nrow = M, ncol = Fplus1 )
    Theta <- length(type_distribution)

    parameters <- df_estimates %>% filter(param != "eta") %>% pull(coeff)
    eta <- df_estimates %>% filter(param == "eta") %>% pull(coeff)

    sigmas <- df_estimates %>% filter(param == "sigma") %>% pull(coeff)
    zetas <- matrix(df_estimates %>% filter(param == "zeta") %>% pull(coeff),
                    nrow = Theta - 1,
                    ncol = Fplus1 - 1)

    df_aggregate <- df_aggregate %>%
        mutate(delta = delta_inverter(parameters,
                                      eta,
                                      df_aggregate,
                                      consumers_m_f,
                                      type_distribution))

    utils_thetam_j <- calculate_utils(type_distribution,
                                      consumers_m_f,
                                      df_aggregate$firm_ids,
                                      eta,
                                      df_aggregate$prices,
                                      df_aggregate$delta,
                                      sigmas,
                                      zetas)
    
    #calculate_share_j(eta, utils_thetam_j, df_aggregate$prices, df_aggregate$market_ids, type_distribution)

    df_aggregate <- df_aggregate %>%
        mutate(mc = calculate_mc_j(prices = df_aggregate$prices,
                                   utils = utils_thetam_j,
                                   H = diag(J),
                                   eta = eta,
                                   type_distribution = type_distribution,
                                   market_list = df_aggregate$market_ids))
    
    df_aggregate$`Lerner index` <-  (df_aggregate$prices - df_aggregate$mc) / df_aggregate$prices
    
    #eqm <- generate_equilibrium(df_aggregate, eta, type_distribution, consumers_m_f, sigmas, zetas)
    #eqm$prices
    
    types_weights <- rep(type_distribution, each = M / Theta)
    
    # simulated shares for each consumer m and each product j
    s_m_j <- calculate_share_m_j(eta, utils_thetam_j, df_aggregate$prices, df_aggregate$market_ids)
    # simulated average shares for each product j
    s_j <- Reduce("+", lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M / Theta, Theta)), colMeans))
    
    # Morrow-Skerlos decomposition
    Lambda <- diag(-eta * s_j)
    
    # outer product of s_m_j averaged over draws
    Gamma <- array(as.numeric(unlist(lapply(1:nrow(s_m_j), function(i) types_weights[i] * tcrossprod(s_m_j[i,])))), dim = c(J, J, nrow(s_m_j)))
    Gamma <- -eta * apply(Gamma, c(1,2), mean)
    
    Sigma <- Lambda - Gamma
    
    # this should be elasticity and should coincide with solve(H * Sigma) %*% s_j
    # notice I've already multiplied by the type weights above
    #epsilon <- - eta * c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j * (1 - s_m_j), rowsep = rep(M, Theta)), colMeans))) * prices / s_j
    epsilon <- c(1 / (solve(diag(J) * Sigma) %*% s_j))
    
    df_aggregate$`Own-price elasticity` <-  epsilon
    
    df_aggregate <- df_aggregate %>%
        arrange(ticker) %>%
        mutate(`Random coefficient (sigma_f)` = parameters[1:J],
               `Income-firm effect (zeta_zf)` = parameters[(J + 2):(2*J + 1)])
    
    df_aggregate <- merge(df_aggregate, ticker_shortname)

    table_industry <- merge(df_survey_measures, df_aggregate, by.x = "first_choice_firm", by.y = "ticker") %>%
        rename(ticker = first_choice_firm) %>%
        select(-c(firm_ids, market_ids, product_ids, prices, delta, mc)) %>%
        relocate(c(industry, short_name, ticker, shares, 
                   `Share of purchases by below-median income consumers`, 
                   `Share of purchases retained after 25% price increase`, 
                   `Income-firm effect (zeta_zf)`, 
                   `Random coefficient (sigma_f)`,  
                   `Own-price elasticity`, 
                   `Lerner index`)) %>%
        rename(`Market share` = shares,
               firm = short_name)
    estimation_moments_by_firm <- table_industry[, .(industry, 
                                                     firm, 
                                                     `Market share`,
                                                     `Share of purchases by below-median income consumers`,
                                                     `Share of purchases retained after 25% price increase`,
                                                     `Own-price elasticity`)][firm == "Other", firm := "zzOther"]
    
    setorderv(estimation_moments_by_firm, c("industry", "firm"))
    
    estimation_moments_by_firm[firm == "zzOther", 
                                       firm := "Other"][, industry := capitalize(industry)]
    
    estimation_moments_by_firm[estimation_moments_by_firm[, .I[-1], industry]$V1, industry := ""]
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    df_mc <- merge(df_mc, ticker_shortname)[, survey_name := NULL][, ticker := NULL][short_name == "Other", short_name := "zzOther"]
    setnames(df_mc, "short_name", "firm")
    
    parameter_estimates_by_firm <- cbind(table_industry[, .(industry,
                                                            firm,
                                                            `Income-firm effect (zeta_zf)`,
                                                            `Random coefficient (sigma_f)`)][firm == "Other", firm := "zzOther"],
                                         df_aggregate[, .(delta)])
    
    parameter_estimates_by_firm <- merge(parameter_estimates_by_firm, df_mc)
    
    setorderv(parameter_estimates_by_firm, c("industry", "firm"))

    parameter_estimates_by_firm[firm == "zzOther", 
                                       firm := "Other"][, industry := capitalize(industry)]  %>%
        rename(`$\\delta (\\coloneqq \\xi + \\gamma)$` = delta,
               `$\\zeta$` = `Income-firm effect (zeta_zf)`,
               `$\\sigma$` = `Random coefficient (sigma_f)`) %>%
        relocate(c(industry, firm, `$\\delta (\\coloneqq \\xi + \\gamma)$`, `$\\zeta$`, `$\\sigma$`, mc))
    
    parameter_estimates_by_firm[parameter_estimates_by_firm[, .I[-1], industry]$V1, industry := ""]
    
    outcome <- list(table_industry, estimation_moments_by_firm, parameter_estimates_by_firm)
    
    outcome
}

compute_W_hat <- function(df_survey) {
    "
    Function to estimate W_hat
    "
    firms <- sort(unique(df_survey[first_choice_firm != "Other", first_choice_firm]))
    moments_names <- c(paste0("g_sub.", firms), "g_out", paste0("g_inc.", firms))

    df_moments <- data.table(matrix(99999, nrow = nrow(df_survey), ncol = 2 * length(firms) + 1))
    colnames(df_moments) <- moments_names

    df_survey <- cbind(df_survey, df_moments)

    for (i in seq_along(firms)) {
        # substitution moments
        df_survey[first_choice_firm == firms[i], (moments_names[i]) := (decision_after_increase=="Yes") * weights / sum(weights) * .N]
        df_survey[first_choice_firm != firms[i], (moments_names[i]) := NA]

        # income effect moments
        df_survey[income_groups == 1, (moments_names[length(firms) + 1 + i]) := ((first_choice_firm == firms[i]) * weights / sum(weights))]
        df_survey[income_groups == 0, (moments_names[length(firms) + 1 + i]) := - ((first_choice_firm == firms[i]) * weights / sum(weights))]
        df_survey[first_choice_firm == firms[i], (moments_names[length(firms) + 1 + i]) := lapply(.SD, function(x) x*.N), .SDcols = (moments_names[length(firms) + 1 + i])]
        df_survey[first_choice_firm != firms[i], (moments_names[length(firms) + 1 + i]) := NA]
    }

    # outside good moment
    df_survey[, o_weight := fcase(
        decision_after_doubling == "Yes", 1,
        decision_after_doubling == "No change", 1,
        decision_after_doubling == "25% less", 0.75,
        decision_after_doubling == "50% less", 0.5,
        decision_after_doubling == "75% less", 0.25,
        default = 0
    )]

    df_survey[, g_out := o_weight * weights / sum(weights) * .N]

    # variance-covariance matrix
    #vcv <- var(df_survey[, ..moments_names], na.rm = T, use = "pairwise.complete.obs")
    corrmat <- rcorr(as.matrix(df_survey[, ..moments_names]))
    vcv <- corrmat[[1]] / corrmat[[2]] * nrow(df_survey)
    vcv[is.na(vcv)] <- 0

    # return the inverse of the vcv matrix, the actual estimator
    solve(vcv)
}

compute_Gamma_hat <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s){
    "
    Function to estimate gamma hat.
    "
    df_aggregate$delta <- delta_inverter(pars[1:(2 * Fplus1 - 1)],
                                         pars[2 * Fplus1],
                                         df_aggregate,
                                         consumers_m_f,
                                         type_distribution,
                                         tol.squarem = 1e-13,
                                         k = 1)
    g <- c( g_sigma(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx),
            g_zeta(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s)

    )
    g <- as.matrix(g, nrow = length(g), ncol = 1)


    dg_dtheta_list <- get_dg_dtheta(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx)
    dg_ddelta_list <- get_dg_ddelta(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx)

    dg_dtheta <- dg_dtheta_list[[1]]
    ds_dtheta <- dg_dtheta_list[[2]]

    dg_ddelta <- dg_ddelta_list[[1]]
    ds_ddelta <- dg_ddelta_list[[2]]

    # m x f @ (f x f @ f x params )
    ddelta_dtheta <- -solve(ds_ddelta) %*% ds_dtheta

    dg_dpar <- dg_dtheta + dg_ddelta %*% ddelta_dtheta
    #dg_dpar[,excluded_firm_idx] <- 0

    dg_dpar[, -excluded_firm_idx]
}

compute_se <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s){
    "
    Function to get the standard errors.
    "
    # obtain weighting matrix
    W_hat <- compute_W_hat(df_survey)
    # obtain Jacobian of moment conditions
    Gamma_hat <- compute_Gamma_hat(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s)

    # compute scaling factor
    scaling_factor <- 1 + 1 / nrow(consumers_m_f)

    # compute estimator of asymptotic variance matrix
    Omega_hat <- scaling_factor *  solve(t(Gamma_hat) %*% W_hat %*% Gamma_hat)

    # extract standard errors
    se <- sqrt(diag(Omega_hat))

    se
}

plot_shapley <- function(shapley_results, industry, weighted = NULL) {
    "
     Function to plot the shapley values.
    "
    msurplus <- melt(shapley_results, id.vars = "firm")
    msurplus<-data.table(msurplus)
    msurplus[variable == "Externality_billion", value := - value]

    if (is.null(weighted)) {
        surplus_plot <- ggplot(data = subset(msurplus, variable == "TS_billion"),
                               aes(x = factor(firm), y = value)) +
            geom_bar(data = msurplus[variable != "TS_billion" & !(variable %like% "weighted")],
                     aes(fill = factor(variable, levels=levels(msurplus$variable)[c(1,2,3,4,5)])),
                     stat = "identity") +
            geom_point(aes(colour = variable),
                       shape=18,
                       size=5) +
            scale_fill_manual( values = c("CS_billion" = "#86BBD8",
                                          "OwnProfit_billion" = "#21897E",
                                          "OtherProfit_billion" = "#9FCC2E",
                                          "Externality_billion" = "#92140C"),
                               labels = c("CS_billion" = "Consumer surplus",
                                          "OwnProfit_billion" = "Profit",
                                          "OtherProfit_billion" = "Competitors' profits",
                                          "Externality_billion" = "Externality"),
                               name = "Measures",
                               breaks = levels(msurplus$variable)[c(1,2,3,5)]) +
            scale_colour_manual(values = c("TS_billion" = "#000000"),
                                labels = c("TS_billion" = "Total product market surplus"),
                                name="") +
            guides(fill = guide_legend(order=1),
                   size = guide_legend(prder=0)) +
            theme_bw() +
            theme(legend.title = element_blank(), axis.text.x = element_text(angle = 45, hjust = 1)) +
            ylab("Billion dollars per year") +
            xlab("Firm")

        ggsave(plot = surplus_plot,
               file = paste0("output/", industry, "_shapley.pdf"),
               width = 5*1.5, height = 3.5*1.5, units = "in", dpi = 128)
    }
    else {
        surplus_plot <- ggplot(data = subset(msurplus, variable == "TS_weighted_billion"),
                               aes(x = factor(firm), y = value)) +
            geom_bar(data = msurplus[variable != "TS_weighted_billion" & ((variable %like% "weighted") | (variable %like% "Externality"))],
                     aes(fill = factor(variable, levels=levels(msurplus$variable)[c(6,7,8,9,5)])),
                     stat = "identity") +
            geom_point(aes(colour = variable),
                       shape = 18,
                       size = 5) +
            scale_fill_manual( values = c("CS_weighted_billion" = "#86BBD8",
                                          "OwnProfit_weighted_billion" = "#21897E",
                                          "OtherProfit_weighted_billion" = "#9FCC2E",
                                          "Externality_billion" = "#92140C"),
                               labels = c("CS_weighted_billion" = "Consumer surplus",
                                          "OwnProfit_weighted_billion" = "Profit",
                                          "OtherProfit_weighted_billion" = "Competitors' profits",
                                          "Externality_billion" = "Externality"),
                               name = "Measures",
                               breaks = levels(msurplus$variable)[c(6,7,8,5)]) +
            scale_colour_manual(values = c("TS_weighted_billion" = "#000000"),
                                labels = c("TS_weighted_billion" = "Total product market surplus"),
                                name="") +
            guides(fill = guide_legend(order=1),
                   size = guide_legend(prder=0)) +
            theme_bw() +
            theme(legend.title = element_blank(), axis.text.x = element_text(angle = 45, hjust = 1)) +
            ylab("Billion dollars per year") +
            xlab("Firm")

        ggsave(plot = surplus_plot,
               file = paste0("output/", industry, "_weighted_shapley.pdf"),
               width = 5*1.5, height = 3.5*1.5, units = "in", dpi = 128)
    }


}
