# Change to the current working directory
setwd(paste0(github.dir, 'welfare_weights'))

# Clean all output
unlink('output', recursive = TRUE)
dir.create('output')

# Run all scripts
source('code/psz_percentile_stats.R')
source('code/compute_percentile_weights.R')
source('code/compute_profit_weight.R')

# Change to the root
setwd(github.dir)
