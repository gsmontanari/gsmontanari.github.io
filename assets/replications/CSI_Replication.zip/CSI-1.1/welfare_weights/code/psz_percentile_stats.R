# Uses Piketty-Saez-Zucman (2018; updated 2020) synthetic 2019 microdata to 
# computes the mean of each post-tax income percentile group of the following values:
#   - Tax filing status (filer)
#   - Pretax income (preinc)
#   - Posttax income (poinc)
#   - Wealth from equity assets, averaged between dividends + capital gains (hwequ)
#   - Income from equity assets (fkequ)
#   - Income from equity assets in C-corporations (fkequ_c)
#   - Corporate tax payment (corptax)
#   - The share of the total of <variable> that belongs to the percentile group (<variable>_share)
source(paste0(github.dir, 'lib/ExportToLyx.R'))
library(tidyverse)
library(readxl)
library(hrbrthemes)
library(scales)
library(magrittr)
library(haven)
library(reldist)
library(Hmisc)

main <- function() {
  # File paths
  inpath_psz19 <- paste0(dropbox.dir, 'Data/welfare_weights/raw/PikettySaezZucman/PSZ2020Dinafiles/usdina2019.dta')
  outpath_psz19 <- paste0(github.dir, 'welfare_weights/output/PSZ_percentile_stats2019.csv')
  
  df_data <- read_dta(inpath_psz19)
  df_stats <- compute_percentile_means(df_data)
  write.csv(df_stats, file = outpath_psz19, row.names = FALSE)
}

# Computes statistics for each percentile group. 
# Remove people with negative post-tax income or people with higher equity income than 
# total post-tax income.
compute_percentile_means <- function(df_data) {
  return <- df_data %>%
    select(dweght, filer, peinc, poinc, hwequ, fkequ, fkequ_c, corptax) %>%
    filter(poinc > 0, poinc > fkequ_c) %>%
    mutate(poinc_rank = wtd.rank(poinc, weights=dweght, normwt=T)) %>%
    filter(!is.na(poinc_rank)) %>%
    mutate(poinc_rank = floor(100 * poinc_rank / n()),
          poinc_rank = if_else(poinc_rank == 100, 99, poinc_rank)) %>%
    group_by(poinc_rank) %>%
    summarise(min_poinc = min(poinc),
              totalwt = sum(dweght),
              filer = wtd.mean(filer, dweght),
              peinc = wtd.mean(peinc, dweght),
              poinc = wtd.mean(poinc, dweght),
              hwequ = wtd.mean(hwequ, dweght),
              fkequ = wtd.mean(fkequ, dweght),
              fkequ_c = wtd.mean(fkequ_c, dweght),
              corptax = wtd.mean(corptax, dweght)) %>%
    mutate(totalwt = totalwt / sum(totalwt),
          peinc_share = peinc / sum(peinc),
          poinc_share = poinc / sum(poinc),
          hwequ_share = hwequ / sum(hwequ),
          fkequ_share = fkequ / sum(fkequ),
          fkequ_c_share = fkequ_c / sum(fkequ_c),
          corptax_share = corptax / sum(corptax)) 
}


main()