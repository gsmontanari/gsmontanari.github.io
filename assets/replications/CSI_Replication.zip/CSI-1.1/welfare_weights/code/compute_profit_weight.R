# Computes the average welfare weight on profits using synthetic 2019 microdata from Piketty-Saez-Zucman.
source(paste0(github.dir, 'lib/ExportToLyx.R'))
library(tidyverse)
library(readxl)
library(hrbrthemes)
library(scales)

# Computes the average profit weight and (1) exports to Lyx and (2) exports to CSV in output.
main <- function() {
  # File paths
  income_percentile_file <- 'output/percentile_welfare_weights.csv'
  # ownership_shares_file <- 'input/business_in_the_us_-_data.xlsx'
  ownership_shares_file <- paste0(github.dir, 'welfare_weights/output/PSZ_percentile_stats2019.csv')
  output_file <- 'output/welfare_weights.csv'
  # Compute welfare weight for profits
  profitweight <- profit_weight(income_percentile_file, ownership_shares_file)
  # Save results
  ExportToLyx(profitweight, 2)
  df <- data.frame(ProfitWeight = profitweight)
  df_out <- merge(df, read_csv(output_file))
  write.csv(df_out, file = output_file, row.names = FALSE)
}

# Computes the average welfare weight of profits, given mean incomes of each percentile bin
# and the ownership shares from the Piketty-Saez-Zucman 2019 synthetic microdata.
profit_weight <- function(income_percentile_file, ownership_shares_file) {
  income_percentiles <- read_csv(income_percentile_file)
  income_means <- pull(income_percentiles, PSZ_MeanIncome)
  income_weights <- pull(income_percentiles, WelfareWeight) # 1/z welfare weights
  own_shares <- read_csv(ownership_shares_file)
  shares <- pull(own_shares, fkequ_c_share)

  # Create descriptive plots
  df <- data.frame(Income_Percentile = 0:99,
                    Mean_Income = income_means,
                    Welfare_Weights = income_weights,
                    Ownership_Shares = shares,
                    Welfare_Contribution = income_weights * shares)
  plot_income <- ggplot(data = df, mapping = aes(x = Income_Percentile, y = Mean_Income)) +
                  geom_bar(stat = 'identity', color = 'grey', fill = 'blue') +
                  labs(x = 'Income percentile',
                        y = 'Mean after-tax income ($)') +
                  scale_y_continuous(labels = comma) +
                  hrbrthemes::theme_ipsum(base_family = "sans") +
                  theme(axis.title.y = element_text(hjust=0.5, size=10),
                  axis.title.x = element_text(hjust=0.5, size=10),
                  axis.text.x = element_text(angle=45, hjust=1, size=10),
                  axis.text.y = element_text(hjust=1, size=10),
                  legend.title= element_blank())
  ggsave('output/income_distribution.pdf', plot_income, height = 3.5*1.5, width = 5*1.5)
  plot_weights <- ggplot(data = df, mapping = aes(x = Income_Percentile, y = Welfare_Weights)) +
                  geom_bar(stat = 'identity', color = 'grey', fill = 'blue') +
                  labs(x = 'Income percentile',
                        y = 'Welfare weight') +
                  hrbrthemes::theme_ipsum(base_family = "sans") +
                  theme(axis.title.y = element_text(hjust=0.5, size=10),
                  axis.title.x = element_text(hjust=0.5, size=10),
                  axis.text.x = element_text(angle=45, hjust=1, size=10),
                  axis.text.y = element_text(hjust=1, size=10),
                  legend.title= element_blank())
  ggsave('output/welfare_weights_distribution.pdf', plot_weights, height = 3.5*1.5, width = 5*1.5)
  plot_shares <- ggplot(data = df, mapping = aes(x = Income_Percentile, y = 100 * Ownership_Shares)) +
                  geom_bar(stat = 'identity', color = 'grey', fill = 'blue') +
                  labs(x = 'Income percentile',
                        y = 'Percent of corporate ownership') +
                  hrbrthemes::theme_ipsum(base_family = "sans") +
                  theme(axis.title.y = element_text(hjust=0.5, size=10),
                  axis.title.x = element_text(hjust=0.5, size=10),
                  axis.text.x = element_text(angle=45, hjust=1, size=10),
                  axis.text.y = element_text(hjust=1, size=10),
                  legend.title= element_blank())
  ggsave('output/ownership_shares_distribution.pdf', plot_shares, height = 3.5*1.5, width = 5*1.5)
  plot_welfare <- ggplot(data = df, mapping = aes(x = Income_Percentile, y = Welfare_Contribution)) +
                  geom_bar(stat = 'identity', color = 'grey', fill = 'blue') +
                  labs(x = 'Income percentile',
                        y = 'Welfare of percentile group') +
                  hrbrthemes::theme_ipsum(base_family = "sans") +
                  theme(axis.title.y = element_text(hjust=0.5, size=10),
                  axis.title.x = element_text(hjust=0.5, size=10),
                  axis.text.x = element_text(angle=45, hjust=1, size=10),
                  axis.text.y = element_text(hjust=1, size=10),
                  legend.title= element_blank())
  ggsave('output/welfare_contributions_distribution.pdf', plot_welfare, height = 3.5*1.5, width = 5*1.5)

  return(income_weights %*% shares)
}

main()
