# Generates household welfare weights. Outputs two csv files.
# 1. (a) Stores the income percentile cutoffs for post-tax household income (data from 
#    Piketty-Saez-Zucman) and for pre-tax household income (data from ACS) and (b) the kappa / z
#    welfare weight for each percentile, where kappa is computed for that the mean welfare weight 
#    is 1 for the PSZ dataset.
# 2. Stores the welfare weights for above-median and below-median households from the PSZ data.
source(paste0(github.dir, 'lib/ExportToLyx.R'))
source(paste0(github.dir, 'labor/code/helper_functions.R'))
library(tidyverse)
library(reldist)

main <- function() {
  # File paths
  inpath_psz <- paste0(github.dir, 'welfare_weights/output/PSZ_percentile_stats2019.csv')
  inpath_acs <- paste0(dropbox.dir, 'Data/welfare_weights/raw/ACS20102019/usa_00006.xml')
  outfile_percentiles <- 'output/percentile_welfare_weights.csv'
  outfile_kappa <- 'output/welfare_weights.csv'
  # Read data
  df_psz <- read_csv(inpath_psz)
  ddi <- read_ipums_ddi(inpath_acs)
  df_acs <- read_ipums_micro(ddi)
  # Compute percentiles
  df_percentiles <- tibble(Percentile = 0:99)
  df_percentiles <- compute_psz_percentiles(df_percentiles, df_psz)
  df_percentiles <- compute_acs_percentiles(df_percentiles, df_acs)
  # Compute welfare weights for each percentile
  weights <- compute_psz_weights(df_percentiles)
  kappaHH <- weights$kappa
  df_percentiles <- weights$df
  binary_weights <- compute_binary_weights(df_percentiles)
  weightLowEarner <- binary_weights$LowEarnerWeight
  weightHighEarner <- binary_weights$HighEarnerWeight
  ExportToLyx(kappaHH, 3)
  ExportToLyx(weightLowEarner, 3)
  ExportToLyx(weightHighEarner, 3)
  # Save results
  write.csv(df_percentiles, file = outfile_percentiles, row.names = FALSE)
  df_kappa <- data.frame(KappaHHIncome = kappaHH, 
                         WeightLowEarner = weightLowEarner, 
                         WeightHighEarner = weightHighEarner)
  write.csv(df_kappa, file = outfile_kappa, row.names = FALSE)
}

# Compute percentile cutoffs for P-S-Z data
compute_psz_percentiles <- function(df_percentiles, df_psz) {
  df_psz %<>%
    rename(Percentile = poinc_rank,
           PSZ_MeanIncome = poinc,
           PSZ_LowBound = min_poinc
           ) %>%
    select(Percentile, PSZ_MeanIncome, PSZ_LowBound)

  df_percentiles %<>%
    left_join(df_psz, by='Percentile')

  return(df_percentiles)
}

# Compute percentile cutoffs for ACS data.
compute_acs_percentiles <- function(df_percentiles, df_acs) {
  cpi19 <- df_acs %>%
    group_by(YEAR) %>%
    summarise(cpi = median(CPI99)) %>%
    filter(YEAR == 2019) %>%
    pull('cpi')

  df_acs %<>%
    mutate(HHID = paste0(SAMPLE, SERIAL)) %>%
    group_by(HHID) %>%
    filter(row_number() == 1) %>%
    ungroup() %>%
    filter(HHINCOME >= 0 & HHWT > 0 & HHINCOME < 9999999) %>%
    mutate(HHINCOME19 = adjust_cpi(HHINCOME, CPI99, cpi19))
  
  acs_percentile_lowbounds <- reldist::wtd.quantile(df_acs$HHINCOME19, q = (df_percentiles$Percentile / 100), na.rm = TRUE, weight = df_acs$HHWT)
  df_percentiles %<>%
    add_column(ACS_LowBound = acs_percentile_lowbounds)
  
  return(df_percentiles)
}

# Compute welfare weights for each percentile group in the PSZ data.
compute_psz_weights <- function(df_percentiles) {
  kappa <- length(df_percentiles$PSZ_MeanIncome) / sum(1 / df_percentiles$PSZ_MeanIncome)
  df_percentiles %<>%
    mutate(WelfareWeight = kappa / PSZ_MeanIncome)
  return(list('kappa' = kappa, 'df' = df_percentiles))
}

# Compute welfare weights for above-median and below-median groups based on PSZ data.
compute_binary_weights <- function(df_percentiles) {
  group_means <- df_percentiles %>%
    mutate(BelowMedian = (Percentile < 50)) %>%
    group_by(BelowMedian) %>%
    summarise(MeanIncome = mean(PSZ_MeanIncome))
  kappa <- 2 / sum(1 / group_means$MeanIncome)
  group_means %<>%
    mutate(WelfareWeight = kappa / MeanIncome)
  below_median_weight <- group_means$WelfareWeight[group_means$BelowMedian]
  above_median_weight <- group_means$WelfareWeight[!group_means$BelowMedian]
  return(list('LowEarnerWeight' = below_median_weight, 'HighEarnerWeight' = above_median_weight))
}

main()