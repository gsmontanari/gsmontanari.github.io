## Code for generating the estimates for each industry.
source('../lib/SetGlobals.R')
source('../lib/functions.R')
source('code/estimation.R')
library(xtable)
library(Rfast)
library(data.table)
library(tidyverse)
library(glue)
library(nloptr)

# 0. Data loading and prepping ----
# Lets initially copy some datasets from dpm/raw to dpm/intermediate.
industries <- c("grocery", "restaurant", "smartphone")
for(industry in industries){

  root_from <- glue(paste0(dropbox.dir,'Data/dpm/raw/{industry}_aggregate.csv'))
  root_to <- glue(paste0(dropbox.dir,'Data/dpm/intermediate/{industry}_aggregate.csv'))
  file.copy(from=root_from, to=root_to, overwrite = TRUE, recursive = FALSE, copy.mode = TRUE)
}


shortnames <- fread(paste0(github.dir,'lib/ticker_shortname.csv')) %>% select(-industry)


income_group_shares <- fread(paste0(dropbox.dir,'Data/survey/intermediate/income_groups.csv'))
below.median.income <- sum(income_group_shares[1:median.income.cutoff, "shares"])
above.median.income <- sum(income_group_shares[(median.income.cutoff+1):13, "shares"])
type_distribution <- c(below.median.income, above.median.income)

df_survey <- fread(paste0(dropbox.dir, 'Data/survey/intermediate/survey_for_estimation.csv'))[income_groups <= (median.income.cutoff-1), income_groups := 0][income_groups > (median.income.cutoff-1), income_groups := 1]

scale_factor <- 0.5  # normalizing factor that defines the initial market share for the inside goods

# PHONE ----
industry_name <- "smartphone"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]]
largest_index <- db[[2]]

# aggregate market shares data set
firms_in_survey <- unique(df$first_choice_firm)

df_phone <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                  #stringsAsFactors = FALSE)[shares < 0.05, ticker := "Other"][, .(shares = sum(shares)), by = ticker][shares >= 0.05][order(ticker)][,
                  stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey), ticker := "Other"][, .(shares = sum(shares)), by = ticker][order(ticker)][,
                                                                                                                      firm_ids :=  .GRP,
                                                                                                                      by = ticker][,
                                                                                                                                   `:=`(market_ids = 1,
                                                                                                                                        prices = 1,
                                                                                                                                        product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]

# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_phone$ticker), first_choice_firm := "Other" ]

other_id <- df_phone[ticker == "Other", firm_ids]

minimizer <- run_estimation(df, df_phone, largest_index, other_id=other_id, type_distribution = type_distribution, seed = 1)
export_estimation_results(minimizer, industry_name, df_phone, shortnames, type_distribution)

# AIRLINE ----
industry_name <- "airline"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]] #[first_choice_firm != "Other"]
largest_index <- db[[2]]

firms_in_survey <- unique(df$first_choice_firm)

df_airline <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                       stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey),
                                                 ticker := "Other"][,
                                                                    .(shares = sum(shares)),
                                                                    by = ticker][order(ticker)][,
                                                                                                firm_ids :=  .GRP,
                                                                                                by = ticker][,
                                                                                                             `:=`(market_ids = 1,
                                                                                                                  prices = 1,
                                                                                                                  product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]

# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_airline$ticker), first_choice_firm := "Other" ]
other_id <- df_airline[ticker == "Other", firm_ids]

minimizer <- run_estimation(df, df_airline, largest_index, other_id = other_id, type_distribution = type_distribution)
export_estimation_results(minimizer, industry_name, df_airline, shortnames, type_distribution)

# RESTAURANT ----
industry_name <- "restaurant"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]]
largest_index <- db[[2]]

firms_in_survey <- unique(df$first_choice_firm)

df_restaurant <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                       stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey),
                                                                ticker := "Other"][,
                                                                                   .(shares = sum(shares)),
                                                                                   by = ticker][order(ticker)][,
                                                                                                               firm_ids :=  .GRP,
                                                                                                               by = ticker][,
                                                                                                                            `:=`(market_ids = 1,
                                                                                                                                 prices = 1,
                                                                                                                                 product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_restaurant$ticker), first_choice_firm := "Other" ]
other_id <- df_restaurant[ticker == "Other", firm_ids]

minimizer <- run_estimation(df, df_restaurant, largest_index, other_id = other_id,  type_distribution = type_distribution)
export_estimation_results(minimizer, industry_name, df_restaurant, shortnames, type_distribution)

# GROCERY ----
industry_name <- "grocery"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]]
largest_index <- db[[2]]

firms_in_survey <- unique(df$first_choice_firm)

df_grocery <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                       stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey),
                                                 ticker := "Other"][,
                                                                    .(shares = sum(shares)),
                                                                    by = ticker][order(ticker)][,
                                                                                                firm_ids :=  .GRP,
                                                                                                by = ticker][,
                                                                                                             `:=`(market_ids = 1,
                                                                                                                  prices = 1,
                                                                                                                  product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
other_id <- df_grocery[ticker == "Other", firm_ids]
# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_grocery$ticker), first_choice_firm := "Other" ][first_choice_firm == "Other", firm_ids := other_id]



minimizer <- run_estimation(df, df_grocery, largest_index, other_id = other_id,  type_distribution = type_distribution)
export_estimation_results(minimizer, industry_name, df_grocery, shortnames, type_distribution)

# AUTO ----
industry_name <- "auto"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]]
largest_index <- db[[2]]

firms_in_survey <- unique(df$first_choice_firm)

df_auto <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                       stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey),
                                                 ticker := "Other"][,
                                                                    .(shares = sum(shares)),
                                                                    by = ticker][order(ticker)][,
                                                                                                firm_ids :=  .GRP,
                                                                                                by = ticker][,
                                                                                                             `:=`(market_ids = 1,
                                                                                                                  prices = 1,
                                                                                                                  product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_auto$ticker), first_choice_firm := "Other" ]

other_id <- df_auto[ticker == "Other", firm_ids]

other_firms <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                     stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey)][, .(shares = sum(shares)),
                                               by = ticker][, ticker]

other_income <- fread(paste0(dropbox.dir,'Data/autos/intermediate/autos_nhts_aggregate.csv'),
                     stringsAsFactors = FALSE)[ticker %in% other_firms, lapply(.SD, mean)][is.na(ticker), ticker := "Other"]

sample_s_auto <- merge(
    rbind(fread(paste0(dropbox.dir,'Data/autos/intermediate/autos_nhts_aggregate.csv'),
          stringsAsFactors = FALSE), other_income),
    df_auto[, .(ticker, firm_ids)]
)[,
  s_sample_auto := (n_income_1 / sum(n_income_1)) - (n_income_0 / sum(n_income_0))][order(firm_ids)][, s_sample_auto]

minimizer <- run_estimation(df, df_auto, largest_index, sample_s = sample_s_auto, other_id = other_id,  type_distribution = type_distribution) # final value = 0
export_estimation_results(minimizer, industry_name, df_auto, shortnames, type_distribution)

# BEER ----
industry_name <- "beer"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]]
largest_index <- db[[2]]

firms_in_survey <- unique(df$first_choice_firm)

df_beer <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                    stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey),
                                              ticker := "Other"][,
                                                                 .(shares = sum(shares)),
                                                                 by = ticker][order(ticker)][,
                                                                                             firm_ids :=  .GRP,
                                                                                             by = ticker][,
                                                                                                          `:=`(market_ids = 1,
                                                                                                               prices = 1,
                                                                                                               product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_beer$ticker), first_choice_firm := "Other" ]

other_id <- df_beer[ticker == "Other", firm_ids]

minimizer <- run_estimation(df, df_beer, largest_index, other_id = other_id,  type_distribution = type_distribution)
export_estimation_results(minimizer, industry_name, df_beer, shortnames, type_distribution)

# CEREAL ----
industry_name <- "cereal"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]]
largest_index <- db[[2]]

firms_in_survey <- unique(df$first_choice_firm)

df_cereal <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                 stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey),
                                           ticker := "Other"][,
                                                              .(shares = sum(shares)),
                                                              by = ticker][order(ticker)][,
                                                                                          firm_ids :=  .GRP,
                                                                                          by = ticker][,
                                                                                                       `:=`(market_ids = 1,
                                                                                                            prices = 1,
                                                                                                            product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_cereal$ticker), first_choice_firm := "Other" ]

other_id <- df_cereal[ticker == "Other", firm_ids]

minimizer <- run_estimation(df, df_cereal, largest_index,  other_id = other_id,  type_distribution = type_distribution, seed = 33)
export_estimation_results(minimizer, industry_name, df_cereal, shortnames, type_distribution)

# SODA ----
industry_name <- "soda"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]]
largest_index <- db[[2]]

firms_in_survey <- unique(df$first_choice_firm)

df_soda <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                   stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey),
                                             ticker := "Other"][,
                                                                .(shares = sum(shares)),
                                                                by = ticker][order(ticker)][,
                                                                                            firm_ids :=  .GRP,
                                                                                            by = ticker][,
                                                                                                         `:=`(market_ids = 1,
                                                                                                              prices = 1,
                                                                                                              product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_soda$ticker), first_choice_firm := "Other" ]

other_id <- df_soda[ticker == "Other", firm_ids]

minimizer <- run_estimation(df, df_soda, largest_index,  other_id = other_id,  type_distribution = type_distribution) # final value = 0
export_estimation_results(minimizer, industry_name, df_soda, shortnames, type_distribution)

# CIGARETTE ----
industry_name <- "cigarette"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]]
largest_index <- db[[2]]

firms_in_survey <- unique(df$first_choice_firm)

df_cigarette <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                 stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey),
                                           ticker := "Other"][,
                                                              .(shares = sum(shares)),
                                                              by = ticker][order(ticker)][,
                                                                                          firm_ids :=  .GRP,
                                                                                          by = ticker][,
                                                                                                       `:=`(market_ids = 1,
                                                                                                            prices = 1,
                                                                                                            product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_cigarette$ticker), first_choice_firm := "Other" ]

other_id <- df_cigarette[ticker == "Other", firm_ids]

minimizer <- run_estimation(df, df_cigarette, largest_index,  other_id = other_id,  type_distribution = type_distribution)
export_estimation_results(minimizer, industry_name, df_cigarette, shortnames, type_distribution)


# TOOTHPASTE ----
industry_name <- "toothpaste"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]]
largest_index <- db[[2]]

firms_in_survey <- unique(df$first_choice_firm)

df_toothpaste <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                      stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey),
                                                ticker := "Other"][,
                                                                   .(shares = sum(shares)),
                                                                   by = ticker][order(ticker)][,
                                                                                               firm_ids :=  .GRP,
                                                                                               by = ticker][,
                                                                                                            `:=`(market_ids = 1,
                                                                                                                 prices = 1,
                                                                                                                 product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_toothpaste$ticker), first_choice_firm := "Other" ]

other_id <- df_toothpaste[ticker == "Other", firm_ids]

minimizer <- run_estimation(df, df_toothpaste, largest_index,  other_id = other_id, type_distribution = type_distribution, seed = 4444) # final value = 0
export_estimation_results(minimizer, industry_name, df_toothpaste, shortnames, type_distribution)


# YOGURT ----
industry_name <- "yogurt"

db <- data_extractor(df_survey, industry_name)
df <- db[[1]]
largest_index <- db[[2]]

firms_in_survey <- unique(df$first_choice_firm)

df_yogurt <- fread(paste0(dropbox.dir,'Data/dpm/intermediate/', industry_name, '_aggregate.csv'),
                       stringsAsFactors = FALSE)[!(ticker %in% firms_in_survey),
                                                 ticker := "Other"][,
                                                                    .(shares = sum(shares)),
                                                                    by = ticker][order(ticker)][,
                                                                                                firm_ids :=  .GRP,
                                                                                                by = ticker][,
                                                                                                             `:=`(market_ids = 1,
                                                                                                                  prices = 1,
                                                                                                                  product_ids = firm_ids)][, shares := shares / sum(shares) * scale_factor]
# filter survey responses appropriately
df[industry == industry_name & !(first_choice_firm %in% df_yogurt$ticker), first_choice_firm := "Other" ]

other_id <- df_yogurt[ticker == "Other", firm_ids]

minimizer <- run_estimation(df, df_yogurt, largest_index,  other_id = other_id,  type_distribution = type_distribution, seed = 3333)
export_estimation_results(minimizer, industry_name, df_yogurt, shortnames, type_distribution)
