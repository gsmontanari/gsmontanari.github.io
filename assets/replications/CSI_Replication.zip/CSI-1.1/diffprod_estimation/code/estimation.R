## Helper functions for generate_estimates
source(paste0(github.dir, "lib/functions.R"))

g_sigma.sim <- function(sigmas, zetas, eta, type_distribution, consumers_m_f, df_aggregate, df_survey, markup = 0.25) {
  "
    Compute the simulation side of sigma moments.
    Input:
        sigmas: vector of length F + 1 of parameters weighting unobserved preferences for each firm + all inside goods
        xis: vector of length F of products unobserved characteristics (here we posit one product per firm)
        zetas: (Theta - 1) x F matrix of type-specific unobserved firm preferences
        eta: scalar price coefficient
        type_distribution: vector of length Theta with types' empirical distribution
        consumers_m_f: M x (F + 1) matrix of simulate unobserved consumer preferences for each firm + all inside goods
        df_survey: data frame including survey responses
        markup: scalar representing the simulated percentage price increase
    Output:
        F x 4 data frame with initial shares and post-increase shares for every firm
    Description:
        This function computes the simulated part of the moment based on parameters
        NOTE: the outside good share is repeated on every row of the output table
    "

  J <- ncol(consumers_m_f)-1
  Theta <- length(type_distribution)
  M <- nrow(consumers_m_f) / Theta
  firm_list <- df_aggregate$firm_ids
  deltas <- df_aggregate$delta
  prices <- df_aggregate$prices
  market_list <- df_aggregate$market_ids  # assume all goods belong to the same market

  utils_thetam_j <- calculate_utils(type_distribution, consumers_m_f, firm_list, eta, prices, deltas, sigmas, zetas)
  initial_shares_j <- calculate_share_j(eta, utils_thetam_j, prices, market_list, type_distribution)

  firm_shares <- data.table(matrix(ncol = 4, nrow = 0))
  post_doubling_inside_share <- sum(calculate_share_j(eta, utils_thetam_j, 2 * prices, market_list, type_distribution))  # same for every firm

  for (firm in firm_list) {
    firm_initial_share <- initial_shares_j[firm]
    increased_prices <- prices + markup * prices * (firm_list == firm)
    firm_post_increase_share <- calculate_share_j(eta, utils_thetam_j, increased_prices, market_list, type_distribution)[firm]

    firm_shares <- rbindlist(list(firm_shares, list(firm, firm_initial_share, firm_post_increase_share, post_doubling_inside_share)))
  }

  colnames(firm_shares) <- c("firm_ids", "initial_shares", "post_increase_firm_shares", "post_doubling_inside_share")

  return(firm_shares[order(firm_ids)])
}

g_sigma <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=NULL, drop.zeta.m=NULL, drop.s.o.m=NULL, drop.s.m=NULL){
  "
    Compute sigma moments. 
    Input:
        pars: vector of length F + 1 + [(Theta - 1) x F] + 1 + J to be decomposed into sigmas, zetas, eta, xis. It assumes flattening of xis with c-major order.
        type_distribution: vector of length Theta with types' empirical distribution
        consumers_m_f: M x (F + 1) matrix of simulate unobserved consumer preferences for each firm + all inside goods
        df_survey: data table containing industry survey responses
    Output:
        vector of length F with firm substitution moments; order is by firm ID
    Description:
        This function computes the substitution moment we think is mainly identifying
        the RC firm standard deviations
        for survey-only markets
    "

  Fplus1 <- ncol(consumers_m_f)
  Theta <- length(type_distribution)
  sigmas <- pars[1:Fplus1]
  zetas <- matrix(pars[(Fplus1+1):(2 * Fplus1 - 1)], nrow = Theta - 1, ncol = Fplus1 - 1)
  eta <- pars[2 * Fplus1]
  if(is.null(other_id)==F){
    firm_shares <- g_sigma.sim(sigmas, zetas, eta, type_distribution, consumers_m_f, df_aggregate, df_survey)[firm_ids == other_id, post_increase_firm_shares := 0]
  }else{
    firm_shares <- g_sigma.sim(sigmas, zetas, eta, type_distribution, consumers_m_f, df_aggregate, df_survey)
  }
  if(is.null(other_id)==F){
    sample_f_sub <- df_survey[, sum((decision_after_increase == "Yes") * weights / sum(weights)) , by = firm_ids][firm_ids == other_id, V1 := 0][, V1]
  }else{
    sample_f_sub <- df_survey[, sum((decision_after_increase == "Yes") * weights / sum(weights)) , by = firm_ids][, V1]
  }
  df_survey[, o_weight := fcase(
    decision_after_doubling == "Yes", 1,
    decision_after_doubling == "No change", 1,
    decision_after_doubling == "25% less", 0.75,
    decision_after_doubling == "50% less", 0.5,
    decision_after_doubling == "75% less", 0.25,
    default = 0
  )]

  sample_out <- df_survey[, sum(o_weight * weights / sum(weights))]
  moment_sub <- firm_shares[, post_increase_firm_shares / initial_shares] - sample_f_sub
  initial_inside_share <- sum(firm_shares$initial_shares)
  moment_out <- firm_shares[1, post_doubling_inside_share] / initial_inside_share - sample_out
  if(is.null(drop.s.o.m) ==F){
    moment <- c(moment_sub)
  }else if(is.null(drop.s.m) == F){
    moment <- c(moment_out)
  }else{
    moment <- c(moment_sub, moment_out)
  }
  return(moment)
}

g_zeta.sim <- function(sigmas, zetas, eta, type_distribution, consumers_m_f, df_aggregate, df_survey) {
  "
    Compute simulation side of the zeta moments.
    Input:
        sigmas: vector of length F + 1 of parameters weighting unobserved preferences for each firm + all inside goods
        zetas: (Theta - 1) x F matrix of type-specific unobserved firm preferences
        xis: vector of length F of products unobserved characteristics (here we posit one product per firm)
        eta: scalar price coefficient
        type_distribution: vector of length Theta with types' empirical distribution
        consumers_m_f: M x (F + 1) matrix of simulate unobserved consumer preferences for each firm + all inside goods
        df_survey: data table containing survey response data
    Output:
        F x (Theta + 1) data frame with difference in average consumption by income group wrt lowest income, plus firm shares
    Description:
        This function computes the simulated part of the moment based on parameters
    "
  J <- length(sigmas) - 1
  Theta <- length(type_distribution)
  M <- nrow(consumers_m_f)

  df_aggregate <- df_aggregate[order(firm_ids)]
  firm_list <- df_aggregate$firm_ids
  deltas <- df_aggregate$delta
  prices <- df_aggregate$prices
  market_list <- df_aggregate$market_ids

  # V without price
  # Potential issue with this:
  ## When eta changes, the change in firm_shares is zero since we are subtracting the new eta here and adding it.
  ## I think the fix requires that eta*prices is removed outside of the optimization from the delta values.
  utils_thetam_j <- calculate_utils(type_distribution, consumers_m_f, firm_list, eta, prices, deltas, sigmas, zetas)

  # S_ij_no_outside: Shares if there was no outside.
  s_m_j <- rep(type_distribution, each = M / Theta) * calculate_share_m_j(eta, utils_thetam_j, prices, market_list)
  s_theta_j <- do.call(rbind, lapply(partition.matrix(s_m_j, rowsep = rep(M / Theta, Theta)), colMeans))
  s_theta_j <- s_theta_j/sum(s_theta_j)

  # print(s_theta_j)
  firm_shares <- matrix(ncol = Theta, nrow = 0)
  for (firm in firm_list) {
    firm_avg_share <- s_theta_j[, firm]
    firm_relative_share <- firm_avg_share[2] - firm_avg_share[1]
    firm_shares <- rbind(firm_shares, c(firm, firm_relative_share))
  }

  firm_shares <- data.frame(firm_shares)
  colnames(firm_shares) <- c("firm_ids", paste0("income_groups", 1:(Theta-1)))

  return(firm_shares)
}

g_zeta <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s) {
  "
    Compute the zeta moment.
    Input:
        pars: vector of length F + 1 + F + 1 + J to be decomposed into sigmas, zetas, eta, xis. It assumes flattening of xis with c-major order.
        eta: scalar price coefficient
        type_distribution: vector of length Theta with types' empirical distribution
        consumers_m_f: M x (F + 1) matrix of simulate unobserved consumer preferences for each firm + all inside goods
        df_survey: data table containing industry survey responses
    Output:
        vector of length 2 x F with firm intercept moments and product moments; order is by firm ID
    Description:
        This function computes the intercept moments we think are mainly identifying
        the  income-firm effect
    "

  Fplus1 <- ncol(consumers_m_f)
  Theta <- length(type_distribution)
  sigmas <- pars[1:Fplus1]
  zetas <- matrix(pars[(Fplus1+1):(2 * Fplus1 - 1)], nrow = Theta - 1, ncol = Fplus1 - 1)
  eta <- pars[2 * Fplus1]

  firm_shares <- g_zeta.sim(sigmas, zetas, eta, type_distribution, consumers_m_f, df_aggregate, df_survey)

  moment <- c(data.matrix(firm_shares[, 2])) - sample_s

  return(moment)
}

SMM <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s,other_id=NULL, drop.zeta.m=NULL,drop.s.o.m=NULL, drop.s.m=NULL) {
  "
    Get the SMM objective.
    Input:
        pars: vector of length F + 1 + [1 x F] + 1 + J to be decomposed into sigmas, zetas, eta, xis. It assumes flattening of xis with c-major order.
        type_distribution: vector of length Theta with types' empirical distribution
        consumers_m_f: M x (F + 1) matrix of simulate unobserved consumer preferences for each firm + all inside goods
        df_survey: data table containing industry survey responses
    Output:
        vector of length F+1 + F + 1 + F with firm intercept moments; order is by firm ID
    Description:
        This function computes the SMM estimator
        for survey-only markets
    "
  Fplus1 <- ncol(consumers_m_f)
  if(is.null(drop.s.m) == F){
    pars[1:(Fplus1-1)] <- drop.s.m[1:(Fplus1-1)]
    pars[2 * Fplus1] <- drop.s.m[(Fplus1)]
  }else{
    pars[excluded_firm_idx] <- 0 # Need to set this here or else gradient with respect to delta is not zero anymore
  }

  if(is.null(drop.zeta.m) == F){
    pars[(Fplus1+1):(2 * Fplus1 - 1)] <- drop.zeta.m
  }
  if(is.null(drop.s.o.m) == F){
    pars[(Fplus1)] <- drop.s.o.m
  }

  if(is.null(other_id) == F){
    pars[other_id] <- mean(abs(pars[-other_id][1:(Fplus1 - 2)]))
  }
  
  pars[excluded_firm_idx] <- 0

  # print(pars)
  df_aggregate$delta <- delta_inverter(pars[1:(2 * Fplus1 - 1)],
                                       pars[2 * Fplus1],
                                       df_aggregate,
                                       consumers_m_f,
                                       type_distribution,
                                       tol.squarem = 1e-13,
                                       k = 1)
  if(is.null(drop.zeta.m) == F){
    g <- c(g_sigma(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=other_id, drop.zeta.m=drop.zeta.m,drop.s.o.m=drop.s.o.m, drop.s.m=drop.s.m))
  }else{
    if((is.null(drop.s.m) == F) & (is.null(drop.s.o.m) == F)){
      g <- c(g_zeta(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s))
    }else{
      g <- c( g_sigma(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=other_id, drop.s.o.m=drop.s.o.m, drop.s.m=drop.s.m),
              g_zeta(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s))
    }

  }

  g <- as.matrix(g, nrow = length(g), ncol = 1)
  # print(dim(g))
  #W <- compute_W_hat(df_survey)
  W <- diag(length(g)) # if want to assume identity as weighting matrix
  #print(df_aggregate$delta)
  
  # uncomment the following line to look at each moment
  #print(g)
  return(t(g) %*% W %*% g)
}

nested_routine <- function(parameters_0, type_distribution, consumers_m_f, df_aggregate, excluded_firm_idx,  df_survey, other_id=NULL, sample_s = NULL,
                           drop.zeta.m=NULL,drop.s.o.m=NULL, drop.s.m=NULL){
  "
    Nested optimization routine for the SMM.
    Input:
        parameters_0: vector of length F + 1 + [(Theta - 1) x F] to be decomposed into sigmas and zetas. It assumes flattening of zetas with c-major order.
        type_distribution: vector of length Theta with income groups empirical distribution
        consumers_m_f: M x (F + 1) matrix of simulate unobserved consumer preferences for each firm + all inside goods
        df_aggregate: data table containing market aggregate data
        df_survey: data table containing industry survey responses
        toler: scalar tolerance parameter on the routine
        sample_s: option to provide the sample shares for each firm theta -- if left as NULL, will be calculated using survey data
        detailed: if output should contain detailed (list containing parameters and eta).
    Output:
        vector of length F + 1 + [(Theta - 1) x F] of estimated parameters via SMM
    Description:
        Implements the estimation strategy
    "
  if(is.null(sample_s)){
    shares_f_theta_a <- df_survey[, sum(weights * income_groups), by = firm_ids][, .(V1)] / df_survey[, sum(weights)]
    shares_f_theta_b <- df_survey[, sum(weights * (1 - income_groups)), by = firm_ids][, .(V1)] / df_survey[, sum(weights)]
    sample_s <- (shares_f_theta_a - shares_f_theta_b)[, V1]
  }

  Fplus1 <- ncol(consumers_m_f)
  current_parameters <- parameters_0

  if(is.null(drop.s.m) == F){
    current_parameters[1:(Fplus1-1)] <- drop.s.m[1:(Fplus1-1)]
    current_parameters[2 * Fplus1] <- drop.s.m[(Fplus1)]
  }
  
  if(is.null(drop.zeta.m) == F){
    current_parameters[(Fplus1+1):(2 * Fplus1 - 1)] <- drop.zeta.m
  }
  if(is.null(drop.s.o.m) == F){
    current_parameters[Fplus1] <- drop.s.o.m
  }
  if(is.null(other_id) == F){
    current_parameters[other_id] <- mean(abs(current_parameters[-other_id][1:(Fplus1 - 2)]))
  }
  
  #current_parameters[excluded_firm_idx] <- 0
  
  potentials_parameters <- vector("list", length(firms_in_survey))
  exit_status <- numeric(length(firms_in_survey)) + 100
  objective_values <- numeric(length(firms_in_survey)) + 100
  
  opts <- list("algorithm"="NLOPT_LD_LBFGS", "xtol_rel"=1.0e-8)
  for (exclude_id in 1:length(firms_in_survey)) {
    current_parameters[exclude_id] <- 0
    
    minim <- nloptr( x0=current_parameters, 
                     eval_f=SMM,
                     eval_grad_f=jacobian_SMM,
                     opts=opts,
                     type_distribution = type_distribution,
                     consumers_m_f = consumers_m_f,
                     df_aggregate = df_aggregate,
                     df_survey = df_survey,
                     excluded_firm_idx = exclude_id,
                     other_id = other_id,
                     drop.zeta.m = drop.zeta.m,
                     drop.s.o.m = drop.s.o.m, drop.s.m = drop.s.m,
                     sample_s = sample_s)
    
    potentials_parameters[[exclude_id]] <- minim$solution
    exit_status[exclude_id] <- minim$status
    objective_values[exclude_id] <- minim$objective
  }
  
  print(potentials_parameters)
  print(exit_status)
  print(objective_values)
  
  optimum <- which.min(objective_values)
  current_parameters <- potentials_parameters[[optimum]]
  
  if( is.null(other_id) == F){
    current_parameters[other_id] <- mean(abs(current_parameters[-other_id][1:(Fplus1 - 2)]))
  }
  
  # set to zero the sigma we normalized in the optimal solution that was picked
  # relevant to do only if the optimum coincides with the "other" firm id  
  current_parameters[optimum] = 0

  print(c("SMM: ", current_parameters[1:(2 * Fplus1 - 1)]))
  print(paste("Eta:", current_parameters[2 * Fplus1]))

  return(current_parameters)
}

run_estimation <- function(df_survey, df_aggregate, excluded_firm_idx,  type_distribution,other_id=NULL, sample_s = NULL, drop.zeta.m=NULL,drop.s.o.m=NULL, drop.s.m=NULL, seed = NULL){
  "
  Function to run estimation.
  "
  # parameters
  M <- 1000  # total number of consumers to be simulated
  if (is.null(seed)) {
    set.seed(1)
  } else
  { set.seed(seed)}
  consumers_m_f <-  generate_nu_m_f(M, df_survey)  # simulated consumers to be used during optimization
  Fplus1 <- ncol(consumers_m_f)
  print(2*Fplus1)
  # initial conditions and estimation
  if (is.null(seed)) {
    set.seed(1)
  } else
  { set.seed(seed)}
  pars0 <- abs(rnorm(2 * Fplus1)) # initial conditions for the estimation
  minimizer <- nested_routine(parameters_0 = pars0,
                              type_distribution = type_distribution,
                              consumers_m_f = consumers_m_f,
                              df_aggregate = df_aggregate,
                              excluded_firm_idx = excluded_firm_idx,
                              other_id = other_id,
                              df_survey = df_survey,
                              sample_s = sample_s,
                              drop.zeta.m=drop.zeta.m,
                              drop.s.o.m = drop.s.o.m, drop.s.m = drop.s.m
  )
  
  # consider the absolute value of sigma for ease of interpretation
  results = minimizer
  results[1:Fplus1] = abs(results[1:Fplus1])
  
  results
}

export_estimation_results <- function(values, industry, df_aggregate, shortnames, type_distribution){
  "
  Function to export estimation routines.
  "
  Fplus1 <- nrow(df_aggregate) + 1  # total number of firms + inside good

  # export estimates in CSV format for internal use
  estimates <- data.table(
    param = c(
      rep("sigma", Fplus1),
      rep("zeta", Fplus1 - 1),
      "eta"
    ),
    ticker = c(
      df_aggregate[order(firm_ids), ticker],
      "",
      df_aggregate[order(firm_ids), ticker],
      ""
    ),
    coeff = minimizer
  )

  # assign to the "Other" firm the average sigma of non-"Other" firms
  avg_sigma <- estimates[param == "sigma" & ticker != "Other" & ticker != "", mean(abs(coeff))]
  estimates[param == "sigma" & ticker == "Other", coeff := avg_sigma]

  fwrite(estimates, paste0("output/", industry, "_estimates.csv"))

  # export estimates in .tex format for the paper

  estimates[, idx := .GRP, by = 1:nrow(estimates)]
  estimates_tex <- merge(estimates, shortnames, all.x = TRUE)
  setnames(estimates_tex, old = c("short_name", "coeff"), new = c("firm", "Value"))
  estimates_tex[ticker == "", firm := "inside goods"]

  estimates_tex[param == "zeta", Description := paste("Above-median income $\\times$", firm, "($\\eta \\zeta_{zf}$)")]
  estimates_tex[param == "sigma", Description := paste("Standard deviation of", firm, "random coefficient ($\\eta \\sigma_{f}$)")]
  estimates_tex[param == "eta", Description := "Price coefficient ($\\eta$)"]

  export_estimation_mc(df_aggregate, industry, type_distribution, estimates)

  results_for_export <- estimates_tex[order(idx)][!largest_index, .(Description, Value)]

  print.xtable(xtable(results_for_export,
                      digits = 2),
               type = "latex",
               file = paste0("output/", industry, "_estimates.tex"),
               sanitize.text.function = identity,
               include.rownames = FALSE,
               floating = FALSE)


  return(estimates)

}

export_estimation_mc <- function(df_aggregate, industry, type_distribution, df_estimates,M = 2000){
  "
  Function to export the estimation routines and the marginal costs.
  "
  set.seed(1234)
  consumers_m_f <- generate_nu_m_f(M, df_aggregate)
  J <- nrow(df_aggregate)
  Theta <- length(type_distribution)
  Fplus1 <- ncol(consumers_m_f)

  eta <- df_estimates[param == "eta", coeff]
  sigmas <- df_estimates[param == "sigma", coeff]
  zetas <- matrix(df_estimates[param == "zeta", coeff],
                  nrow = Theta - 1,
                  ncol = Fplus1 - 1)

  parameters <- c(sigmas, zetas)

  df_aggregate$delta <- delta_inverter(parameters,
                                       eta,
                                       df_aggregate,
                                       consumers_m_f,
                                       type_distribution)

  utils_thetam_j <- calculate_utils(type_distribution,
                                    consumers_m_f,
                                    df_aggregate$firm_ids,
                                    eta,
                                    df_aggregate$prices,
                                    df_aggregate$delta,
                                    sigmas,
                                    zetas)

  df_aggregate$mc <- calculate_mc_j(df_aggregate$prices, utils_thetam_j, diag(J), eta, type_distribution, df_aggregate$market_ids)
  df_aggregate[ticker == "Other", mc := 1]
  df_mc <- df_aggregate[, c("ticker", "mc")]
  fwrite(df_mc, paste0(github.dir, "diffprod_estimation/output/", industry, "_mc.csv"))

}

dV_dTheta_Z <- function(consumers_m_f, theta, firm_list, prices, other_id=NULL, sigma_sign_list=NULL) {
  "
  Jacobian estimation: Getting dV/dTheta for each Z
  "
  M <- nrow(consumers_m_f)
  Fplus1 <- length(firm_list)+1
  NF <- Fplus1-1
  J <- length(prices)
  
  if(is.null(sigma_sign_list) == T){
    sigma_sign_list <- rep(1, NF)
  }

  dV_z_list <- list()
  idx <- 1
  # dV_dsigma <- consumers_m_f[,1:NF]
  for(i in 1:NF){
    temp_matrix <- matrix(0L, nrow=M, ncol=J)
    if(is.null(other_id) == F){
      if(i != other_id){
        temp_matrix[,i] <- consumers_m_f[,i] #+  consumers_m_f[, other_id]/(NF-1)
        temp_matrix[, other_id] <- consumers_m_f[, other_id]/(NF-1) *sigma_sign_list[i]
      }
    }else{
      temp_matrix[,i] <- consumers_m_f[,i]
    }
    dV_z_list[[i]] <- temp_matrix ## dsigma
  }
  idx <- i+1

  # dV_dInside <- matrix(consumers_m_f[,Fplus1], nrow=M, ncol=J)
  dV_z_list[[idx]] <- matrix(consumers_m_f[,Fplus1], nrow=M, ncol=J)  ## Inside

  for(i in 1:NF){
    temp_matrix <- matrix(0L, nrow=M, ncol=J)
    if (theta != 0) {
      temp_matrix[,i] <- 1
    }
    dV_z_list[[i+idx]] <- temp_matrix
  }

  dV_z_list[[Fplus1*2]] <- matrix(-prices, nrow = M, ncol = J, byrow = T)
  dV_z <- abind(dV_z_list, along=3)
  return(dV_z)
}

get_dV_dTheta <- function(type_distribution, consumers_m_f, firm_list, prices, other_id=NULL, sigma_sign_list=NULL) {
  Theta <- length(type_distribution)
  M <- nrow(consumers_m_f)
  J <- length(prices)

  consumers_m_f <- partition.matrix(consumers_m_f, rowsep = rep(M / Theta, Theta))

  dV_z_list <- list()
  for (theta in 0:(length(type_distribution)-1)) {
    dV_z_list[[theta+1]] <- dV_dTheta_Z(consumers_m_f[[theta + 1]], theta, firm_list, prices,other_id=other_id,sigma_sign_list=sigma_sign_list)
  }
  dV_dtheta <- abind(dV_z_list, along=1)

  return(dV_dtheta)
}

get_ds_dtheta_z <- function(type_distribution, consumers_m_f, df_aggregate, s_m_j, other_id=NULL, prices_to_use=NULL, sigma_sign_list=NULL) {
  "
  Jacobian estimation: Getting ds/dtheta for each z
  "
  # Define some variables
  Z <- length(type_distribution)
  N_i <- nrow(consumers_m_f)

  firm_list <- df_aggregate$firm_ids
  if (is.null(prices_to_use)){
    prices <- df_aggregate$prices
  }else{
    prices <- prices_to_use
  }

  # Get dvij_dtheta: 3D: N_i x N_j x N_theta
  dV_dtheta <- get_dV_dTheta(type_distribution, consumers_m_f, firm_list, prices,other_id=other_id, sigma_sign_list=sigma_sign_list)

  # Get s_i0, s_ij
  s_m_0 <- 1-rowSums(s_m_j)
  s_m_j <- array(s_m_j, dim=dim(dV_dtheta))

  # Compute ds_ij/dtheta -- jacobian.pdf
  s_dV_m_j_theta <- s_m_j*dV_dtheta # intermediate array

  s_dV_m_theta <- rowSums(aperm(s_dV_m_j_theta, c(1,3, 2)), dims=2) # Fast way of summing over firms. Why is R so bad...

  ds0_dtheta_i <- -s_m_0*s_dV_m_theta # ds0/dtheta: N_i x N_theta for outside firm

  s_dV_m_theta <- aperm(array(s_dV_m_theta, dim=dim(dV_dtheta)[c(1, 3, 2)]), c(1,3, 2)) # unsqueeze for dim 2: N_i x N_j x N_theta
  ds_dtheta_i <- s_m_j*(dV_dtheta - s_dV_m_theta)

  ds_dtheta_z <- list()
  ds0_dtheta_z <- list()
  for (z in 1:Z){
    ds_dtheta_temp <- rowMeans(aperm(ds_dtheta_i[((N_i/Z*(z-1))+1):(N_i/Z*z), , , drop=F], c(2, 3, 1)), dims=2) # Expectation over i for i in z
    ds0_dtheta_temp <- colMeans(ds0_dtheta_i[((N_i/Z*(z-1))+1):(N_i/Z*z), , drop=F]) # Expectation over i for i in z -- j is outside

    ds_dtheta_z[[z]] <- ds_dtheta_temp # ds_z/dtheta: N_j x N_theta
    ds0_dtheta_z[[z]] <- ds0_dtheta_temp
  }

  return(list(ds_dtheta_z, ds0_dtheta_z))
}

get_ds_ddelta_z <- function(type_distribution, consumers_m_f, df_aggregate, s_m_j, prices_to_use=NULL) {
  "
  Jacobian estimation: Getting dV/dDelta for each Z
  "
  # Define some variables
  Z <- length(type_distribution)
  N_i <- nrow(consumers_m_f)
  N_j <- ncol(s_m_j)
  firm_list <- df_aggregate$firm_ids
  if (is.null(prices_to_use)){
    prices <- df_aggregate$prices
  }else{
    prices <- prices_to_use
  }

  s_m_0 <- 1-rowSums(s_m_j)

  ds_ddelta_z <- list()
  ds0_ddelta_z <- list()
  for (z in 1:Z){
    s_m_j_z <- s_m_j[((N_i/Z*(z-1))+1):(N_i/Z*z),, drop=F]
    s_m_0_z <- s_m_0[((N_i/Z*(z-1))+1):(N_i/Z*z)]
    ds_ddelta_z[[z]] <- (diag(as.vector(colSums(s_m_j_z)), N_j, N_j)- t(s_m_j_z) %*% s_m_j_z)/(N_i/Z)
    ds0_ddelta_z[[z]] <- (-as.vector(t(s_m_j_z) %*% s_m_0_z))/(N_i/Z)
  }

  return(list(ds_ddelta_z, ds0_ddelta_z))
}

get_dg_dtheta <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=NULL, markup=0.25, drop.zeta.m=NULL,drop.s.o.m=NULL, drop.s.m=NULL){
  "
  Jacobian estimation: Getting dg/dtheta
  "
  ## Note: Subscripts for this function use the updated document, where theta is parameters and z is income group. Other functions use theta for income group.
  # Define some variables of importance
  J <- ncol(consumers_m_f)-1
  Fplus1 <- ncol(consumers_m_f)
  Theta <- length(type_distribution)
  M <- nrow(consumers_m_f) / Theta

  firm_list <- df_aggregate$firm_ids
  deltas <- df_aggregate$delta
  prices <- df_aggregate$prices
  market_list <- df_aggregate$market_ids  # assume all goods belong to the same market

  sigmas <- pars[1:Fplus1]
  sigmas[excluded_firm_idx] <- 0
  if(is.null(other_id)==F){
    sigmas[other_id] <- 0
  }
  zetas <- matrix(pars[(Fplus1+1):(2 * Fplus1 - 1)], nrow = Theta - 1, ncol = Fplus1 - 1)
  eta <- pars[2 * Fplus1]

  # Get utils and shares
  utils_thetam_j <- calculate_utils(type_distribution, consumers_m_f, firm_list, eta, prices, deltas, sigmas, zetas)
  s_m_j <- calculate_share_m_j(eta, utils_thetam_j, prices, market_list)
  # s_m_j_noout <- calculate_share_m_j_nooutgood(eta, utils_thetam_j, prices, market_list)

  # ds_dtheta_z_nooutside <- get_ds_dtheta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_noout)[[1]]
  # dg_zeta_dtheta <- ds_dtheta_z_nooutside[[2]] - ds_dtheta_z_nooutside[[1]]

  # Get ds/dtheta and ds0/dtheta for each z
  ds_dtheta_z_list <- get_ds_dtheta_z(type_distribution, consumers_m_f, df_aggregate ,sigma_sign_list=sign(sigmas))
  # list by z, each element is  N_j x N_theta
  ds_dtheta_z <- ds_dtheta_z_list[[1]]
  # list by z, each element is  N_j x N_theta
  ds0_dtheta_z <- ds_dtheta_z_list[[2]]


  # Get ds/dtheta AND ds0/dtheta across z
  ds_dtheta <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds_dtheta_z[[x]]*type_distribution[x]))
  ds_dtheta[,excluded_firm_idx] <- 0
  if(is.null(other_id)==F){
    ds_dtheta[,other_id] <- 0
  }
  ds0_dtheta <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds0_dtheta_z[[x]]*type_distribution[x]))

  # Shares by income group
  s_z_j <- do.call(rbind, lapply(partition.matrix(s_m_j, rowsep = rep(M, Theta)), colMeans))

  # Get dg_zeta/dtheta -- using par instead of theta -- LOOK AT
  # dg_zeta_dpar <- ds_dtheta_z[[2]]/sum(s_z_j[2,]) + (s_z_j[2,] %o% ds0_dtheta_z[[2]])/sum(s_z_j[2,])^2 -
  # (ds_dtheta_z[[1]]/sum(s_z_j[1,]) + (s_z_j[1,] %o% ds0_dtheta_z[[1]])/sum(s_z_j[1,])^2)


  # Get some variables of interest
  types_weights <- rep(type_distribution, each = M)
  s_z_j <- do.call(rbind, lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M, Theta)), colMeans))
  s_j <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M, Theta)), colMeans)))
  s_0 <- 1 - sum(s_j)

  # Set up some vectors/matrices that will be filled:
  s_j_shock <- s_j*0
  s_0_shock <- s_j*0
  ds_dtheta_shock<- ds_dtheta*0
  # ds0_dtheta_shock<- ds_dtheta*0

  ## What happens when there is a doubling
  s_m_j_double <- calculate_share_m_j(eta, utils_thetam_j, prices*2, market_list)
  s_j_double_f <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j_double, rowsep = rep(M, Theta)), colMeans)))
  s_0_double <- 1 - sum(s_j_double_f)

  ds_dtheta_z_double_list <- get_ds_dtheta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_double, prices_to_use = prices*2)
  ds0_dtheta_z_double <- ds_dtheta_z_double_list[[2]]
  ds0_dtheta_double <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds0_dtheta_z_double[[x]]*type_distribution[x]))

  ## For each firm, estimate what happens when their product has a 25% markup
  for (firm in firm_list) {
    # New prices
    increased_prices <- prices + markup * prices * (firm_list == firm)
    # Individual shares under the shock
    s_m_j_shock <- calculate_share_m_j(eta, utils_thetam_j, increased_prices, market_list)
    # Shares under shock
    s_j_shock_f <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j_shock, rowsep = rep(M, Theta)), colMeans)))

    # Update share variables
    s_j_shock[firm_list == firm] <- s_j_shock_f[firm_list == firm]
    #   s_0_shock[firm_list == firm] <- 1 - sum(s_j_shock_f)

    # Get ds/dtheta ds0/dtheta for shock
    ds_dtheta_z_shock_list <- get_ds_dtheta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_shock, prices_to_use = increased_prices)
    ds_dtheta_z_shock <- ds_dtheta_z_shock_list[[1]]
    # ds0_dtheta_z_shock <- ds_dtheta_z_shock_list[[2]]

    # Average across income group
    ds_dtheta_shock_firm <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds_dtheta_z_shock[[x]]*type_distribution[x]))
    # ds0_dtheta_shock_firm <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds0_dtheta_z_shock[[x]]*type_distribution[x]))

    # Update ds/dtheta for new price
    ds_dtheta_shock[firm_list == firm,] <- ds_dtheta_shock_firm[firm_list == firm, ]
    # ds0_dtheta_shock[firm_list == firm,] <- ds0_dtheta_shock_firm
  }

  # Get dg_sigma/dtheta

  dg_sigma_dtheta <- ds_dtheta_shock/s_j - (s_j_shock*ds_dtheta)/s_j^2
  # Get dg_outside/dtheta
  # dg_outside_dtheta <- colMeans(t(t(ds0_dtheta_shock) - ds0_dtheta)/s_j - ((s_0_shock - s_0)*ds_dtheta)/s_j^2)
  dg_outside_dtheta <- -(ds0_dtheta_double/(1-s_0) - ((1-s_0_double)*ds0_dtheta)/(1-s_0)^2) 

  dg_zeta_dtheta <- (type_distribution[2]*ds_dtheta_z[[2]] - type_distribution[1]*ds_dtheta_z[[1]])/(1-s_0) +
    ((type_distribution[2]*s_z_j[2,] - type_distribution[1]*s_z_j[1,])*ds0_dtheta)/(1-s_0)^2
  if(is.null(drop.zeta.m) == F){
    if(is.null(drop.s.o.m) == F){
      dg_dtheta <- dg_sigma_dtheta
    }else if(is.null(drop.s.m) == F){
      dg_dtheta <- dg_outside_dtheta
    }else{
      dg_dtheta <- rbind(dg_sigma_dtheta, dg_outside_dtheta)
    }
  }else{
    if((is.null(drop.s.o.m) == F)& (is.null(drop.s.m) == F)){
      dg_dtheta <- dg_zeta_dtheta
    }else if(is.null(drop.s.o.m) == F){
      dg_dtheta <- rbind(dg_sigma_dtheta, dg_zeta_dtheta)
    }else if(is.null(drop.s.m) == F){
      dg_dtheta <- rbind(dg_outside_dtheta, dg_zeta_dtheta)
    }else{
      # Concatenate
      dg_dtheta <- rbind(dg_sigma_dtheta, dg_outside_dtheta, dg_zeta_dtheta)

    }

  }
  # Leave out firm that is being excluded
  # dg_dtheta<- dg_dtheta[,-excluded_firm_idx] # excluding sigma_excluded_firm_idx
  dg_dtheta[,excluded_firm_idx] <- 0
  if(is.null(other_id)==F){
    dg_dtheta[,other_id] <- 0
  }
  return(list(dg_dtheta, ds_dtheta))
}

get_dg_ddelta <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=NULL, markup=0.25, drop.zeta.m=NULL,drop.s.o.m=NULL, drop.s.m=NULL){
  "
  Jacobian estimation: Getting dg/ddelta
  "
  ## Note: Subscripts for this function use the updated document, where theta is parameters and z is income group. Other functions use theta for income group.
  # Define some variables of importance
  J <- ncol(consumers_m_f)-1
  Fplus1 <- ncol(consumers_m_f)
  Theta <- length(type_distribution)
  M <- nrow(consumers_m_f) / Theta

  firm_list <- df_aggregate$firm_ids
  deltas <- df_aggregate$delta
  prices <- df_aggregate$prices
  market_list <- df_aggregate$market_ids  # assume all goods belong to the same market

  sigmas <- pars[1:Fplus1]
  sigmas[excluded_firm_idx] <- 0
  if(is.null(other_id)==F){
    sigmas[other_id] <- 0
  }
  zetas <- matrix(pars[(Fplus1+1):(2 * Fplus1 - 1)], nrow = Theta - 1, ncol = Fplus1 - 1)
  eta <- pars[2 * Fplus1]

  # Get utils and shares
  utils_thetam_j <- calculate_utils(type_distribution, consumers_m_f, firm_list, eta, prices, deltas, sigmas, zetas)
  s_m_j <- calculate_share_m_j(eta, utils_thetam_j, prices, market_list)
  s_m_j_noout <- calculate_share_m_j_nooutgood(eta, utils_thetam_j, prices, market_list)

  # Shares by income group
  s_z_j <- do.call(rbind, lapply(partition.matrix(s_m_j, rowsep = rep(M, Theta)), colMeans))

  # Get some variables of interest
  types_weights <- rep(type_distribution, each = M)
  s_z_j <- do.call(rbind, lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M, Theta)), colMeans))
  s_j <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M, Theta)), colMeans)))
  s_0 <- 1 - sum(s_j)


  ## 1.
  # dg_zeta_ddelta
  # Something is going wrong here
  # ds_ddelta_z_nooutside <- get_ds_ddelta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_noout)[[1]]
  # dg_zeta_ddelta <- ds_ddelta_z_nooutside[[2]] - ds_ddelta_z_nooutside[[1]]


  ## 2. and 3.
  # Get ds/ddelta and ds0/ddelta for each z
  ds_ddelta_z_list <- get_ds_ddelta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j)
  # list by z, each element is  N_j x N_j
  ds_ddelta_z <- ds_ddelta_z_list[[1]]
  # list by z, each element is  N_j x N_j
  ds0_ddelta_z <- ds_ddelta_z_list[[2]]

  # Get ds/ddelta AND ds0/ddelta across z
  ds_ddelta <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds_ddelta_z[[x]]*type_distribution[x]))
  ds0_ddelta <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds0_ddelta_z[[x]]*type_distribution[x]))


  # Set up some vectors/matrices that will be filled:
  s_j_shock <- s_j*0
  s_0_shock <- s_j*0
  ds_ddelta_shock<- ds_ddelta*0
  # ds0_ddelta_shock<- ds_ddelta*0

  ## What happens when there is a doubling
  s_m_j_double <- calculate_share_m_j(eta, utils_thetam_j, prices*2, market_list)
  s_j_double_f <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j_double, rowsep = rep(M, Theta)), colMeans)))
  s_0_double <- 1 - sum(s_j_double_f)

  ds_ddelta_z_double_list <- get_ds_ddelta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_double, prices_to_use = prices*2)
  ds0_ddelta_z_double <- ds_ddelta_z_double_list[[2]]
  ds0_ddelta_double <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds0_ddelta_z_double[[x]]*type_distribution[x]))

  # For each firm, estimate what happens when their product has a 25% markup
  for (firm in firm_list) {
    # New prices
    increased_prices <- prices + markup * prices * (firm_list == firm)
    # Individual shares under the shock
    s_m_j_shock <- calculate_share_m_j(eta, utils_thetam_j, increased_prices, market_list)
    # Shares under shock
    s_j_shock_f <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j_shock, rowsep = rep(M, Theta)), colMeans)))

    # Update share variables
    s_j_shock[firm_list == firm] <- s_j_shock_f[firm_list == firm]
    # s_0_shock[firm_list == firm] <- 1 - sum(s_j_shock_f)

    # Get ds/ddelta ds0/ddelta for shock
    ds_ddelta_z_shock_list <- get_ds_ddelta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_shock, prices_to_use = increased_prices)
    ds_ddelta_z_shock <- ds_ddelta_z_shock_list[[1]]
    # ds0_ddelta_z_shock <- ds_ddelta_z_shock_list[[2]]

    # Average across income group
    ds_ddelta_shock_firm <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds_ddelta_z_shock[[x]]*type_distribution[x]))
    # ds0_ddelta_shock_firm <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds0_ddelta_z_shock[[x]]*type_distribution[x]))

    # Update ds/ddelta for new price
    ds_ddelta_shock[firm_list == firm,] <- ds_ddelta_shock_firm[firm_list == firm, ]
    # ds0_ddelta_shock[firm_list == firm,] <- ds0_ddelta_shock_firm
  }

  # Get dg_sigma/ddelta
  dg_sigma_ddelta <- ds_ddelta_shock/s_j - (s_j_shock*ds_ddelta)/s_j^2
  # Get dg_outside/ddelta
  # dg_outside_ddelta <- colMeans(t(t(ds0_ddelta_shock) - ds0_ddelta)/s_j - ((s_0_shock - s_0)*ds_ddelta)/s_j^2)
  dg_outside_ddelta <- -(ds0_ddelta_double/(1-s_0) - ((1-s_0_double)*ds0_ddelta)/(1-s_0)^2)

  dg_zeta_ddelta <- (type_distribution[2]*ds_ddelta_z[[2]] - type_distribution[1]*ds_ddelta_z[[1]])/(1-s_0) +
    ((type_distribution[2]*s_z_j[2,] - type_distribution[1]*s_z_j[1,])*ds0_ddelta)/(1-s_0)^2
  if(is.null(drop.zeta.m) == F){
    if(is.null(drop.s.o.m) == F){
      dg_ddelta <- dg_sigma_ddelta
    }else if(is.null(drop.s.m) == F){
      dg_ddelta <- dg_outside_ddelta
    }else{
      dg_ddelta <- rbind(dg_sigma_ddelta, dg_outside_ddelta)
    }
  }else{
    if((is.null(drop.s.o.m) == F)& (is.null(drop.s.m) == F)){
      dg_ddelta <- dg_zeta_ddelta
    }else if(is.null(drop.s.o.m) == F){
      dg_ddelta <- rbind(dg_sigma_ddelta, dg_zeta_ddelta)
    }else if(is.null(drop.s.m) == F){
      dg_ddelta <- rbind(dg_outside_ddelta, dg_zeta_ddelta)
    }else{
      # Concatenate
      dg_ddelta <- rbind(dg_sigma_ddelta, dg_outside_ddelta, dg_zeta_ddelta)
    }
  }
  # Leave out firm that is being excluded
  # dg_ddelta<- dg_ddelta[,-excluded_firm_idx] # excluding sigma_excluded_firm_idx
  # dg_ddelta[,excluded_firm_idx] <- 0

  return(list(dg_ddelta, ds_ddelta))
}

get_dg_eff <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=NULL, markup=0.25, drop.zeta.m=NULL,drop.s.o.m=NULL, drop.s.m=NULL){
  "
  Jacobian estimation: Getting dg efficiently
  "
  #### This is an efficient combination of dg_dtheta and dg_ddelta which share a lot of computations
  ### 0.0 Define some variables of importance
  J <- ncol(consumers_m_f)-1
  Fplus1 <- ncol(consumers_m_f)
  Theta <- length(type_distribution)
  M <- nrow(consumers_m_f) / Theta

  firm_list <- df_aggregate$firm_ids
  deltas <- df_aggregate$delta
  prices <- df_aggregate$prices
  market_list <- df_aggregate$market_ids  # assume all goods belong to the same market

  sigmas <- pars[1:Fplus1]
  if(is.null(other_id)==F){
    sigmas[other_id] <- mean(abs(sigmas[-other_id][1:(Fplus1-2)]))
  }
  
  sigmas[excluded_firm_idx] <- 0
  zetas <- matrix(pars[(Fplus1+1):(2 * Fplus1 - 1)], nrow = Theta - 1, ncol = Fplus1 - 1)
  eta <- pars[2 * Fplus1]

  # Get utils and shares
  utils_thetam_j <- calculate_utils(type_distribution, consumers_m_f, firm_list, eta, prices, deltas, sigmas, zetas)
  s_m_j <- calculate_share_m_j(eta, utils_thetam_j, prices, market_list)
  s_m_j_noout <- calculate_share_m_j_nooutgood(eta, utils_thetam_j, prices, market_list)

  # Shares by income group
  s_z_j <- do.call(rbind, lapply(partition.matrix(s_m_j, rowsep = rep(M, Theta)), colMeans))

  # Get some variables of interest
  types_weights <- rep(type_distribution, each = M)
  s_z_j <- do.call(rbind, lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M, Theta)), colMeans))
  s_j <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M, Theta)), colMeans)))
  s_0 <- 1 - sum(s_j)


  ### 1.0
  # ## 1.1 dg_zeta_ddelta
  # ds_ddelta_z_nooutside <- get_ds_ddelta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_noout)[[1]]
  # dg_zeta_ddelta <- ds_ddelta_z_nooutside[[2]] - ds_ddelta_z_nooutside[[1]]
  #
  # ## 1.2 dg_zeta_dtheta
  # ds_dtheta_z_nooutside <- get_ds_dtheta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_noout)[[1]]
  # dg_zeta_dtheta <- ds_dtheta_z_nooutside[[2]] - ds_dtheta_z_nooutside[[1]]

  ### 2.0
  ## 2.1 Get ds/ddelta and ds0/ddelta
  # for each z
  ds_ddelta_z_list <- get_ds_ddelta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j)
  ds_ddelta_z <- ds_ddelta_z_list[[1]]
  ds0_ddelta_z <- ds_ddelta_z_list[[2]]

  # Get ds/ddelta AND ds0/ddelta across z
  ds_ddelta <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds_ddelta_z[[x]]*type_distribution[x]))
  ds0_ddelta <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds0_ddelta_z[[x]]*type_distribution[x]))

  ## 2.1 Get ds/dtheta and ds0/dtheta
  #for each z
  ds_dtheta_z_list <- get_ds_dtheta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j, other_id=other_id)
  ds_dtheta_z <- ds_dtheta_z_list[[1]]
  ds0_dtheta_z <- ds_dtheta_z_list[[2]]

  # Get ds/dtheta AND ds0/dtheta across z
  ds_dtheta <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds_dtheta_z[[x]]*type_distribution[x]))
  ds0_dtheta <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds0_dtheta_z[[x]]*type_distribution[x]))

  ds_dtheta[,excluded_firm_idx] <- 0
  ds0_dtheta[excluded_firm_idx] <- 0

  if(is.null(other_id)==F){
    ds_dtheta[,other_id] <- 0
    ds0_dtheta[other_id] <- 0
  }

  ### 3.0 What happens when there is a doubling
  ## 3.1 Shares
  s_m_j_double <- calculate_share_m_j(eta, utils_thetam_j, prices*2, market_list)
  s_j_double_f <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j_double, rowsep = rep(M, Theta)), colMeans)))
  s_0_double <- 1 - sum(s_j_double_f)
  ## 3.2 ds0_dtheta_double
  ds_dtheta_z_double_list <- get_ds_dtheta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_double, prices_to_use = prices*2, other_id=other_id)
  ds0_dtheta_z_double <- ds_dtheta_z_double_list[[2]]
  ds0_dtheta_double <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds0_dtheta_z_double[[x]]*type_distribution[x]))
  ## 3.3 ds0_ddelta_double
  ds_ddelta_z_double_list <- get_ds_ddelta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_double, prices_to_use = prices*2)
  ds0_ddelta_z_double <- ds_ddelta_z_double_list[[2]]
  ds0_ddelta_double <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds0_ddelta_z_double[[x]]*type_distribution[x]))

  ### 4.0
  # Set up some vectors/matrices that will be filled:
  s_j_shock <- s_j*0
  s_0_shock <- s_j*0
  ds_dtheta_shock<- ds_dtheta*0
  ds_ddelta_shock<- ds_ddelta*0
  ## For each firm, estimate what happens when their product has a 25% markup
  for (firm in firm_list) {
    ## 4.1 Shock shares
    # New prices
    increased_prices <- prices + markup * prices * (firm_list == firm)
    # Individual shares under the shock
    s_m_j_shock <- calculate_share_m_j(eta, utils_thetam_j, increased_prices, market_list)
    # Shares under shock
    s_j_shock_f <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j_shock, rowsep = rep(M, Theta)), colMeans)))
    # Update share variables
    s_j_shock[firm_list == firm] <- s_j_shock_f[firm_list == firm]

    ## 4.2 ds/dtheta ds0/dtheta for shock
    ds_dtheta_z_shock_list <- get_ds_dtheta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_shock, prices_to_use = increased_prices, other_id=other_id)
    ds_dtheta_z_shock <- ds_dtheta_z_shock_list[[1]]

    # Average across income group
    ds_dtheta_shock_firm <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds_dtheta_z_shock[[x]]*type_distribution[x]))

    # Update ds/dtheta for new price
    ds_dtheta_shock[firm_list == firm,] <- ds_dtheta_shock_firm[firm_list == firm, ]

    ## 4.3 ds/ddelta ds0/ddelta for shock
    ds_ddelta_z_shock_list <- get_ds_ddelta_z(type_distribution, consumers_m_f, df_aggregate, s_m_j_shock, prices_to_use = increased_prices)
    ds_ddelta_z_shock <- ds_ddelta_z_shock_list[[1]]

    # Average across income group
    ds_ddelta_shock_firm <- Reduce("+", lapply(seq_len(length(type_distribution)), function(x) ds_ddelta_z_shock[[x]]*type_distribution[x]))

    # Update ds/ddelta for new price
    ds_ddelta_shock[firm_list == firm,] <- ds_ddelta_shock_firm[firm_list == firm, ]
  }
  ### 5.0 Finalize moments
  ## 5.1 dg_dtheta
  # Get dg_sigma/dtheta
  dg_sigma_dtheta <- ds_dtheta_shock/s_j - (s_j_shock*ds_dtheta)/s_j^2

  # Get dg_outside/dtheta
  dg_outside_dtheta <- -(ds0_dtheta_double/(1-s_0) - ((1-s_0_double)*ds0_dtheta)/(1-s_0)^2) 
  # Get dg_zeta/dtheta
  dg_zeta_dtheta <- (type_distribution[2]*ds_dtheta_z[[2]] - type_distribution[1]*ds_dtheta_z[[1]])/(1-s_0) +
    ((type_distribution[2]*s_z_j[2,] - type_distribution[1]*s_z_j[1,])%o%ds0_dtheta)/(1-s_0)^2

  if(is.null(drop.zeta.m) == F){
    if(is.null(drop.s.o.m) == F){
      dg_dtheta <- rbind(dg_sigma_dtheta)
    }else if(is.null(drop.s.m) == F){
      dg_dtheta <- rbind(dg_outside_dtheta)
    }else{
      dg_dtheta <- rbind(dg_sigma_dtheta, dg_outside_dtheta)
    }

  }else{
    if((is.null(drop.s.o.m) == F)& (is.null(drop.s.m) == F)){
      dg_dtheta <- rbind(dg_zeta_dtheta)
    }else if(is.null(drop.s.o.m) == F){
      dg_dtheta <- rbind(dg_sigma_dtheta, dg_zeta_dtheta)
    }else if(is.null(drop.s.m) == F){
      dg_dtheta <- rbind(dg_outside_dtheta, dg_zeta_dtheta)
    }else{
      # Concatenate
      dg_dtheta <- rbind(dg_sigma_dtheta, dg_outside_dtheta, dg_zeta_dtheta)
    }
  }
  # Leave out firm that is being excluded
  dg_dtheta[,excluded_firm_idx] <- 0
  if(is.null(other_id)==F){
    dg_dtheta[,other_id] <- 0
    dg_dtheta[other_id,] <- 0
  }
  ## 5.2 dg_ddelta
  # Get dg_sigma/ddelta
  dg_sigma_ddelta <- ds_ddelta_shock/s_j - (s_j_shock*ds_ddelta)/s_j^2
  # Get dg_outside/ddelta
  dg_outside_ddelta <- -(ds0_ddelta_double/(1-s_0) - ((1-s_0_double)*ds0_ddelta)/(1-s_0)^2) 

  # Get dg_zeta/ddelta
  dg_zeta_ddelta <- (type_distribution[2]*ds_ddelta_z[[2]] - type_distribution[1]*ds_ddelta_z[[1]])/(1-s_0) +
    ((type_distribution[2]*s_z_j[2,] - type_distribution[1]*s_z_j[1,])%o%ds0_ddelta)/(1-s_0)^2


  if(is.null(drop.zeta.m) == F){
    if(is.null(drop.s.o.m) == F){
      dg_ddelta <- rbind(dg_sigma_ddelta)
      ds_dtheta[,((Fplus1):(2 * Fplus1 - 1))] <- 0
      dg_dtheta[,((Fplus1):(2 * Fplus1 - 1))] <- 0
    }else if(is.null(drop.s.m) == F){
      dg_ddelta <- rbind(dg_outside_ddelta)
      ds_dtheta[,c(1:(Fplus1-1),(Fplus1+1):(2 * Fplus1))] <- 0
      dg_dtheta[,c(1:(Fplus1-1),(Fplus1+1):(2 * Fplus1))] <- 0
    }else{
      dg_ddelta <- rbind(dg_sigma_ddelta, dg_outside_ddelta)
      ds_dtheta[,((Fplus1+1):(2 * Fplus1 - 1))] <- 0
      dg_dtheta[,((Fplus1+1):(2 * Fplus1 - 1))] <- 0
    }
  }else{
    if((is.null(drop.s.o.m) == F)& (is.null(drop.s.m) == F)){
      dg_ddelta <- rbind(dg_zeta_ddelta)
      ds_dtheta[,c(1:(Fplus1), 2*Fplus1)] <- 0
      dg_dtheta[,c(1:(Fplus1), 2*Fplus1)] <- 0
    }else if(is.null(drop.s.o.m) == F){
      dg_ddelta <- rbind(dg_sigma_ddelta, dg_zeta_ddelta)
      ds_dtheta[,((Fplus1))] <- 0
      dg_dtheta[,((Fplus1))] <- 0
    }else if(is.null(drop.s.m) == F){
      dg_ddelta <- rbind(dg_outside_ddelta, dg_zeta_ddelta)
      ds_dtheta[,c(1:(Fplus1-1), 2*Fplus1)] <- 0
      dg_dtheta[,c(1:(Fplus1-1), 2*Fplus1)] <- 0

    }else{
      # Concatenate
      dg_ddelta <- rbind(dg_sigma_ddelta, dg_outside_ddelta, dg_zeta_ddelta)
    }
  }
  if(is.null(other_id)==F){
    dg_ddelta[other_id,] <- 0
  }
  return(list(dg_dtheta, ds_dtheta, dg_ddelta, ds_ddelta))
}

get_s <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=NULL, markup=0.25, drop.zeta.m=NULL,drop.s.o.m=NULL, drop.s.m=NULL){
  "
  Get shares.
  "
  ### 0.0 Define some variables of importance
  J <- ncol(consumers_m_f)-1
  Fplus1 <- ncol(consumers_m_f)
  Theta <- length(type_distribution)
  M <- nrow(consumers_m_f) / Theta

  firm_list <- df_aggregate$firm_ids
  deltas <- df_aggregate$delta
  prices <- df_aggregate$prices
  market_list <- df_aggregate$market_ids  # assume all goods belong to the same market

  sigmas <- pars[1:Fplus1]
  sigmas[excluded_firm_idx] <- 0
  if(is.null(other_id)==F){
    sigmas[other_id] <- mean(sigmas[-other_id][1:(Fplus1-2)])
  }
  zetas <- matrix(pars[(Fplus1+1):(2 * Fplus1 - 1)], nrow = Theta - 1, ncol = Fplus1 - 1)

  eta <- pars[2 * Fplus1]

  # Get utils and shares
  utils_thetam_j <- calculate_utils(type_distribution, consumers_m_f, firm_list, eta, prices, deltas, sigmas, zetas)
  s_m_j <- calculate_share_m_j(eta, utils_thetam_j, prices, market_list)
  s_m_j_noout <- calculate_share_m_j_nooutgood(eta, utils_thetam_j, prices, market_list)

  # Shares by income group
  s_z_j <- do.call(rbind, lapply(partition.matrix(s_m_j, rowsep = rep(M, Theta)), colMeans))

  # Get some variables of interest
  types_weights <- rep(type_distribution, each = M)
  s_z_j <- do.call(rbind, lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M, Theta)), colMeans))
  s_j <- c(Reduce("+", lapply(partition.matrix(types_weights * s_m_j, rowsep = rep(M, Theta)), colMeans)))
  s_0 <- 1 - sum(s_j)
  return(s_j)
}

get_g <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s, other_id=NULL, drop.zeta.m=NULL,drop.s.o.m=NULL, drop.s.m=NULL){
  "
    Get moments.
  "
  if(is.null(sample_s)){
    shares_f_theta_a <- df_survey[, sum(weights * income_groups), by = firm_ids][, .(V1)] / df_survey[, sum(weights)]
    shares_f_theta_b <- df_survey[, sum(weights * (1 - income_groups)), by = firm_ids][, .(V1)] / df_survey[, sum(weights)]
    sample_s <- (shares_f_theta_a - shares_f_theta_b)[, V1]
  }

  Fplus1 <- ncol(consumers_m_f)
  if(is.null(drop.s.m) == F){
    pars[1:(Fplus1-1)] <- drop.s.m[1:(Fplus1-1)]
    pars[2 * Fplus1] <- drop.s.m[(Fplus1)]
  }else{
    pars[excluded_firm_idx] <-  0
    if(is.null(other_id) == F){
      pars[other_id] <- mean(abs(pars[-other_id][1:(Fplus1 - 2)]))
    }
  }

  if(is.null(drop.zeta.m) == F){
    pars[(Fplus1+1):(2 * Fplus1 - 1)] <- drop.zeta.m
  }
  if(is.null(drop.s.o.m) == F){
    pars[Fplus1] <- drop.s.o.m
  }

  df_aggregate$delta <- delta_inverter(pars[1:(2 * Fplus1 - 1)],
                                       pars[2 * Fplus1],
                                       df_aggregate,
                                       consumers_m_f,
                                       type_distribution,
                                       tol.squarem = 1e-13,
                                       k = 1)
  if(is.null(drop.zeta.m) == F){
    g <- c(g_sigma(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=other_id, drop.zeta.m=drop.zeta.m,drop.s.o.m=drop.s.o.m, drop.s.m=drop.s.m))
  }else{
    if((is.null(drop.s.m) == F) & (is.null(drop.s.o.m) == F)){
      g <- c(g_zeta(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s))
    }else{
      g <- c( g_sigma(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=other_id, drop.s.o.m=drop.s.o.m, drop.s.m=drop.s.m),
              g_zeta(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s))
    }

  }
  g <- as.matrix(g, nrow = length(g), ncol = 1)
  return(g)
}

get_dg_dpar <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx,  sample_s, other_id=NULL, drop.zeta.m=NULL,drop.s.o.m=NULL, drop.s.m=NULL){
  "
  Jacobian estimation: Getting dg/dparameters
  "
  Fplus1 <- ncol(consumers_m_f)
  if(is.null(other_id) == F){
    pars[other_id] <- mean(abs(pars[-other_id][1:(Fplus1 - 2)]))
  }

  df_aggregate$delta <- delta_inverter(pars[1:(2 * Fplus1 - 1)],
                                       pars[2 * Fplus1],
                                       df_aggregate,
                                       consumers_m_f,
                                       type_distribution,
                                       tol.squarem = 1e-13,
                                       k = 1)

  dg_dtheta_ddelta_list <- get_dg_eff(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=other_id)

  dg_dtheta <- dg_dtheta_ddelta_list[[1]]
  ds_dtheta <- dg_dtheta_ddelta_list[[2]]
  dg_ddelta <- dg_dtheta_ddelta_list[[3]]
  ds_ddelta <- dg_dtheta_ddelta_list[[4]]

  # m x f @ (f x f @ f x params )
  ddelta_dtheta <- -solve(ds_ddelta) %*% ds_dtheta

  dg_dpar <- dg_dtheta + dg_ddelta %*% ddelta_dtheta

  if(is.null(drop.s.m) == F){
    dg_dpar[,1:(Fplus1-1)] <- 0
    dg_dpar[,2 * Fplus1] <- 0
  }else{
    dg_dpar[,excluded_firm_idx] <-  0
    if(is.null(other_id)==F){
      dg_dpar[,other_id] <-  0
    }
  }

  if(is.null(drop.zeta.m) == F){
    dg_dpar[,(Fplus1+1):(2 * Fplus1 - 1)] <- 0
  }
  if(is.null(drop.s.o.m) == F){
    dg_dpar[,(Fplus1)] <- 0
  }
  return(list(dg_dpar, ds_dtheta))
}

jacobian_SMM <- function(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s, other_id=NULL, drop.zeta.m=NULL,drop.s.o.m=NULL, drop.s.m=NULL){
  "
  Jacobian estimation: Getting dSMM/dtheta
  "
  # Might be worth looking into if there is any cross contamination before this column is dropped. If so, would be worth dropping this earlier.
  Fplus1 <- ncol(consumers_m_f)
  if(is.null(other_id) == F){
    pars[other_id] <- mean(abs(pars[-other_id][1:(Fplus1 - 2)]))
  }

  df_aggregate$delta <- delta_inverter(pars[1:(2 * Fplus1 - 1)],
                                       pars[2 * Fplus1],
                                       df_aggregate,
                                       consumers_m_f,
                                       type_distribution,
                                       tol.squarem = 1e-13,
                                       k = 1)
  if(is.null(drop.zeta.m) == F){
    g <- c(g_sigma(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=other_id, drop.zeta.m=drop.zeta.m,drop.s.o.m=drop.s.o.m, drop.s.m=drop.s.m))
  }else{
    if((is.null(drop.s.m) == F) & (is.null(drop.s.o.m) == F)){
      g <- c(g_zeta(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s))
    }else{
      g <- c( g_sigma(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=other_id, drop.s.o.m=drop.s.o.m, drop.s.m=drop.s.m),
              g_zeta(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, sample_s))
    }

  }
  g <- as.matrix(g, nrow = length(g), ncol = 1)

  W <-  diag(length(g))  # assume identity as weighting matrix

  dg_dtheta_ddelta_list <- get_dg_eff(pars, type_distribution, consumers_m_f, df_aggregate, df_survey, excluded_firm_idx, other_id=other_id, drop.zeta.m = drop.zeta.m, drop.s.o.m = drop.s.o.m, drop.s.m = drop.s.m )

  dg_dtheta <- dg_dtheta_ddelta_list[[1]]
  ds_dtheta <- dg_dtheta_ddelta_list[[2]]
  dg_ddelta <- dg_dtheta_ddelta_list[[3]]
  ds_ddelta <- dg_dtheta_ddelta_list[[4]]
  # m x f @ (f x f @ f x params )

  ddelta_dtheta <- -solve(ds_ddelta) %*% ds_dtheta

  dg_dpar <- dg_dtheta + dg_ddelta %*% ddelta_dtheta
  # dg_dpar[,excluded_firm_idx] <- 0
  if(is.null(drop.s.m) == F){
    dg_dpar[,1:(Fplus1-1)] <- 0
    dg_dpar[,2 * Fplus1] <- 0
  }else{
    dg_dpar[, excluded_firm_idx] <-  0
    if(is.null(other_id) == F){
      dg_dpar[, other_id] <-  0
    }
  }

  if(is.null(drop.zeta.m) == F){
    dg_dpar[,((Fplus1+1):(2 * Fplus1 - 1))] <- 0
  }
  if(is.null(drop.s.o.m) == F){
    dg_dpar[,(Fplus1)] <- 0
  }
  return(as.vector(2*t(dg_dpar) %*% W %*% g))
}
