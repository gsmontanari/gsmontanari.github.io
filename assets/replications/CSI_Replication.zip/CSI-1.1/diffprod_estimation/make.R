## Make file for running the estimation 
rm(list = ls())

# Load paths
source('lib/SetGlobals.R')

# Change to the current working directory
setwd(paste0(github.dir, 'diffprod_estimation'))

# Clean all output
unlink('output', recursive = TRUE)
dir.create('output')

# Run all scripts
source('code/generate_estimates.R')

# Change to the root
setwd(github.dir)
