###This file contains configurations for the oil code
demand_elasticity<- -0.14
supply_elasticity<- 0.1
us_share<- 0.2
companies<-c("XOM","BP","RDSA","CVX","TOT","COP","E")
company_names <- c("Exxon","BP", "Shell", "Chevron", "Total", "ConocoPhillips", "Eni")