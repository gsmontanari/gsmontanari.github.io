## This file estimates the welfare effects of single-firm exit
rm(list=ls())

source('lib/functions.R')
source('lib/SetGlobals.R')
source('lib/ExportToLyx.R')

library(readr)
library(dplyr)
library(haven)
library(readxl)
library(tidyr)
library(stargazer)
library(ggplot2)

library(readxl)

# read in configs and functions
source("oil/code/configs.R")
source("oil/code/estimation_utils.R")

# read in data
output <- get_rystad_data()
company_data <- output[[1]]
production <- output[[2]]
price_now <- output[[3]]
total_oil <- output[[4]]

# estimate profits
prof <- c()
for(i in 1:length(company_data)){
  prof <- c(prof, profits(company_data[[i]]))
}
prof <- prof/price_now


#Results
df<-data.frame()
for (i in 1:length(companies)){
  df<-rbind(df,oil_exit(production[i],prof[i]))
}

names(df)<-c("Oil Production","Price on Exit","Production on Exit","Firm Global PS","Change in Global PS - Other Firms","Change in US PS - Other Firms","Change in Global CS","Change in US CS","Change in Global TS","Change in US TS")

# incorporate externality
df$change_env_ext <- (total_oil - df$`Production on Exit`)*scc*.475
extOil <- scc*.475/price_now
ExportToLyx(extOil, 2)
names(df)<-c("Oil Production","Price on Exit","Production on Exit","Firm Global PS","Change in Global PS - Other Firms","Change in US PS - Other Firms","Change in Global CS","Change in US CS","Change in Global TS","Change in US TS","Change in Env. Externality")
df$Company<-companies
df <- df %>% select(Company, everything())

# get nhts data
travel_df <- get_nhts_data()

#output table
output<-df %>% select(Company) %>% rename(firm=Company)
output$CS_billion<-df$`Change in US CS`/1000000000
output$OwnProfit_billion<- - df$`Firm Global PS`*0.2/1000000000
output$OtherProfit_billion<- df$`Change in US PS - Other Firms`/1000000000
output$TS_billion<- output$CS_billion + output$OwnProfit_billion + output$OtherProfit_billion

output$Revenues_billion<- price_now*df$`Oil Production`*0.2/1000000000
output$Externality_billion<-df$`Change in Env. Externality`*0.2/1000000000

output$CS_weighted_billion<-output$CS_billion*sum(travel_df$share*travel_df$weight)

w_weights <- fread(paste0(github.dir,'welfare_weights/output/welfare_weights.csv'))
profits_weight <- w_weights[["ProfitWeight"]]

output$OwnProfit_weighted_billion<- output$OwnProfit_billion * profits_weight
output$OtherProfit_weighted_billion<- output$OtherProfit_billion * profits_weight


revenue<-price_now*production/1000000000

output$CS_billion[output$CS_billion> (revenue*2)]<-revenue[output$CS_billion> (revenue*2)]
output$CS_weighted_billion[output$CS_weighted_billion> (revenue*2)]<-revenue[output$CS_weighted_billion> (revenue*2)]


output$TS_weighted_billion<-output$CS_weighted_billion+output$OwnProfit_weighted_billion+output$OtherProfit_weighted_billion

output$firm<-c("Exxon","BP","Shell","Chevron","Total","Conoco","Eni")
output$scenario<-"primary"
output<-output[,c("firm",	"scenario",	"CS_billion",	"OwnProfit_billion",	"OtherProfit_billion",	"Externality_billion",	"TS_billion",	"CS_weighted_billion",	"OwnProfit_weighted_billion",	"OtherProfit_weighted_billion",	"TS_weighted_billion",	"Revenues_billion")]

output$Externality_billion<- -output$Externality_billion
write_csv(output,"oil/output/oil_output.csv")

surplus <- fread(paste0(github.dir, "oil/output/oil_output.csv"))


setwd(paste0(github.dir,"/oil"))

surplus$Revenues_billion<-NULL
plot_output(surplus, "oil", weighted = NULL)
plot_output(surplus, "oil", weighted = TRUE)
setwd("..")
