## Functions for the oil code.
get_rystad_data <- function(){
  rystad <- read_excel(paste0(dropbox.dir,"Data/oil/raw/rystad.xlsx"))
  
  rystad <- rystad %>% filter(Year==2018)
  
  # This scripts analyses welfare change from oil company exit
  production<-rystad$`Production (Million bbl)...5`*1000000 # production in terms of barrel
  rystad$profit<-rystad$`Free Cash Flow`/rystad$`Production (Million bbl)...5` # profit per million barrel
  
  # Parameters
  price_now<-as.numeric(rystad$`Brent oil price (USD/bbl)`[1])

  total_oil<- as.numeric(rystad$`Production (Million bbl)...11`[1])*1000000 
  totalOil <- total_oil/365/1e6
  priceOil <- price_now
  ExportToLyx(totalOil, 0)
  ExportToLyx(priceOil, 0)
  
  company_data <- list()
  for(i in 1:length(company_names)){
    company_data[[i]] <- read_excel(paste0(dropbox.dir,"/Data/oil/raw/rystad_data.xlsx"), sheet = company_names[i], skip = 2)
  }
  return(list(company_data, production, price_now, total_oil))
}

get_nhts_data <- function(){
  #Results for US gasoline consumers
  
  #Import travel data
  travel_df<-read_csv(paste0(dropbox.dir,"/Data/oil/raw/NHTS/trippub.csv"))
  travel_df2<-read_csv(paste0(dropbox.dir,"/Data/oil/raw/NHTS/hhpub.csv"))
  
  #Assume 20 miles per gallon 
  miles_per_barrel<-20*42
  
  #Clean travel data
  travel_df<- travel_df %>% filter(DRVR_FLG == "01" & TRPTRANS %in% c("03","04","05","06","08","09","18") & TRPMILES >= 0) %>% group_by(HOUSEID) %>% mutate(old_total_buy = sum(WTTRDFIN*TRPMILES/(miles_per_barrel*365))) %>% ungroup() %>% select(HOUSEID,old_total_buy) %>% distinct()
  
  travel_df2$income<-NA
  hhfaminc_labs <- c("01", "02", "03","04","05","06","07","08","09","10","11")
  income_labs <- c(10000,14999, 24999, 34999, 49999, 74999, 99999, 124999, 149999, 199999, 224999)
  for(i in 1:length(income_labs)){
    travel_df2$income[which(travel_df2$HHFAMINC==hhfaminc_labs[i])]<-income_labs[i]
  }
  
  travel_df2<- travel_df2 %>% select(HOUSEID,income) %>% filter(!is.na(income))
  travel_df<-inner_join(travel_df2,travel_df)
  rm(travel_df2)
  
  # Collapse by income group
  travel_df <- travel_df %>% select(income,old_total_buy) %>% group_by(income) %>% summarise(old_total_buy=sum(old_total_buy)) %>%  ungroup()
  travel_df$income<-travel_df$income/10000
  travel_df <- travel_df %>% mutate(num = prod(income)) %>% mutate(dem= num/income) %>% mutate(dem2 = sum(dem)) %>% mutate(weight = num/(dem2*income)*nrow(travel_df))
  travel_df<- travel_df %>% mutate(share=old_total_buy/sum(old_total_buy)) %>% select(share, weight)
  
  return(travel_df)
}

oil_exit<-function(company_oil,profit_per_unit){
  
  #get slopes and intercepts
  b <- -demand_elasticity*total_oil/price_now # absolute value of slope of demand
  d <- supply_elasticity*total_oil/price_now # slope of supply
  a<- total_oil + b*price_now # q intercept of demand
  c<- total_oil - d*price_now # q intercept of supply
  
  #supply shock
  c <- c - company_oil
  
  # new equilibrium values
  new_price <- (a-c)/(b+d)
  new_total_oil<- a- (b*new_price)
  
  profits<- company_oil*(price_now*profit_per_unit)
  
  CS_change_global<- - (1/2)*(total_oil + new_total_oil)*(new_price-price_now)
  
  PS_other_change<- (1/2)*(new_total_oil + (total_oil-company_oil))*(new_price-price_now)
  
  PS<- PS_other_change*us_share
  CS_change<-CS_change_global*us_share
  
  TS_global_change<- - company_oil*(new_price-price_now) / 2
  TS_change<- TS_global_change*us_share
  
  return(c(company_oil,new_price,new_total_oil,profits, PS_other_change,PS,CS_change_global,CS_change, TS_global_change,TS_change))
}


profits<-function(x){
  "
  function for the profits
  "
  colnames(x)<-c("a","supply","price")
  x<-x[x$a!="Sum",]
  return(sum(diff(x$supply)*x$price[2:length(x$price)])/x$supply[length(x$price)])
}



powerset <- function(x) {
  "
  function to get the powerset.
  "
  sets <- lapply(1:(length(x)), function(i) combn(x, i, simplify = F))
  unlist(sets, recursive = F)
}
