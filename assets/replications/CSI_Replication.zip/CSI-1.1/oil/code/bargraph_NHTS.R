## Plotting oil output.
rm(list=ls())

source('lib/SetGlobals.R')

library(readr)
library(dplyr)
library(haven)
library(readxl)
library(tidyr)
library(stargazer)
library(ggplot2)

travel_df<-read_csv(paste0(dropbox.dir,"/Data/oil/raw/NHTS/trippub.csv"))
travel_df2<-read_csv(paste0(dropbox.dir,"/Data/oil/raw/NHTS/hhpub.csv"))

miles_per_barrel<-20
#Clean travel data
travel_df<- travel_df %>% mutate(TRPMILES = ifelse(DRVR_FLG == "01" & TRPTRANS %in% c("03","04","05","06","08","09","18") & TRPMILES >= 0,TRPMILES,0)) %>% group_by(HOUSEID) %>% mutate(old_total_buy = sum(WTTRDFIN*TRPMILES/(miles_per_barrel))) %>% ungroup() %>% select(HOUSEID,old_total_buy) %>% distinct()

travel_df2$income<-NA
travel_df2$income[which(travel_df2$HHFAMINC=="01")]<-"<10"
travel_df2$income[which(travel_df2$HHFAMINC=="02")]<-"10-15"
travel_df2$income[which(travel_df2$HHFAMINC=="03")]<-"15-25"
travel_df2$income[which(travel_df2$HHFAMINC=="04")]<-"25-35"
travel_df2$income[which(travel_df2$HHFAMINC=="05")]<-"35-50"
travel_df2$income[which(travel_df2$HHFAMINC=="06")]<-"50-75"
travel_df2$income[which(travel_df2$HHFAMINC=="07")]<-"75-100"
travel_df2$income[which(travel_df2$HHFAMINC=="08")]<-"100-125"
travel_df2$income[which(travel_df2$HHFAMINC=="09")]<-"125-150"
travel_df2$income[which(travel_df2$HHFAMINC=="10")]<-"150-200"
travel_df2$income[which(travel_df2$HHFAMINC=="11")]<-">200"

travel_df2<- travel_df2 %>% select(HOUSEID,income) %>% filter(!is.na(income))
travel_df<-inner_join(travel_df2,travel_df)
rm(travel_df2)

# Collapse by income group
travel_df <- travel_df %>% select(income,old_total_buy) %>% group_by(income) %>% summarise(old_total_buy=mean(old_total_buy)) %>%  ungroup()

travel_df$income <- factor(travel_df$income,levels = c("<10","10-15","15-25","25-35","35-50","50-75","75-100","100-125","125-150","150-200",">200"))

g<-ggplot(data=travel_df, aes(x=(income), y=old_total_buy/1000),fill=income) + geom_bar(stat="identity",fill='darkblue') + labs(x="Income group (thousands $)", y="Average gallons of gas consumption per year") + theme_grey(base_size = 9)
ggsave(filename="oil/output/oil_income.pdf", plot=g, width = 5, height = 3.5)
