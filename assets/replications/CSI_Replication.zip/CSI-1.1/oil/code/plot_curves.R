## Plotting oil outputs
source('lib/SetGlobals.R')

library(readxl)
library(dplyr)

#all
all <- read_excel(paste0(dropbox.dir,"/Data/oil/raw/rystad_data.xlsx"), sheet = "All", skip = 2)
colnames(all)<-c("a","b","c")
all<-all[all$a!="Sum",]
ggplot(all, aes(b,c)) + geom_step() + labs(x="Production (1000 barrels per day)",y="Price")

# By Company
companies <- read_excel(paste0(dropbox.dir,"/Data/oil/raw/rystad_data.xlsx"), skip = 3)
colnames(companies)<-c("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q")
companies<-companies[companies$a!="Sum",]
companies$Exxon="Exxon"
companies$BP="BP"
g<- ggplot(companies) + lims(y = c(0,120))+ geom_step(aes(x=b,y=c, color="Exxon", linetype="Exxon")) +
  geom_step(aes(x=d,y=e, color="BP", linetype="BP")) + geom_step(aes(x=f,y=g, color="Shell", linetype="Shell")) + 
  geom_step(aes(x=h,y=i, color="Chevron", linetype="Chevron")) + geom_step(aes(x=j,y=k, color="Total", linetype="Total")) + 
  geom_step(aes(x=l,y=m, color="ConocoPhillips", linetype="ConocoPhillips"))+ geom_step(aes(x=n,y=o, color="Eni", linetype="Eni"))+ 
  labs(x="Production (1000 barrels per day)",y="Marginal cost ($/barrel)") + labs(color="Company", linetype="Company")
ggsave(filename=paste0(github.dir, "oil/output/cost_curves.pdf"), plot=g, height = 3.5*1.5, width = 5*1.5)
