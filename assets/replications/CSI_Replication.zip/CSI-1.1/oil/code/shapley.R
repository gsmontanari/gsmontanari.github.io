## Running the shapley estimates on the oil industry.
rm(list=ls())

source('lib/functions.R')
source('lib/SetGlobals.R')
source( 'lib/ExportToLyx.R')

library(readr)
library(dplyr)
library(haven)
library(readxl)
library(tidyr)
library(stargazer)
library(ggplot2)
library(gtools)


library(readxl)

# run configs and utility functions
source("oil/code/configs.R")
source("oil/code/estimation_utils.R")

# read in data
output <- get_rystad_data()
company_data <- output[[1]]
production <- output[[2]]
price_now <- output[[3]]
total_oil <- output[[4]]

# get company level profits
prof <- c()
for(i in 1:length(company_data)){
  prof <- c(prof, profits(company_data[[i]]))
}

prof <- prof/price_now

sets<-powerset(1:7)
# get the production for each powerset entry
df<-data.frame()
for (i in 1:length(sets)){
  df<-rbind(df,oil_exit( sum(production[sets[[i]]]) , sum(production[sets[[i]]]*prof[sets[[i]]])/sum(production[sets[[i]]]) ))
}

names(df)<-c("Oil Production","Price on Exit","Production on Exit","Firm Global PS","Change in Global PS - Other Firms",
             "Change in US PS - Other Firms","Change in Global CS","Change in US CS","Change in Global TS","Change in US TS")
df$change_env_ext <- (total_oil - df$`Production on Exit`)*scc*.475

names(df)<-c("Oil Production","Price on Exit","Production on Exit","Firm Global PS","Change in Global PS - Other Firms",
             "Change in US PS - Other Firms","Change in Global CS","Change in US CS","Change in Global TS","Change in US TS",
             "Change in Env. Externality")


travel_df <- get_nhts_data()
#output table
output<-df
output$CS_billion<-df$`Change in US CS`/1000000000
output$OwnProfit_billion<- - df$`Firm Global PS`*0.2/1000000000
output$OtherProfit_billion<- df$`Change in US PS - Other Firms`/1000000000
output$TS_billion<- output$CS_billion + output$OwnProfit_billion + output$OtherProfit_billion

output$Revenues_billion<- price_now*df$`Oil Production`*0.2/1000000000
output$Externality_billion<-df$`Change in Env. Externality`*0.2/1000000000

output$CS_weighted_billion<-output$CS_billion*sum(travel_df$share*travel_df$weight)

oilCSweight<-sum(travel_df$share*travel_df$weight)
ExportToLyx(oilCSweight, 2)

w_weights <- fread(paste0(github.dir,'welfare_weights/output/welfare_weights.csv'))
profits_weight <- w_weights[["ProfitWeight"]]

output$OwnProfit_weighted_billion<- output$OwnProfit_billion * profits_weight
output$OtherProfit_weighted_billion<- output$OtherProfit_billion * profits_weight

output$TS_weighted_billion<-output$CS_weighted_billion+output$OwnProfit_weighted_billion+output$OtherProfit_weighted_billion

output$PS_billion<- output$OwnProfit_billion+output$OtherProfit_billion
output$PS_weighted_billion<-   output$OwnProfit_weighted_billion+output$OtherProfit_weighted_billion

output<-output[,c("CS_billion",
                  "OwnProfit_billion",
                  "OtherProfit_billion",
                  "TS_billion",
                  "Externality_billion",
                  "CS_weighted_billion",
                  "OwnProfit_weighted_billion",
                  "OtherProfit_weighted_billion",
                  "TS_weighted_billion")]



set_perm<- function(x,no) {
  # get all permutations of a set
  temp<-permutations(n = length(x), r = length(x), v = x)
  temp <- split(temp, 1:nrow(temp))
  return(lapply(temp, function(x) sort(x[1:which(x==no)])))
}


out <- data.table()
# for each firm
for (firm in 1:7){
  # get permutations
  firm_sets_sub<-set_perm(c(1:7), firm)

  shapley<-c(0,0,0,0,0,0,0)
  # estimate shapley value for each firm
  for (k in 1:length(firm_sets_sub)) {
    set_in<-as.vector(sort(unlist((firm_sets_sub[k]))))
    set_out<-as.vector(sort(unlist((firm_sets_sub[k]))))[-which(as.vector(sort(unlist((firm_sets_sub[k]))))==firm)]
    k_out<-which(sapply(sets,function(x)all(x==c(1:7)[!(1:7 %in% set_out)])))

    if (length(set_in)==7){
      shapley <- shapley + 0 - output[k_out,]
    } else {
    k_in<-which(sapply(sets,function(x)all(x==c(1:7)[!(1:7 %in% set_in)])))
    shapley <- shapley + output[k_in,]- output[k_out,]
  }
  }

  out <- rbindlist(list(out, data.table(c("Exxon","BP","Shell","Chevron","Total","Conoco","Eni")[firm],
                                        shapley/length(firm_sets_sub)
  )))
}

revenue<-price_now*production/1000000000

#out$CS_billion[out$CS_billion> (revenue*2)]<-revenue[out$CS_billion> (revenue*2)]
#out$CS_weighted_billion[out$CS_weighted_billion> (revenue*2)]<-revenue[out$CS_weighted_billion> (revenue*2)]


# output shapley estimates
colnames(out) <- c("firm",
                   "CS_billion",
                   "OwnProfit_billion",
                   "OtherProfit_billion",
                   "TS_billion",
                   "Externality_billion",
                   "CS_weighted_billion",
                   "OwnProfit_weighted_billion",
                   "OtherProfit_weighted_billion",
                   "TS_weighted_billion")


out$Externality_billion<- -out$Externality_billion

out$TS_weighted_billion <- out$CS_weighted_billion + out$OtherProfit_weighted_billion + out$OwnProfit_weighted_billion - out$Externality_billion
out$TS_billion <- out$CS_billion + out$OwnProfit_billion + out$OtherProfit_billion - out$Externality_billion

fwrite(out, 'oil/output/oil_shapley.csv', row.names = FALSE)

setwd(paste0(github.dir,"/oil"))


plot_shapley(out, "oil", weighted = NULL)
plot_shapley(out, "oil", weighted = TRUE)


setwd(github.dir)
