# Change to the current working directory
source('lib/SetGlobals.R')

# Clean all output
unlink('oil/output', recursive = TRUE)
dir.create('oil/output')

# Run all scripts
source('oil/code/single_firm.R')
source('oil/code/shapley.R')

source('oil/code/plot_curves.R')
source('oil/code/bargraph_NHTS.R')

# Change to the root
setwd(github.dir)
