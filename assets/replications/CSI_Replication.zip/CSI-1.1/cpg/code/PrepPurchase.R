# This code imports the purchase dataset and prepares it
library(data.table)
library(dplyr)
library(lubridate)

# Import purchase data, select certain modules, merge in household code and time, and combine across years
trips <- readRDS(paste0(Externals, '/Intermediate/Trips.rds'))
UPCs <- readRDS(paste0(Externals, '/Final/UPCs',product_module,'.rds'))[
  , .(upc, upc_ver_uc, product, brand_descr, size1_amount, size1_units, firm)]
combined_purchases <- c()
for (year in BeginYear:EndYear) {
  print(paste0('Purchases: Starting year ', year, '...'))
  purchases <- fread(paste0(Nielsen, '/HMS/', year, '/Annual_Files/purchases_', year, '.tsv'),
                     sep = '\t', quote = "", stringsAsFactors = FALSE, na.string = "")[
                       UPCs, on = c('upc', 'upc_ver_uc'), nomatch = 0]
  saveRDS(purchases, paste0(Externals, '/Intermediate/Purchases',product_module,year, '.rds'))
  combined_purchases <- rbind(combined_purchases, purchases)
}
combined_purchases <- combined_purchases[trips, on = 'trip_code_uc', nomatch = 0]
saveRDS(combined_purchases, paste0(Externals, '/Intermediate/Purchases',product_module,'.rds'))

# Merge in consumer groups
household_panel <- readRDS(paste0(Externals, '/Final/HouseholdPanel.rds'))
purchases <- readRDS(paste0(Externals, '/Intermediate/Purchases',product_module,'.rds'))[
  , panel_year := year(purchase_date)][
    , quarter := quarter(purchase_date)][
      , retailer_code := NULL][
        household_panel, on = c('panel_year', 'household_code'), nomatch = 0]

# Collapse to consumer group - product - quarter dataset
final <- purchases[
  , price_per_unit := (total_price_paid - coupon_value) / quantity][ # Average price by unit
    , .(firm = first(firm),
        brand = first(brand_descr),
        quantity = sum(quantity),
        price = mean(price_per_unit),
        price_sd = sd(price_per_unit),
        size = first(size1_amount),
        unit = first(size1_units),
        n = .N,
        income = mean(nominal_income)),
    by = .(retailer_code, product, panel_year, quarter)][
      , time := (panel_year - BeginYear) * 4 + quarter]

# Within each consumer group * year, keep products with at least 1 unit purchased in every quarter
subset_product <- final[
  , .(count = .N),
  by = .(retailer_code, product, panel_year)][
    count == 4][
      , c('count') := NULL] # Key: retailer_code, product, panel_year
final <- final[subset_product, on = c('retailer_code', 'product', 'panel_year'), nomatch = 0]

# Define total market size as 1+max(total quarterly units purchased in the consumer group * year)
market_size <- final[
  , .(market_size = sum(quantity)), by = .(retailer_code, panel_year, quarter)][ # quarterly units purchased
    , .(market_size = 1 + max(market_size)), by = .(retailer_code, panel_year)] # Key: retailer_code, panel_year

# Calculate quarterly quantities by each firm
firm_quantity <- final[
  , .(firm_quantity = sum(quantity)),
  by = .(retailer_code, firm, panel_year, quarter)] # Key: retailer_code, firm, panel_year, quarter

# Generate market share and within-nest share
final <- final[
  market_size, on = c('retailer_code', 'panel_year'), nomatch = 0][
    firm_quantity, on = c('retailer_code', 'firm', 'panel_year', 'quarter'), nomatch = 0][
      , log_share := log(quantity / market_size)][
        , log_within_nest_share := log(quantity / firm_quantity)]
write.csv(final, paste0(Externals, '/Final/DataForRegressions',product_module,'.csv'), quote = FALSE, row.names = FALSE, na = '') # Key: retailer_code, product, panel_year, quarter
saveRDS(final, paste0(Externals, '/Final/DataForRegressions',product_module,'.rds'))
