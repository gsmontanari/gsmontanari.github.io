# Filter UPCs within certain modules ane merge in flavor
UPCs <- fread(paste0(Externals, '/Intermediate/UPCs.txt'),
              sep = '|', quote = '', stringsAsFactors = FALSE, na.string = '')[
                product_module_code == product_module]

mapping <- read_dta(paste0(Raw, '/GS1_Nielsen_merged.dta'))
mapping<- mapping %>% select(upc2=UPC,firm=companyname)
mapping<- mapping %>% distinct()
mapping$firm<-gsub("[[:punct:]]", " ", mapping$firm)
  
UPCs <- product_attributes[UPCs, on = c('upc', 'upc_ver_uc')]
UPCs$upc2<-as.numeric(UPCs$upc)
mapping$upc2<-as.numeric(mapping$upc2)
UPCs<-left_join(UPCs,mapping)
UPCs$upc2<-NULL



# Group different UPCs into products by brand, size, flavor
UPCs[ , product := .GRP, by = .(firm, brand_code_uc, size1_amount, size1_units, flavor_code, flavor_descr)]

saveRDS(UPCs, paste0(Externals, '/Final/UPCs',product_module,'.rds'))
