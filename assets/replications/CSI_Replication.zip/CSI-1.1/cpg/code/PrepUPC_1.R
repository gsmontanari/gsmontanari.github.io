
# Combine additional product attributes
combined_product_attributes <- c()
for (year in BeginYear:EndYear) {
  print(paste0('Attributes: Starting year ', year, '...'))
  product_attributes <- fread(paste0(Nielsen, '/HMS/', year, '/Annual_Files/products_extra_', year, '.tsv'),
                              sep = '\t', quote = '', stringsAsFactors = FALSE, na.string = '')[
                                , c('size2_code', 'size2_amount', 'size2_units') := NULL]
  combined_product_attributes <- rbind(product_attributes, combined_product_attributes)
}
saveRDS(combined_product_attributes, paste0(Externals, '/Intermediate/ProductAttributes.rds'))
