## This code prepare trips data and identifies the primary retailer of each household * year

source('SetGlobals.R')
library(data.table)

# Import trips data, identify the primary retailer by total expenditure, and combine across years
combined_trips <- c()
combined_primary_retailer <- c()
for (year in BeginYear:EndYear) {
  print(paste0('Trips: Starting year ', year, '...'))
  data <- fread(paste0(Nielsen, '/HMS/', year, '/Annual_Files/trips_', year, '.tsv'),
                sep = '\t', quote = "", stringsAsFactors = FALSE, na.string = "")
  trips <- data[, .(trip_code_uc, household_code, purchase_date, store_code_uc, retailer_code)]
  # Identify the primary retailer of each household by total expenditure
  primary_retailer <- data[
    , .(total_spent_in_chain = sum(total_spent)), by = .(household_code, retailer_code, panel_year)][
    order(-total_spent_in_chain, retailer_code), head(.SD, 1), by = .(household_code, panel_year)][
      , total_spent_in_chain := NULL]
  combined_trips <- rbind(combined_trips, trips)
  combined_primary_retailer <- rbind(combined_primary_retailer, primary_retailer)
}
saveRDS(combined_trips, paste0(Externals, '/Intermediate/Trips.rds')) # Key: trip_code_uc
saveRDS(combined_primary_retailer, paste0(Externals, '/Intermediate/PrimaryRetailer.rds')) # Key: household_code, panel_year
