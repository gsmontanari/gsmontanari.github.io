## This code imports the household data and prepares it
source('SetGlobals.R')
library(data.table)
library(dplyr)

# Import household data and combine across years
combined_household_panel <- c()
for (year in BeginYear:EndYear) { 
  print(paste0('Households: Starting year ', year, '...'))
  household_panel <- fread(paste0(Nielsen, '/HMS/', year, '/Annual_Files/panelists_', year, '.tsv'),
                           sep = '\t', quote = "", stringsAsFactors = FALSE, na.string = "")
  household_panel <- household_panel[
    , c('Projection_Factor_Magnet', 'Type_Of_Residence', 'DMA_Name', 'Kitchen_Appliances', 'TV_Items', 'Household_Internet_Connection') := NULL][
      , grep('^Scantrack', names(household_panel)) := NULL][
        , grep('Occupation$', names(household_panel)) := NULL][
          , grep('^Member.+Employment$', names(household_panel)) := NULL]
  combined_household_panel <- rbind(combined_household_panel, household_panel)
}
saveRDS(combined_household_panel, paste0(Externals, '/Intermediate/HouseholdPanel.rds')) # Key: Household_Cd, Panel_Year

# Clean demographics, merge in primary retailer, and keep relevant variables
primary_retailer <- readRDS(paste0(Externals, '/Intermediate/PrimaryRetailer.rds'))
household_panel <- readRDS(paste0(Externals, '/Intermediate/HouseholdPanel.rds'))[
  , nominal_income :=  recode(Household_Income, 
                              `3`  = 2500,  `4`  = 6500,  `6`  = 9000,  `8`  = 11000, `10` = 13500,
                              `11` = 17500, `13` = 22500, `15` = 27500, `16` = 32500, `17` = 37500,
                              `18` = 42500, `19` = 47500, `21` = 55000, `23` = 65000, `26` = 85000,
                              .default = 140000)][
                                , .(household_code = Household_Cd, panel_year = Panel_Year, nominal_income)][
                                  primary_retailer, on = c('household_code', 'panel_year'), nomatch = 0]

# Restrict to consumer groups with at least `min_conusumer` consumers
subset_group <- primary_retailer[
  , .(count = .N), by = .(retailer_code, panel_year)][
    count >= min_household][
      , c('count') := NULL]
household_panel <- household_panel[subset_group, on = c('retailer_code', 'panel_year'), nomatch = 0]
saveRDS(household_panel, paste0(Externals, '/Final/HouseholdPanel.rds')) # Key: household_code, panel_year
