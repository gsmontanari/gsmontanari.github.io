source('../lib/SetGlobals.R')
library(readr)
library(readxl)
library(tidyverse)
library(dplyr)
library(glue)

products<-c("yogurt","beer","cereal","cigarettes","soda","toothpaste")
codes<-c("3603","5000","1344","7460","1484","8404")

for (i in 1:length(products)){
  product <- read_excel(glue("{github.dir}/issues/55/survey_text_generation/output/{products[i]}.xlsx"))
  product <- product %>% select(firm=firm_from_nielson,ticker)
  
  df <- read_csv(glue("{dropbox.dir}/Data/cpg/intermediate/DataForRegressions{codes[i]}.csv"))
  df<- left_join(df,product)
  df$ticker[is.na(df$ticker)]<-"Other"
  df <- df %>% group_by(ticker) %>%  summarise(shares=sum(price*quantity, na.rm=T))
  df$ticker[df$ticker==NA]<-"Other"
  df$shares<-df$shares/sum(df$shares)
  #df<-df %>% filter(ticker!="Other")
  write_csv(df,glue("{dropbox.dir}/Data/dpm/intermediate/{products[i]}_aggregate.csv"))
}

i<-4
product <- read_excel(glue("{github.dir}/issues/55/survey_text_generation/output/{products[i]}.xlsx"))
product <- product %>% dplyr::select(firm=firm_from_nielson,ticker)

df <- read_csv(glue("{dropbox.dir}/Data/cpg/intermediate/DataForRegressions{codes[i]}.csv"))
df<- left_join(df,product)

df$price<- df$price*5.29/weighted.mean(20*df$price/df$size,df$quantity*df$size)

df<-df %>% group_by(ticker) %>% summarise( avg_price=weighted.mean(20*price/size,quantity*size))
df$internality<- 14.65/df$avg_price
df$externality<- 0.64/df$avg_price

df$ticker[is.na(df$ticker)]<-"Other"

df<-df%>% dplyr::select(-c(avg_price))
write_csv(df,glue("{dropbox.dir}/Data/dpm/intermediate/cigarette_externality_internality.csv"))

i<-5
product <- read_excel(glue("{github.dir}/issues/55/survey_text_generation/output/{products[i]}.xlsx"))
product <- product %>% dplyr::select(firm=firm_from_nielson,ticker)

df <- read_csv(glue("{dropbox.dir}/Data/cpg/intermediate/DataForRegressions{codes[i]}.csv"))
df<- left_join(df,product)


df$price<- df$price*0.045/weighted.mean(df$price/df$size,df$quantity*df$size)

df<-df %>% group_by(ticker) %>% summarise( avg_price=weighted.mean(price/size,quantity*size))
df$internality<- 0.0093/df$avg_price
df$externality<- 0.0085/df$avg_price

df$ticker[is.na(df$ticker)]<-"Other"
df<-df %>% dplyr::select(-c(avg_price))
write_csv(df,glue("{dropbox.dir}/Data/dpm/intermediate/{products[i]}_externality_internality.csv"))

