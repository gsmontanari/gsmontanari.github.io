out<-data_frame()
for (i in 1:length(product_modules)){
  product_module<-product_modules[i]
  product_group<-product_groups[i]
  
  household_panel <- readRDS(paste0(Externals, '/Final/HouseholdPanel.rds'))
  purchases <- readRDS(paste0(Externals, '/Intermediate/Purchases',product_module,'.rds'))[
    , panel_year := year(purchase_date)][
      , quarter := quarter(purchase_date)][
        , retailer_code := NULL][
          household_panel, on = c('panel_year', 'household_code'), nomatch = 0]
  
  temp<-purchases %>% group_by(firm) %>% summarise( avg_income=weighted.mean(nominal_income,total_price_paid))
  temp$product_module=product_module
  out<-rbind(out,temp)
}

write.csv(out, paste0('output/firm_average_income.csv'), quote = FALSE, row.names = FALSE, na = '') # Key: retailer_code, product, panel_year, quarter
