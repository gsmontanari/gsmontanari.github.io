Nielsen = "/n/holylfs/EXTERNAL_REPOS/NIELSEN/dua_nielsen_consumer/nielsen_extracts"

NielsenRMS = "/n/holylfs/EXTERNAL_REPOS/NIELSEN/dua_nielsen_scanner/nielsen_extracts"
Externals = '/n/holyscratch01/kremer_lab/Brandon/Nielsen/data'
figures = '/n/holyscratch01/kremer_lab//kremer_lab/Brandon/Nielsen/figures'
Raw ="/n/home00/btan/CSI"
Output ="/n/home00/btan/git/CSI/cpg/output"
github.dir<-"/n/home00/btan/git/CSI/"



BeginYear = 2015
EndYear = 2019
min_household = 100

product_modules<-c(1484,1344,7460,3603, 8404, 5000)
product_groups<-c(1503,1005,4510,2510, 6014, 5001)
ind_names<-c("soda","cereal", "cig","yogurt","paste","beer")
ext_vals<-c(0.85,0,0.64,0,0,0)
full_names<-c("soda","cereal", "cigarettes","yogurt","toothpaste","beer")
