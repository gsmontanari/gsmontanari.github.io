# This code runs a loop over all product groups to run analysis for the CPG module
setwd("~/git/CSI/cpg")

# Set Globals
source('SetGlobals.R')

# Load packages
library(data.table)
library(dplyr)
library(tidyr)
library(haven)

# prepare the shared data
source('code/PrepTrip.R')
source('code/PrepHousehold.R')
source('code/PrepUPC_1.R')

# Run scripts for individual modules
for (i in 1:length(product_modules)){
  product_module<-product_modules[i]
  product_group<-product_groups[i]
  source('code/PrepUPC_2.R')
  source('code/PrepPurchase.R')
}

source('code/FirmAvgIncome.R')
source('code/FirmShares')


